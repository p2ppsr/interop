# Remaining native coverage review

Reviewed all66 feasible rows from the immutable306-row inventory. One scoped row already has complete implemented checks; seven have reusable calls but need stronger prospective independent predicates;58 need new native case inputs. No native verdict is inferred.

| ID | Assessment | Minimal next work |
| --- | --- | --- |
| `privileged.authorization/missing-reason` | `NEW_NATIVE_CASE_REQUIRED` | The requested conditional privileged:true branch is absent even though ordinary reason validation partly executes. |
| `privileged.authorization/short-reason` | `NEW_NATIVE_CASE_REQUIRED` | The requested conditional privileged:true branch is absent even though ordinary reason validation partly executes. |
| `privileged.authorization/overlong-reason` | `NEW_NATIVE_CASE_REQUIRED` | The requested conditional privileged:true branch is absent even though ordinary reason validation partly executes. |
| `permissions.restart-persistence/protocol-lock` | `NEW_NATIVE_CASE_REQUIRED` | No visible lock/unlock in the same running browser process. |
| `permissions.restart-persistence/basket-lock` | `NEW_NATIVE_CASE_REQUIRED` | No visible lock/unlock in the same running browser process. |
| `permissions.restart-persistence/certificate-lock` | `NEW_NATIVE_CASE_REQUIRED` | No visible lock/unlock in the same running browser process. |
| `permissions.revoke-persistence/single-restart` | `NEW_NATIVE_CASE_REQUIRED` | Individual category revocation and unaffected-category preservation across restart are absent. |
| `permissions.linkage-isolation/verifier` | `NEW_NATIVE_CASE_REQUIRED` | Only origin changes; no one-axis verifier scope mutation. |
| `permissions.linkage-isolation/counterparty` | `NEW_NATIVE_CASE_REQUIRED` | Only origin changes; no one-axis counterparty scope mutation. |
| `permissions.linkage-isolation/protocol` | `NEW_NATIVE_CASE_REQUIRED` | Only origin changes; no one-axis protocol scope mutation. |
| `permissions.linkage-isolation/level2-key` | `NEW_NATIVE_CASE_REQUIRED` | Only origin changes; no one-axis level2-key scope mutation. |
| `permissions.manifest-selection/subset-selected` | `NEW_NATIVE_CASE_REQUIRED` | No unchecked category is probed after a partial manifest grant. |
| `permissions.manifest-selection/spending-unchecked` | `NEW_NATIVE_CASE_REQUIRED` | No unchecked category is probed after a partial manifest grant. |
| `permissions.standing-allowance/single-over-cap-deny` | `NEW_NATIVE_CASE_REQUIRED` | No single request exceeds fresh cap100 by itself. |
| `permissions.allowance-boundaries/concurrent-cap` | `NEW_NATIVE_CASE_REQUIRED` | No joined accounting transition or concurrent reservation oracle for this variant. |
| `permissions.allowance-boundaries/abort-accounting` | `NEW_NATIVE_CASE_REQUIRED` | No joined accounting transition or concurrent reservation oracle for this variant. |
| `permissions.allowance-boundaries/rejection-accounting` | `NEW_NATIVE_CASE_REQUIRED` | No joined accounting transition or concurrent reservation oracle for this variant. |
| `permissions.allowance-boundaries/nosend-accounting` | `NEW_NATIVE_CASE_REQUIRED` | No joined accounting transition or concurrent reservation oracle for this variant. |
| `basket.ascii-length/bytes-0` | `NEW_NATIVE_CASE_REQUIRED` | No exact short-name case across createAction/internalizeAction/listOutputs/relinquishOutput. |
| `basket.ascii-length/bytes-4` | `NEW_NATIVE_CASE_REQUIRED` | No exact short-name case across createAction/internalizeAction/listOutputs/relinquishOutput. |
| `basket.ascii-length/bytes-5` | `NEW_NATIVE_CASE_REQUIRED` | No exact short-name case across createAction/internalizeAction/listOutputs/relinquishOutput. |
| `basket.unicode-and-namespace/uppercase` | `NEW_NATIVE_CASE_REQUIRED` | No exact malformed namespace across all4 basket-consuming methods; normalization must not be silently counted as rejection. |
| `basket.unicode-and-namespace/double-space` | `NEW_NATIVE_CASE_REQUIRED` | No exact malformed namespace across all4 basket-consuming methods; normalization must not be silently counted as rejection. |
| `basket.unicode-and-namespace/trailing-basket` | `NEW_NATIVE_CASE_REQUIRED` | No exact malformed namespace across all4 basket-consuming methods; normalization must not be silently counted as rejection. |
| `transaction.defaults/acceptDelayedBroadcast-omitted-true` | `NEW_NATIVE_CASE_REQUIRED` | No exact omitted-vs-true pair across createAction/signAction; existing source also documents conflicting sendWith timing prose. |
| `transaction.signing-branches/foreign-reference-reject` | `NEW_NATIVE_CASE_REQUIRED` | Missing/consumed reference is not a real pending reference owned by a different wallet. |
| `transaction.proof-trust/unknown-not-in-knownTxids` | `NEW_NATIVE_CASE_REQUIRED` | Neither exact variant nor internalizeAction counterpart exists. |
| `transaction.proof-trust/conflicting-proof` | `NEW_NATIVE_CASE_REQUIRED` | Neither exact variant nor internalizeAction counterpart exists. |
| `transaction.proof-trust/wrong-merkle-root` | `NEW_NATIVE_CASE_REQUIRED` | Neither exact variant nor internalizeAction counterpart exists. |
| `transaction.batch-send/two-dependent-held` | `NEW_NATIVE_CASE_REQUIRED` | Exact multi-transaction or signAction batch variant absent. |
| `transaction.batch-send/sign-sendWith` | `NEW_NATIVE_CASE_REQUIRED` | Exact multi-transaction or signAction batch variant absent. |
| `transaction.batch-send/unknown-batch-txid` | `NEW_NATIVE_CASE_REQUIRED` | Exact multi-transaction or signAction batch variant absent. |
| `transaction.nosend-change/valid-subset` | `NEW_NATIVE_CASE_REQUIRED` | A real semantically invalid/subset outpoint and both create/sign variants are absent. |
| `transaction.nosend-change/foreign-output` | `NEW_NATIVE_CASE_REQUIRED` | A real semantically invalid/subset outpoint and both create/sign variants are absent. |
| `transaction.nosend-change/already-spent` | `NEW_NATIVE_CASE_REQUIRED` | A real semantically invalid/subset outpoint and both create/sign variants are absent. |
| `transaction.nosend-change/out-of-range` | `NEW_NATIVE_CASE_REQUIRED` | A real semantically invalid/subset outpoint and both create/sign variants are absent. |
| `transaction.nosend-change/noSend-false` | `NEW_NATIVE_CASE_REQUIRED` | A real semantically invalid/subset outpoint and both create/sign variants are absent. |
| `transaction.internalization/wallet-payment` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/basket-insertion` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/both-output-types` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/missing-paymentRemittance` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/missing-insertionRemittance` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/conflicting-remittance` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/wrong-derivation` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/output-index-out-of-range` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `transaction.internalization/relinquish-without-spend` | `NEW_NATIVE_CASE_REQUIRED` | Full cross-API credit/basket transition or exact semantic malformed remittance is not independently bound. Existing valid payment data should be reused before creating another payment. |
| `query.output-filters/relinquished-excluded` | `EXISTING_TRACE_NEW_ORACLE_REQUIRED` | Absence can currently be mistaken for spending: no predicate protects that output through all final submission ancestry. |
| `certificate.issuance/wrong-auth-identity` | `NEW_NATIVE_CASE_REQUIRED` | No wrong authenticated transport identity variant. Applicant-versus-server identity must be explicitly distinguished; do not claim a mutated certifier field tests transport auth. |
| `certificate.inventory/restart` | `NEW_NATIVE_CASE_REQUIRED` | No complete before/after native certificate inventory equality across restart. |
| `certificate.revocation/relinquish-revoked` | `NEW_NATIVE_CASE_REQUIRED` | No revoked fixture local deletion and post-deletion list control; revocation policy must distinguish chain status from local retention. |
| `certificate.discovery/identity-match` | `EXISTING_TRACE_NEW_ORACLE_REQUIRED` | Returned certifierInfo trust metadata is not checked against the exact temporary trust settings; aggregate row explicitly requires it. |
| `certificate.discovery/attribute-match` | `EXISTING_TRACE_NEW_ORACLE_REQUIRED` | Returned certifierInfo trust metadata is not checked against the exact temporary trust settings; aggregate row explicitly requires it. |
| `certificate.discovery/attribute-no-match` | `NEW_NATIVE_CASE_REQUIRED` | Exact negative/multiple-issuer/permission-default native case missing; a verifier tamper regression or an already-trusted explicittrue call is not this scenario. |
| `certificate.discovery/multiple-certifiers` | `NEW_NATIVE_CASE_REQUIRED` | Exact negative/multiple-issuer/permission-default native case missing; a verifier tamper regression or an already-trusted explicittrue call is not this scenario. |
| `certificate.discovery/untrusted-excluded` | `FULL_EXISTING_SCOPED` | No new case needed for this scoped row. Qualification must still use actual admitted native report; this read-only mapping supplies no native verdict. |
| `certificate.discovery/bad-signature` | `NEW_NATIVE_CASE_REQUIRED` | Exact negative/multiple-issuer/permission-default native case missing; a verifier tamper regression or an already-trusted explicittrue call is not this scenario. |
| `certificate.discovery/bad-keyring` | `NEW_NATIVE_CASE_REQUIRED` | Exact negative/multiple-issuer/permission-default native case missing; a verifier tamper regression or an already-trusted explicittrue call is not this scenario. |
| `certificate.discovery/default-seekPermission-false` | `NEW_NATIVE_CASE_REQUIRED` | Exact negative/multiple-issuer/permission-default native case missing; a verifier tamper regression or an already-trusted explicittrue call is not this scenario. |
| `certificate.discovery/explicit-seekPermission-true` | `NEW_NATIVE_CASE_REQUIRED` | Exact negative/multiple-issuer/permission-default native case missing; a verifier tamper regression or an already-trusted explicittrue call is not this scenario. |
| `crypto.conditional-signatures/data-only` | `EXISTING_TRACE_NEW_ORACLE_REQUIRED` | Boundary verifies the native signature under a native-returned child key and does not independently bind that child to exact identity/protocol/key/counterparty or verify all original arguments. |
| `crypto.conditional-signatures/hash-only` | `EXISTING_TRACE_NEW_ORACLE_REQUIRED` | The generic verifySignature hash-only control only proves it returned a result; it does not independently authenticate that signature/hash/context or require valid:true. |
| `crypto.conditional-signatures/neither-data-nor-hash` | `NEW_NATIVE_CASE_REQUIRED` | No request omits both inputs. |
| `crypto.conditional-signatures/forSelf-false-default` | `NEW_NATIVE_CASE_REQUIRED` | No equivalent omitted-forSelf verifySignature call exists; explicit false alone cannot prove the default. |
| `crypto.conditional-signatures/forSelf-true` | `EXISTING_TRACE_NEW_ORACLE_REQUIRED` | Current boundary verifier checks valid:true without independently binding exact forSelf/request/key universe. |
| `crypto.conditional-signatures/anyone-counterparty` | `EXISTING_TRACE_NEW_ORACLE_REQUIRED` | Current signature predicate trusts the SUT-returned child public key, so a congruently wrong derivation is not excluded. |
| `crypto.conditional-signatures/identityKey-override` | `NEW_NATIVE_CASE_REQUIRED` | A bare identity query does not exercise overriding protocolID/keyID/counterparty. |

See review.json for exact source/call/predicate evidence, all66 proposed oracles, scope constraints and bounded phase estimates. Existing4.2 remains unchanged.
