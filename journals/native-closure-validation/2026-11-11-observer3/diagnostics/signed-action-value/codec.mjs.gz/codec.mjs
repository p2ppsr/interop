import fs from 'node:fs'
import assert from 'node:assert/strict'
import Processor from '../../../synthesis/node_modules/@bsv/sdk/dist/esm/src/wallet/substrates/WalletWireProcessor.js'
import Transceiver from '../../../synthesis/node_modules/@bsv/sdk/dist/esm/src/wallet/substrates/WalletWireTransceiver.js'
const observations=[]
for(const value of [-1032,-1,0,1,1032]) {
  const action={txid:'11'.repeat(32),satoshis:value,status:'nosend',isOutgoing:true,description:'Signed value codec control',version:1,lockTime:0}
  const processor=new Processor({listActions:async()=>({totalActions:1,actions:[action]})})
  let response
  const transceiver=new Transceiver({transmitToWallet:async bytes=>{response=await processor.transmitToWallet(bytes);return response}})
  const result=await transceiver.listActions({labels:[]},'lab.itcve.test')
  assert.equal(result.actions[0].satoshis,value)
  observations.push({input:value,decoded:result.actions[0].satoshis,responseHex:Buffer.from(response).toString('hex')})
}
console.log(JSON.stringify({claim:'ENGINEERING_CODEC_ONLY_NOT_NATIVE',sdk:'2.7.1',observations},null,2))
