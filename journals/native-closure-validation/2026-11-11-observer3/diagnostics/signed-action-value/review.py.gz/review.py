from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[3]
folder=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=folder/'brc100-current-9150386.md';b=p.read_bytes()
blob=lambda raw:hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
if blob(b)!= '6aea78a5568c79ba01f577c51e2add540d0c188e':
 assert blob(b[:-1])=='6aea78a5568c79ba01f577c51e2add540d0c188e';p.write_bytes(b[:-1]);b=b[:-1]
files={
'pinnedBRC100':('out/native-conformance-20261109/brc100.md',[[277,277],[435,442],[810,824],[1619,1628],[1820,1823]]),
'currentBRC100':(str(p.relative_to(root)),[[27,37],[290,290],[462,469],[837,850],[1647,1656],[1848,1851]]),
'TSStorageCalculation':('synthesis/node_modules/@bsv/wallet-toolbox/out/src/storage/methods/createAction.js',[[146,156],[474,487]]),
'TSStorageProjection':('synthesis/node_modules/@bsv/wallet-toolbox/out/src/storage/methods/listActionsKnex.js',[[177,188]]),
'TSStorageIdbProjection':('synthesis/node_modules/@bsv/wallet-toolbox/out/src/storage/methods/listActionsIdb.js',[[120,132]]),
'GoStorageCalculation':('out/storage-native-contracts-go-source/pkg/storage/internal/actions/create.go',[[611,628]]),
'GoStorageProjection':('out/storage-native-contracts-go-source/pkg/storage/internal/actions/list_actions_mapping.go',[[85,94]]),
'GoStorageContract':('out/storage-native-contracts-go-source/pkg/wdk/storage_list_actions_args.go',[[30,45]]),
'TSWireProcessor':('synthesis/node_modules/@bsv/sdk/dist/esm/src/wallet/substrates/WalletWireProcessor.js',[[584,592]]),
'TSWireTransceiver':('synthesis/node_modules/@bsv/sdk/dist/esm/src/wallet/substrates/WalletWireTransceiver.js',[[210,216]]),
'TSVarIntCodec':('synthesis/node_modules/@bsv/sdk/dist/esm/src/primitives/utils.js',[[502,507],[548,555],[680,698]]),
'GoSDKInterface':('/Users/tyeverett/go/pkg/mod/github.com/bsv-blockchain/go-sdk@v1.7.3/wallet/interfaces.go',[[271,280]]),
'GoSDKCodec':('/Users/tyeverett/go/pkg/mod/github.com/bsv-blockchain/go-sdk@v1.7.3/wallet/serializer/list_actions.go',[[118,124],[203,210]]),
'YoursShippedCandidateAccounting':('out/native-closure-20261111/standing-allowance-review/candidate/background.js/151/source.ts',[[44303,44329]]),
'YoursProspectiveAccounting':('/Users/tyeverett/tmp/network-ops/worktrees/ty-everett/yours-wallet/codex/ghsa-5vmp-dependency-upgrade/node_modules/@bsv/wallet-toolbox-client/out/index.client.mjs',[[44341,44375]]),
'YoursHistoryConsumer':('/Users/tyeverett/tmp/network-ops/worktrees/ty-everett/yours-wallet/codex/ghsa-5vmp-dependency-upgrade/src/utils/coinHistory.ts',[[73,77],[108,120]])}
sources={}
for name,(file,ranges) in files.items():
 path=Path(file) if Path(file).is_absolute() else root/file;raw=path.read_bytes();lines=raw.decode().splitlines()
 sources[name]={'path':file,'sha256':sha(raw),'bytes':len(raw),'excerpts':[{'firstLine':a,'lastLine':z,'text':'\n'.join(lines[a-1:z])} for a,z in ranges]}
assert sources['pinnedBRC100']['sha256']=='537ab393c655195e8cd61897b00d6b187a36f17d930493f8af48430752064082'
ts=json.loads((folder/'typescript-codec.json').read_text());go=json.loads((folder/'go-codec.json').read_text());assert ts['observations']==go['observations']
base=root/'out/native-review-43157433977/attempt-2026-11-12T05-17-05-561Z/original/repetition-1/evidence/conformance'
clause=json.loads((base/'clauses.json').read_text());conditional=json.loads((base/'conditional.json').read_text())
action=next(c['result']['actions'][0] for c in clause['trace'] if c['method']=='listActions' and c.get('result',{}).get('actions'))
rows={}
for c in conditional['trace']:
 if c['method']=='listActions':
  for a in (c.get('result') or {}).get('actions',[]):rows[a['txid']]={k:a.get(k) for k in ['txid','satoshis','isOutgoing','status']}
result={'schema':'tpnil-signed-action-amount-review@1','claim':'SOURCE_AND_CODEC_ENGINEERING_ONLY','nativeSessions':0,'runtimeEdits':False,
'conclusion':'Pinned positive-only SatoshiValue conflicts with established signed-net listActions behavior in both storage implementations and both SDK codecs. Preserve the honest output.listActions FAIL; do not change sign, clamp, suppress actions or weaken the pinned predicate. A default public projection would break existing callers and wire bytes, and a zero net action cannot satisfy minimum1 without fabricating value. Standards clarification or an explicitly negotiated additive API is needed; no conformance closure claimed.',
'primaryCurrentSource':{'repository':'bsv-blockchain/BRCs','commit':'9150386334fe1411a295ee1f2e354f215f93339e','path':'wallet/0100.md','gitBlobSha':blob(b),'sha256':sha(b),'url':'https://github.com/bsv-blockchain/BRCs/blob/9150386334fe1411a295ee1f2e354f215f93339e/wallet/0100.md'},
'originalNativeObservation':{'runId':43157433977,'repetition':1,'source':'585211c193d0288effeb466bda38fe6ef23ac94d','clausesSha256':sha((base/'clauses.json').read_bytes()),'conditionalSha256':sha((base/'conditional.json').read_bytes()),'assertion':next(a for a in clause['assertions'] if a['id']=='output.listActions'),'sample':{k:action[k] for k in ['txid','satoshis','isOutgoing','status']},'conditionalUniqueActions':len(rows),'negative':sum(a['satoshis']<0 for a in rows.values()),'zero':sum(a['satoshis']==0 for a in rows.values()),'positive':sum(a['satoshis']>0 for a in rows.values())},
'codecReview':{'typescriptSDK':'2.7.1','goSDK':'1.7.3','values':[-1032,-1,0,1,1032],'exactByteEquality':True,'eachRoundTripsUnchanged':True,'scope':'Actual SDK listActions encoder/decoder with deterministic result fixture, no wallet/UI/session qualification'},
'accountingCounterexample':{'existingDebit':-1032,'existingSpent':1032,'absProjectionSpent':-1032,'zeroClampSpent':0,'impact':'Permission manager subtracts signed net amounts; normalizing storage or its underlying listActions would turn actual spend into credit or erase it.'},
'possiblePaths':[{'path':'abs or clamp storage/public result','admissible':False,'reason':'Changes deployed wire/API meaning; breaks internal spending if applied beneath permissions; zero net still incompatible with minimum1.'},{'path':'filter negative or zero actions','admissible':False,'reason':'Drops legitimate transaction history and breaks totalActions/pagination/accounting.'},{'path':'unsigned magnitude only for non-admin callers','admissible':False,'reason':'Can preserve internal accounting but still breaks established external caller signed results and default wire bytes; isOutgoing marks creation origin rather than defining an invertible balance sign.'},{'path':'clarify a distinct signed net balance type and signed VarInt semantics in BRC100 or explicitly negotiate an additive representation','admissible':'requires separate prospective standard/API decision','reason':'Can preserve historical contracts and expose exact magnitude/direction without altering existing results; strict pinned positive-only conformance remains unresolved until an approved new contract.'}],
'sources':sources,'receipts':{q.name:{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in folder.iterdir() if q.is_file() and q.name not in ['review.json']}}
(folder/'review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'receipt':str(folder/'review.json'),'sha256':sha((folder/'review.json').read_bytes()),'nativeOutputPredicate':'FAIL','codecCases':5,'crossLanguageBytesEqual':True,'newNativeSessions':0}))
