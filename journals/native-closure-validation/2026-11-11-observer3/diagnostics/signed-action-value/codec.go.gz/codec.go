package main
import("encoding/hex";"encoding/json";"fmt";"github.com/bsv-blockchain/go-sdk/chainhash";"github.com/bsv-blockchain/go-sdk/wallet";"github.com/bsv-blockchain/go-sdk/wallet/serializer")
func main(){
 h,err:=chainhash.NewHashFromHex("1111111111111111111111111111111111111111111111111111111111111111");if err!=nil{panic(err)}
 rows:=[]map[string]any{}
 for _,value:=range []int64{-1032,-1,0,1,1032}{
  in:=&wallet.ListActionsResult{TotalActions:1,Actions:[]wallet.Action{{Txid:*h,Satoshis:value,Status:wallet.ActionStatusNoSend,IsOutgoing:true,Description:"Signed value codec control",Version:1,LockTime:0}}}
  raw,err:=serializer.SerializeListActionsResult(in);if err!=nil{panic(err)}
  out,err:=serializer.DeserializeListActionsResult(raw);if err!=nil{panic(err)}
  if out.Actions[0].Satoshis!=value{panic("signed amount differs")}
  rows=append(rows,map[string]any{"input":value,"decoded":out.Actions[0].Satoshis,"responseHex":hex.EncodeToString(append([]byte{0},raw...))})
 }
 raw,_:=json.MarshalIndent(map[string]any{"claim":"ENGINEERING_CODEC_ONLY_NOT_NATIVE","sdk":"1.7.3","observations":rows},"","  ");fmt.Println(string(raw))
}
