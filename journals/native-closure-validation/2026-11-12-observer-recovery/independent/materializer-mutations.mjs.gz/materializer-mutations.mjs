import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {prepareFrozenComponentReplay} from '../../../scripts/frozen-component-replay.mjs'
const temporary=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'tpnil-materializer-review-'))),root=path.join(temporary,'repository'),checks=[]
const write=(name,value)=>{const p=path.join(root,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,value)}
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8',timeout:30000})
const commit=message=>{git('add','-A');git('-c','user.name=TPNIL fixture','-c','user.email=fixture@example.invalid','commit','-qm',message);return git('rev-parse','HEAD').trim()}
const scratchEmpty=()=>assert.equal(fs.readdirSync(temporary).filter(p=>p.startsWith('.tpnil-replay-archive-')).length,0)
try{
 fs.mkdirSync(root);write('.nvmrc',process.versions.node+'\n');write('package.json','{}');write('scripts/marker.mjs','$Format:%s$');write('scripts/executable.mjs','export const ok=true\n');fs.chmodSync(path.join(root,'scripts/executable.mjs'),0o755)
 for(const p of ['synthesis','integrations/services','components/transport']){write(p+'/package-lock.json','{"lockfileVersion":3}');fs.mkdirSync(path.join(root,p,'node_modules'))}
 write('components/rust/Cargo.lock','# fixture\n');git('init','-q')
 let source=commit('plain source');const good=prepareFrozenComponentReplay(root,source,path.join(temporary,'good'))
 assert.equal(fs.readFileSync(path.join(good.root,'scripts/marker.mjs'),'utf8'),'$Format:%s$');assert.ok(fs.statSync(path.join(good.root,'scripts/executable.mjs')).mode&0o111);scratchEmpty();checks.push({id:'regular-and-executable-blobs',result:'PASS'});fs.rmSync(good.root,{recursive:true})
 write('.gitattributes','scripts/marker.mjs export-subst\n');source=commit('evil-marker')
 assert.equal(Buffer.byteLength('$Format:%s$'),Buffer.byteLength('evil-marker'))
 assert.throws(()=>prepareFrozenComponentReplay(root,source,path.join(temporary,'same-size-substitution')),/Frozen source Git blob differs: scripts\/marker.mjs/);scratchEmpty();checks.push({id:'same-size-export-subst',result:'REJECTED_BY_GIT_BLOB_HASH'})
 write('.gitattributes','scripts/marker.mjs export-ignore\n');source=commit('ignored file')
 assert.throws(()=>prepareFrozenComponentReplay(root,source,path.join(temporary,'omitted-file')),/Frozen archive inventory differs/);scratchEmpty();checks.push({id:'export-ignore-omission',result:'REJECTED_BY_EXACT_FILE_SET'})
 const result={schema:'tpnil-materializer-independent-mutation-review@1',claim:'LAB_SELF_TEST_ONLY_NOT_NATIVE_QUALIFICATION',status:'PASS',checks,source:{path:'scripts/frozen-component-replay.mjs',sha256:createHash('sha256').update(fs.readFileSync(new URL('../../../scripts/frozen-component-replay.mjs',import.meta.url))).digest('hex')},nativeSessions:0}
 fs.writeFileSync(new URL('materializer-mutations.json',import.meta.url),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result))
}finally{fs.rmSync(temporary,{recursive:true,force:true})}
