#!/usr/bin/env python3
import hashlib,json,pathlib,subprocess,datetime,sys
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
BASE='c648022b2d9209b7350527bd5553d73e3e82a52c'
def data(p): return (ROOT/p).read_bytes()
def obj(p): return json.loads(data(p))
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
oldpath='infra/native/conformance/plan-pr368-coverage-1.json'
planpath='infra/native/conformance/plan-pr368-coverage-2.json'
rustpath='infra/native/conformance/rust-graph-pr368-coverage-2.json'
reevalpath='infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-6.json'
old=obj(oldpath); plan=obj(planpath); rust=obj(rustpath); reeval=obj(reevalpath)
assert len(plan['conformanceInputs'])==164
assert all(sha(data(p))==h for p,h in plan['conformanceInputs'].items())
assert plan['expectedObservations']==535 and plan['coverageRevision']==2
assert plan['itcve']=='ITCVE-1@4.4.0' and plan['program']=='ISI-4@5.4.0'
assert plan['admissionState']=='FROZEN' and plan['claim']=='ENGINEERING_OBSERVATION_ONLY'
for k in ['wallet','walletCandidate','coverageModules','compatibilityPatchSha256','timeoutSecondsPerRepetition','executionBudget']: assert plan[k]==old[k],k
assert plan['walletCandidate']['officialRelease'] is False
p1=obj('itcves/ITCVE-1/4.3.0/profile.json');p2=obj('itcves/ITCVE-1/4.4.0/profile.json')
assert p1['nativeConformance']['assertions']==p2['nativeConformance']['assertions']
assert sum(len(x) for x in p2['nativeConformance']['assertions'].values())==527
assert sum(m['assertions'] for m in plan['coverageModules'].values())==109
# Check every existing JSON in the native/profile/policy families, plus all
# original profile JSON inputs. Read committed bytes directly, not a prior report.
files=set(p for p in old['conformanceInputs'] if p.endswith('.json'))
for p in git('ls-tree','-r','--name-only',BASE,'--','infra/native','itcves/ITCVE-1','programs/ISI-4').decode().splitlines():
 if p.endswith('.json'): files.add(p)
unchanged={}
for p in sorted(files):
 current=data(p); assert current==git('show',BASE+':'+p),p
 unchanged[p]=sha(current)
assert rust['nativePlan']=={'path':planpath,'sha256':sha(data(planpath)),'profile':plan['itcve'],'program':plan['program']}
assert rust['sourceBindingRevision']==5
assert rust['predecessor']=={'manifest':'infra/native/conformance/rust-graph-pr368-coverage-1.json','sha256':sha(data('infra/native/conformance/rust-graph-pr368-coverage-1.json'))}
for p,h in rust['sources'].items(): assert sha(data(p))==h,p
assert reeval['sourceBindingRevision']==6
priorpath='infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-5.json'
assert reeval['predecessor']=={'path':priorpath,'sha256':'3c7b9ba53566eaae153aed5734266f58d1bd91746a1d4bb9e08f2002e91c263b'}
prior=obj(priorpath)
for k in ['original','rust','expected']: assert reeval[k]==prior[k],k
for p,h in reeval['evaluatorSources'].items(): assert sha(data(p))==h,p
candidate=obj(plan['walletCandidate']['manifest']);assert sha(data(plan['walletCandidate']['manifest']))==plan['walletCandidate']['manifestSha256']
assert candidate['wallet']==plan['wallet'] and candidate['officialRelease'] is False
candidateFiles={str(pathlib.Path(plan['walletCandidate']['manifest']).parent/p):h for p,h in candidate['files'].items()}
for p,h in candidateFiles.items(): assert sha(data(p))==h,p
# Actual retained identity was emitted by the Linux native all-Go service process.
identitypath='journals/integrated-native-attempts/2026-11-12/43195585984/original/repetition-1/evidence/service-components.json'
identity=obj(identitypath);assert identity['components']=={'overlay':'go','chaintracks':'go','storage':'go'}
assert sha(data(identitypath))=='db5c0ab28f3b6ac3ca1af4790c14f6376fb2c62d6ce5981da87c19ee431f4088'
build=identity['go']['compatibilityPatch'];assert build['schema']=='tpnil-storage-sqlite-retry-go-build@1.0.0'
assert build['patchLockSha256']==plan['compatibilityPatchSha256']; assert build['binarySha256']==identity['go']['binarySha256']
for p,h in build['inputs'].items(): assert sha(data(p))==h,p
result={'schema':'tpnil-coverage2-independent-source-review@1','claim':'READ_ONLY_SOURCE_PREFLIGHT_NOT_NATIVE_QUALIFICATION','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executionBase':BASE,'status':'PASS','nativeSessions':0,'plan':{'path':planpath,'sha256':sha(data(planpath))},'rust':{'path':rustpath,'sha256':sha(data(rustpath))},'reevaluation':{'path':reevalpath,'sha256':sha(data(reevalpath))},'sourceInputs':plan['conformanceInputs'],'oldJsonUnchanged':unchanged,'candidateFilesVerified':len(candidateFiles),'actualGoIdentity':{'path':identitypath,'sha256':sha(data(identitypath)),'buildInputCount':len(build['inputs']),'buildSchema':build['schema'],'binarySha256':build['binarySha256']},'predicates':{'totalUnchanged':535,'fourConformanceVectors':527,'baselineFirstFour':8,'coverageDeltaUnchanged':109},'source6AcceptanceUnchanged':reeval['expected'],'scopes':['No new native observations or result promotion','All existing JSON is compared directly with c648 Git blobs','Current source may contain prospective edits; exact committed-source admission remains required before dispatch']}
destination=OUT/(sys.argv[1] if len(sys.argv)>1 else 'source-review.json')
with destination.open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','inputs':164,'oldJsonUnchanged':len(unchanged),'candidateFilesVerified':len(candidateFiles),'goBuildInputs':len(build['inputs']),'receipt':str(destination),'sha256':sha(destination.read_bytes())}))
