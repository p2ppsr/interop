import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {verifyIntegrationArchive,requireArchiveVerifierReceipt} from '../../../../scripts/verify-published-integrations.mjs'
const directory=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'tpnil-coverage2-publication-review-')))
const original={schema:'tpnil-native-integrated-qualification@2',claim:'ENGINEERING_OBSERVATION_ONLY',profile:'ITCVE-1@4.4.0',program:'ISI-4@5.4.0',source:'ab'.repeat(20),qualifiedEnvironment:true,completeBRC100Conformance:false}
const hash=bytes=>createHash('sha256').update(bytes).digest('hex'),checks=[]
// LAB_SELF_TEST_ONLY: opaque archive bytes exercise metadata admission only.
// This never invokes semantic replay and makes no native qualification claim.
function publish(value){
 fs.writeFileSync(path.join(directory,'qualification.json'),JSON.stringify(value))
 fs.writeFileSync(path.join(directory,'native-integrated.zip'),'LAB_SELF_TEST_NOT_AN_EVIDENCE_PACK')
 const files=['qualification.json','native-integrated.zip'].map(name=>{const bytes=fs.readFileSync(path.join(directory,name));return {path:name,size:bytes.length,sha256:hash(bytes)}})
 fs.writeFileSync(path.join(directory,'provenance.json'),JSON.stringify({schema:'tpnil-integrated-native-archive@1',source:original.source,files}))
 return verifyIntegrationArchive(directory)
}
try{
 const bundle=publish(original);assert.equal(bundle.qualification.profile,'ITCVE-1@4.4.0');assert.deepEqual(requireArchiveVerifierReceipt(JSON.stringify(original),bundle),original)
 checks.push({id:'exact-4.4-engineering-metadata',result:'PASS'})
 for(const [id,change] of Object.entries({previousProgram:{program:'ISI-4@5.3.0'},previousProfile:{profile:'ITCVE-1@4.3.0'},releaseClaim:{claim:'EXPERIMENTAL_CONFORMANCE_RESULT'},fullConformance:{completeBRC100Conformance:true},unqualified:{qualifiedEnvironment:false},differentSource:{source:'cd'.repeat(20)},missingProgram:{program:undefined}})){
  assert.throws(()=>publish({...original,...change}),id);checks.push({id,result:'REJECTED'})
 }
 for(const key of ['profile','program','claim']){const changed={...original};delete changed[key];assert.throws(()=>requireArchiveVerifierReceipt(JSON.stringify(changed),bundle));checks.push({id:'child-missing-'+key,result:'REJECTED'})}
 const relabeled={...original,profile:'ITCVE-1@4.3.0',program:'ISI-4@5.3.0'},prior=publish(relabeled)
 assert.throws(()=>requireArchiveVerifierReceipt(JSON.stringify(original),prior));assert.throws(()=>requireArchiveVerifierReceipt(JSON.stringify(relabeled),bundle))
 checks.push({id:'jointly-rehashed-previous-profile-vs-exact-child',result:'REJECTED'})
 const result={schema:'tpnil-coverage2-publication-mutation-review@1',claim:'LAB_SELF_TEST_ONLY_NOT_NATIVE_QUALIFICATION',scope:'Metadata/child receipt admission only; opaque test archive not semantic replay',status:'PASS',positiveControls:1,negativeControls:11,checks,source:{path:'scripts/verify-published-integrations.mjs',sha256:hash(fs.readFileSync(new URL('../../../../scripts/verify-published-integrations.mjs',import.meta.url)))}}
 fs.writeFileSync(new URL('publication-mutations.json',import.meta.url),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result))
}finally{fs.rmSync(directory,{recursive:true,force:true})}
