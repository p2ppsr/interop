# ISI-4 5.4.0: prospective observer recovery

This additive engineering profile retains the same 4a954ac wallet, final SQLite-retry Go chain and 535 assertions. Coverage revision 2 corrects observer-owned identity consent, prompt scope and extension-page ownership, and preserves primary failures through cleanup. It changes no normative policy or applicability decision.

The coverage1 plan, policy bytes and failed native evidence remain immutable. This revision has a frozen source inventory and separate Rust selector binding. Native admission still requires the exact committed source, complete environment gates and two matching repetitions. No native qualification or complete BRC100 conformance is claimed.
