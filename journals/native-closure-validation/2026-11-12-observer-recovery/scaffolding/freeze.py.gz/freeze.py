"""Source freeze only, after root/evidence declared the recovery runtime stable."""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd()
def digest(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
def read(p):return json.loads((root/p).read_text())
def write(p,x):(root/p).write_text(json.dumps(x,indent=2)+'\n')
source='c648022b2d9209b7350527bd5553d73e3e82a52c'
legacy=read('out/native-closure-20261111/coverage2-scaffolding/legacy-before.json')['files']
oldpaths=subprocess.check_output(['git','ls-tree','-r','--name-only',source,'infra/native/conformance','itcves/ITCVE-1','programs/ISI-4'],text=True,cwd=root).splitlines()
oldjson=[p for p in oldpaths if p.endswith('.json')]
for p in oldjson:
 assert (root/p).read_bytes()==subprocess.check_output(['git','show',f'{source}:{p}'],cwd=root),f'Historical JSON changed: {p}'
for p,h in legacy.items():assert digest(p)==h,f'Legacy intake/plan changed: {p}'
planpath='infra/native/conformance/plan-pr368-coverage-2.json'
rustpath='infra/native/conformance/rust-graph-pr368-coverage-2.json'
reevalpath='infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-6.json'
plan=read(planpath);old=read('infra/native/conformance/plan-pr368-coverage-1.json')
assert plan['itcve']=='ITCVE-1@4.4.0' and plan['program']=='ISI-4@5.4.0' and plan['coverageRevision']==2
for field in ['wallet','walletCandidate','coverageModules','expectedObservations','compatibilityPatch','compatibilityPatchSha256','permissionFixture','permissionCoverageOracle','permissionCoverageOracleManifest']:
 assert plan[field]==old[field],field
assert read('itcves/ITCVE-1/4.4.0/profile.json')['nativeConformance']['assertions']==read('itcves/ITCVE-1/4.3.0/profile.json')['nativeConformance']['assertions']
inputs=set(plan['conformanceInputs'])
inputs.update(['synthesis/src/wallet-lab/native/failure.ts','synthesis/test/native-permission-startup.test.ts','synthesis/test/native-failure.test.ts','synthesis/test/fixtures/native5-identity-prompt.json'])
for cmd in [['git','diff','--name-only'],['git','ls-files','--others','--exclude-standard']]:
 for p in subprocess.check_output(cmd,cwd=root,text=True).splitlines():
  if (p.startswith('synthesis/src/') or p.startswith('integrations/services/src/')) and p.endswith('.ts'):inputs.add(p)
plan['conformanceInputs']={p:digest(p) for p in sorted(inputs)}
plan['admissionState']='FROZEN';plan['pendingInputs']=[]
assert 'PENDING_' not in json.dumps(plan)
write(planpath,plan)
rust=read(rustpath);rust['nativePlan']['sha256']=digest(planpath)
rust['sources']={p:digest(p) for p in rust['sources']}
assert digest(rust['predecessor']['manifest'])==rust['predecessor']['sha256']
write(rustpath,rust)
reeval=read(reevalpath)
assert reeval['sourceBindingRevision']==6 and digest(reeval['predecessor']['path'])==reeval['predecessor']['sha256']
reeval['evaluatorSources']={p:digest(p) for p in reeval['evaluatorSources']}
write(reevalpath,reeval)
for p in ['itcves/ITCVE-1/4.4.0/README.md','programs/ISI-4/5.4.0/README.md']:
 s=(root/p).read_text().replace('same4a954ac','same 4a954ac').replace('and535','and 535').replace('revision2','revision 2')
 s=s.replace('This revision is PENDING_SOURCE_FREEZE and cannot be dispatched or admitted until exact source inputs and Rust selector bindings are regenerated, reviewed and committed.', 'This revision has a frozen source inventory and separate Rust selector binding. Native admission still requires the exact committed source, complete environment gates and two matching repetitions.')
 (root/p).write_text(s)
result={'schema':'tpnil-coverage2-source-freeze@1','claim':'SOURCE_FREEZE_ONLY_NOT_NATIVE_QUALIFICATION','nativeSessions':0,'inputs':len(inputs),'sourceInputs':plan['conformanceInputs'],'originalProfileSource':source,'originalJsonFilesUnchanged':len(oldjson),'preScaffoldingLegacyFilesUnchanged':len(legacy),'plan':{'path':planpath,'sha256':digest(planpath)},'rust':{'path':rustpath,'sha256':digest(rustpath)},'reevaluation':{'path':reevalpath,'sha256':digest(reevalpath)},'wallet':plan['wallet'],'expectedNativeAssertions':535,'coverageAssertions':109,'compatibilityPatchSha256':plan['compatibilityPatchSha256']}
print(json.dumps(result,indent=2))
