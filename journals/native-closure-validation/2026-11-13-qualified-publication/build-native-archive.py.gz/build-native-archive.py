from pathlib import Path
import json,hashlib,shutil,gzip,datetime,subprocess
r=Path.cwd();source='ec3a554d433845e9aa8209d9eb20dde48cba6a2a';run=json.loads((r/'out/source19-validation/native-run.json').read_bytes())['id']
a=r/f'out/source19-ci/acquisition/{run}';intake=r/'out/source19-native-intake';replay=r/'out/source19-replay';image=r/'out/source19-image-audit';d=r/'out/source19-delivery/native-publication'
assert not d.exists();read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
acq=read(a/'acquisition.json');assert acq['source']==source and acq['conclusion']=='success'
guard=read(replay/'guarded-replay.json');ind=read(replay/'replay.json');audit=read(image/'source-reconstruction/result.json')
assert guard['source']==ind['source']==audit['source']==source and guard['exitCode']==0 and guard['guardRequired']
assert ind['result']=='VERIFIED_EXACT_SOURCE_AND_ALL_CHILDREN'and len(ind['children'])==12 and ind['originalBytesUnchanged']and ind['frozenSourceUnchanged']
assert audit['verified']and audit['allSourceCopyBytesMatch']and audit['completeRuntimeConfig']and audit['seededMissingFileRejected']
assert (replay/'original-members-before.json').read_bytes()==(replay/'original-members-after.json').read_bytes()
summary=read(intake/'intake.json');comparison=read(intake/'comparison.json');assert summary['missingOriginalQualificationOrRust']==[]
assert len(summary['repetitions'])==2 and all(x['status']=='RAW_OBSERVATIONS_ONLY'and x['assertions']==698 for x in summary['repetitions'])
native=read(intake/'original/qualification.json');integrated=read(intake/'original/integrated-qualification.json')
assert native['qualifiedEnvironment']and integrated['qualifiedEnvironment']and integrated['repetitionMatch']
assert native['source']==integrated['source']==source and integrated['profile']=='ITCVE-1@4.8.0'and integrated['program']=='ISI-4@5.8.0'
row=next(x for x in acq['files']if x.get('artifactName')=='native-go-yours-wallet-pr368-coverage6');raw=(a/row['path']).read_bytes();assert sha(raw)==row['sha256']and len(raw)<=512*1024*1024
for x in acq['files']+acq['apis']:
 b=(a/x['path']).read_bytes();assert len(b)==x['bytes']and sha(b)==x['sha256']
jobs=read(a/'jobs-api.json')['jobs'];j=next(x for x in jobs if x['name']=='all-go-native');t=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'));seconds=int((t(j['completed_at'])-t(j['started_at'])).total_seconds());assert j['conclusion']=='success'and seconds<=5400
assert all(x['conclusion']=='skipped'for x in jobs if x['id']!=j['id'])
admission=read(r/'out/source19-validation/native-dispatch/dispatch.json');prerequisiteSeconds=int(admission['prerequisiteJobSeconds']);cohortBeforeNative=int(admission['cohortBeforeNative']);totals=admission['jobSeconds'];assert sum(totals.values())==prerequisiteSeconds
cost={'order':27,'source':source,'nativeRun':run,'nativeJobSeconds':seconds,'PRFoundationJobSeconds':totals[str(admission['PRFoundation'])],'duplicateCanceledJobSeconds':totals[str(admission['duplicatePushCanceled'])],'retainedReevaluationJobSeconds':totals[str(admission['reevaluationPASS'])],'order27JobSeconds':prerequisiteSeconds+seconds,'completedCohortJobSecondsBeforeOrder27':89739,'completedCohortJobSeconds':cohortBeforeNative+seconds,'fullCostReconciled':False,'unknownCostsAreZero':False,'costUSD':{k:None for k in ['actualCICharge','storageEgress','operatorEffort','developmentAgentUsage','allocatedOwnedCapacity','totalFullCost']}}

d.mkdir();parts=[]
if len(raw)>40*1024*1024:
 for offset in range(0,len(raw),40*1024*1024):
  name=f'native-integrated.zip.part-{len(parts):03d}';(d/name).write_bytes(raw[offset:offset+40*1024*1024]);parts.append(name)
else:(d/'native-integrated.zip').write_bytes(raw)
for old,new in [('run-api.json','run.json'),('jobs-api.json','jobs.json'),('artifacts-api.json','artifacts.json'),('acquisition.json','acquisition.json'),('run-logs.zip','native-logs.zip')]:shutil.copyfile(a/old,d/new)
imageRow=next(x for x in acq['files']if x.get('artifactName')=='native-image-filesystem-audit');shutil.copyfile(a/imageRow['path'],d/'native-image-audit.zip')
(d/'native-job.log.gz').write_bytes(gzip.compress((a/f"job-{j['id']}.log").read_bytes(),mtime=0))
for old,new in [(intake/'original/integrated-qualification.json','qualification.json'),(intake/'original/qualification.json','native-qualification.json'),(intake/'comparison.json','comparison.json'),(intake/'intake.json','intake.json'),(intake/'original-member-inventory.json','native-members.json'),(image/'replay.json','independent-image-replay.json'),(image/'source-reconstruction/result.json','independent-image-source-reconstruction.json'),(image/'source-reconstruction/linux-storage-manifest.json','linux-storage-manifest.json'),(image/'source-reconstruction/manifest-binding.json','linux-manifest-binding.json'),(replay/'source/infra/native/conformance/plan-pr368-coverage-6-source-9.json','plan.json'),(replay/'source/infra/native/conformance/rust-graph-pr368-coverage-6-source-9.json','rust-compatibility.json')]:shutil.copyfile(old,d/new)
(d/'cost.json').write_text(json.dumps(cost,indent=2)+'\n');inddir=d/'independent';inddir.mkdir()
names=['guarded-replay.json','replay.json','source-inventory.json','original-members-before.json','original-members-after.json','dependency-byte-closure-v3.json','dependency-guard-tests-v3.json','package-byte-audit.json','messaging-sdk-byte-closure.json','rust-dependency-byte-closure.json','cache-isolation.json','dependencies.json','preparation-lineage.json','guarded-replay.mjs','replay-when-authorized.mjs','replay-dependency-guard-v3.sb','prepare.mjs','inventory.py','controller-preflight.json']
for n in names:shutil.copyfile(replay/n,inddir/n)
for old,new in [(image/'verify.mjs','image-verification-controller.mjs'),(image/'source-reconstruction/reconstruct.py','linux-manifest-binding-controller.py'),(image/'source-reconstruction/reconstruct.mjs','image-source-reconstruction-controller.mjs')]:shutil.copyfile(old,inddir/new)
early=r/'out/source19-image-early';earlydir=inddir/'early-image';earlydir.mkdir()
for name in ['replay.json','acquisition.json','artifacts-api.json','verify.mjs','capture.py','native-inputs.json']:shutil.copyfile(early/name,earlydir/name)
observer=r/'out/source19-validation';observerdir=inddir/'admission-observers';observerdir.mkdir()
for name in ['dispatch-native.stdout','dispatch-native.stderr','monitor-native.stdout','monitor-native.stderr','after-prerequisites.controller.stdout','after-prerequisites.controller.stderr']:
 shutil.copyfile(observer/name,observerdir/name)
for name in ['start-reevaluation.py','reevaluation-dispatch.json','reevaluation-dispatch.stdout','reevaluation-dispatch.stderr','read-status.py','monitor-prerequisites.controller.stdout','monitor-prerequisites.controller.stderr','after-reevaluation.controller.stdout','after-reevaluation.controller.stderr','watch-native.controller.stdout','watch-native.controller.stderr']:
 if(observer/name).exists():shutil.copyfile(observer/name,observerdir/name)
preflightdir=inddir/'source-preflight';preflightdir.mkdir()
for name in ['history-commit.json','history-index-tree.json','history-index.log','committed-selector.json','admit-order27.py','commit.stdout','push.log','prepare-pipeline.py']:
 shutil.copyfile(r/'out/source19-preflight'/name,preflightdir/name)
for name in ['native-dispatch','cancelled-job-status-preflight']:
 if(observer/name).exists():shutil.copytree(observer/name,observerdir/name)
shutil.copyfile(observer/'dispatch-native.py',observerdir/'dispatch-controller.py')
shutil.copyfile(observer/'monitor-native.py',observerdir/'monitor-controller.py')
for p in replay.glob('*.log'):(inddir/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in image.glob('*.stdout'):(inddir/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in image.glob('*.stderr'):(inddir/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
rows='\n'.join(f"| {x['repetition']} | {x['counts'].get('PASS',0)} | {x['counts'].get('FAIL',0)} | {x['counts'].get('BLOCKED',0)} |"for x in summary['repetitions'])
(d/'README.md').write_text(f'''# Qualified expanded native engineering profile

[Native run {run}](https://github.com/p2ppsr/interop/actions/runs/{run}) at source `{source}` completed two clean ITCVE-1 4.8 / ISI-4 5.8 repetitions using the exact e360e67 engineering candidate and Go-backed services. The original native and integrated qualification receipts are retained. Environment qualification permits genuine FAIL and BLOCKED observations; complete BRC-100 conformance and certification remain unavailable.

| Repetition | PASS | FAIL | BLOCKED |
| --- | ---: | ---: | ---: |
{rows}

Each repetition retains all 698 native observations, 77 integration checks and 48 actual Rust checks. The comparison maps every original obligation, preserves the original 99-failure denominator and reports regressions and additional coverage explicitly. Original-failure outcomes: `{json.dumps(comparison['originalFailureOutcomes'])}`. Original coverage gate: `{comparison['originalBlockedGate']['after']}`. Regressions: {len(comparison['regressions'])}.

Independent replay used the frozen source, an empty Rust target and temporary directory, pinned tools, byte-verified dependencies and the mandatory dependency sandbox. The parent and all 12 child verifiers passed; original artifact members and frozen source bytes remained unchanged. The independent image audit verifies all {audit['finalEntries']} filesystem entries, complete inherited runtime configuration, two added layers and every source COPY, with the Linux Go manifest bound to its original job log. A seeded missing source file was rejected.

The original native ZIP is retained byte-for-byte, split into ordered bounded parts when needed. `python3 verify.py` checks its complete member inventory, GitHub artifact digest, public receipt copies and physical archive. The repository's `node scripts/verify-published-integrations.mjs --semantic` performs the separate frozen-source semantic replay after the documented dependency preparation.

Native job use was {seconds} seconds. Order 27 used {prerequisiteSeconds+seconds} job-seconds including passing PR CI, the canceled duplicate and retained reevaluation; completed cohort use is {cohortBeforeNative+seconds}. Full monetary, operator, agent and allocated owned-capacity costs remain unknown. Earlier failed samples remain in their separate immutable archives.
''')
verifier='''from pathlib import Path
import json,hashlib,zipfile,io,datetime
r=Path(__file__).resolve().parent;m=json.loads((r/'provenance.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
assert {str(p.relative_to(r))for p in r.rglob('*')if p.is_file()}=={x['path']for x in m['files']}|{'provenance.json'}
for x in m['files']:
 b=(r/x['path']).read_bytes();assert len(b)==x['size']and sha(b)==x['sha256'],x['path']
spec=m.get('archiveParts');raw=b''.join((r/n).read_bytes()for n in spec['parts'])if spec else(r/'native-integrated.zip').read_bytes()
if spec:assert len(raw)==spec['size']and sha(raw)==spec['sha256']and all(0<(r/n).stat().st_size<=64*1024*1024 for n in spec['parts'])
assert len(raw)<=512*1024*1024;api=json.loads((r/'artifacts.json').read_bytes());artifact=next(x for x in api['artifacts']if x['id']==m['artifactId']);assert len(raw)==artifact['size_in_bytes']and'sha256:'+sha(raw)==artifact['digest']
members=json.loads((r/'native-members.json').read_bytes())
with zipfile.ZipFile(io.BytesIO(raw))as z:
 assert {x.filename for x in z.infolist()if not x.is_dir()}=={x['path']for x in members}
 for x in members:
  b=z.read(x['path']);assert len(b)==x['bytes']and sha(b)==x['sha256']
 assert z.read('integrated-qualification.json')==(r/'qualification.json').read_bytes()
 assert z.read('qualification.json')==(r/'native-qualification.json').read_bytes()
q=json.loads((r/'qualification.json').read_bytes());assert q['qualifiedEnvironment']and q['repetitionMatch']and q['source']==m['source']and q['profile']=='ITCVE-1@4.8.0'
guard=json.loads((r/'independent/guarded-replay.json').read_bytes());replay=json.loads((r/'independent/replay.json').read_bytes());assert guard['exitCode']==0 and guard['source']==m['source']and replay['result']=='VERIFIED_EXACT_SOURCE_AND_ALL_CHILDREN'and len(replay['children'])==12 and replay['originalBytesUnchanged']and replay['frozenSourceUnchanged']
assert(r/'independent/original-members-before.json').read_bytes()==(r/'independent/original-members-after.json').read_bytes()
jobs=json.loads((r/'jobs.json').read_bytes())['jobs'];j=next(x for x in jobs if x['name']=='all-go-native');t=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'));seconds=int((t(j['completed_at'])-t(j['started_at'])).total_seconds());cost=json.loads((r/'cost.json').read_bytes());assert seconds==cost['nativeJobSeconds']and cost['order27JobSeconds']==1693+seconds and cost['completedCohortJobSeconds']==60017+seconds
print(json.dumps({'verified':True,'source':m['source'],'members':len(members),'nativeJobSeconds':seconds,'physicalIntegrityOnly':True}))
'''
verifier=verifier.replace('1693',str(prerequisiteSeconds)).replace('60017',str(cohortBeforeNative))
(d/'verify.py').write_text(verifier)
m={'schema':'tpnil-integrated-native-archive@1','source':source,'workflowRun':run,'artifactId':row['artifactId'],'files':[{'path':str(p.relative_to(d)),'size':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(d.rglob('*'))if p.is_file()]}
if parts:m['archiveParts']={'path':'native-integrated.zip','size':len(raw),'sha256':sha(raw),'parts':parts}
(d/'provenance.json').write_text(json.dumps(m,indent=2)+'\n');subprocess.run(['python3',str(d/'verify.py')],check=True);print(json.dumps({'directory':str(d),'provenanceSha256':sha((d/'provenance.json').read_bytes()),'cost':cost,'nativeRepetitions':[{k:x[k]for k in ['repetition','counts','original99']}for x in summary['repetitions']]}))
