from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();read=lambda p:json.loads(p.read_bytes());h=r/'out/source19-delivery';d=h/'native-publication';m=read(d/'provenance.json');cost=read(d/'cost.json');summary=read(d/'intake.json');comparison=read(d/'comparison.json');audit=read(d/'independent-image-source-reconstruction.json');guard=read(d/'independent/guarded-replay.json');replay=read(d/'independent/replay.json');q=read(d/'qualification.json');nq=read(d/'native-qualification.json');assert q['qualifiedEnvironment']and nq['qualifiedEnvironment']and guard['exitCode']==0 and replay['result']=='VERIFIED_EXACT_SOURCE_AND_ALL_CHILDREN'and len(replay['children'])==12 and audit['verified']
source=m['source'];run=m['workflowRun'];assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==source
native=r/f'journals/integrated-native-qualification/2026-11-13/{run}';assert not native.exists();native.parent.mkdir(parents=True,exist_ok=True)
import shutil
shutil.copytree(d,native)
rows='\n'.join(f"| {x['repetition']} | {x['counts'].get('PASS',0)} | {x['counts'].get('FAIL',0)} | {x['counts'].get('BLOCKED',0)} |"for x in summary['repetitions'])
ci=read(r/'out/source19-ci/publication/summary.json');rr=read(r/'out/source19-reevaluation-replay/publication/provenance.json')
for src,dst in [(r/'out/source19-ci/publication',r/f"journals/source-ci/2026-11-13/{ci['run']}"),(r/'out/source19-ci/duplicate-publication',r/f"journals/source-ci/2026-11-13/{ci['duplicateCanceledRun']}"),(r/'out/source19-reevaluation-replay/publication',r/f"journals/native-integrated-reevaluation/2026-11-13/{rr['workflowRun']}")]:
 assert not dst.exists();dst.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(src,dst)
text=f"""# Go-backed native qualification: 13 November 2026

[Native20 run {run}](https://github.com/p2ppsr/interop/actions/runs/{run}) qualifies the scoped ITCVE-1@4.8.0 / ISI-4@5.8.0 engineering environment at source `{source}`. Both original qualification receipts, two original Rust results and the [complete immutable evidence archive](../{native.relative_to(r)}/README.md) are retained.

| Repetition | PASS | FAIL | BLOCKED |
| --- | ---: | ---: | ---: |
{rows}

Each clean repetition executes all 698 native predicates, 77 integration predicates and 48 Rust graph-oracle predicates. The original 99-failure denominator maps to `{json.dumps(comparison['originalFailureOutcomes'])}`. The original blocked coverage gate remains `{comparison['originalBlockedGate']['after']}`; regressions: {len(comparison['regressions'])}. Environment qualification means complete, reproducible scoped evidence. Complete BRC-100 conformance and certification remain unproven.

## Artifacts and integration

The exact Yours Wallet candidate is [5.1.1-pr368.e360e67](../fixtures/artifacts/yours-wallet-pr368-e360e67/README.md), source `e360e67876be2eadbf5caf2a4fd6d401fce64569`, ZIP SHA-256 `553b6df9a43714c5b4c708fac2a00eed2c77e4c26047edcd70456df5eaeaf0da`. Its candidate CI passes 269 tests with 1,839 expectations and all four bundles. [Wallet PR368](https://github.com/yours-org/yours-wallet/pull/368) remains unmerged.

The lab supports Go Overlay Services, Go ChainTracks and Go Wallet Storage, all eight TS/Go selections and mixed replacement. The integrated graph includes TS/Go Message Box, bidirectional GASP, identity discovery and trust, relay/402, UHRP/CHIRP/LCH, native permission/storage/transaction/certificate coverage and independent Rust verification. The source-bound component matrix retains 584 PASS and six upstream Go Messaging FAIL observations among 590 assertions; complete evidence verification passes.

[Go11](native-go-serialization-artifact-correction-2026-11-13.md) extends the full Go10 host and SDK lineage with deterministic ancestry root traversal. Native19 exposed two byte-different inputBEEF arrays containing identical raw transactions and proofs. Its failed artifact remains unchanged. Go11 passes 512 captured-graph permutations and round-trips, the full SDK/host/storage/wallet/RPC suites, 12 artifact mutation controls and nine direct authenticated replacement/source-outage checks. Native20 uses the fresh Go11 artifact; no prior failed observation is rescored.

## Independent verification

Original native and integrated qualification receipts agree across two repetitions. Mandatory sandboxed replay executes the frozen source parent and all 12 independent child verifiers, including actual Rust execution. It retains every original member and frozen source byte. The independently reconstructed image verifies all {audit['finalEntries']} final entries and {audit['sourceOverlayEntries']} source overlay entries, all source COPY bytes, complete inherited runtime configuration, the Linux Go build manifest and a seeded missing-source rejection.

[Source9 PR CI {ci['run']}](https://github.com/p2ppsr/interop/actions/runs/{ci['run']}) passes 236 Linux core tests with one explicit skip, 1,831 synthesis tests with 126 explicit skips, five Python and 13 Go matrix tests, plus the nine Go11 replacement predicates. The earlier source8 prerequisite sample retains one 30-second mutation-test timeout; source9 bounds CI cryptographic workers to two with the same timeout and every assertion unchanged. No native session ran in the failed prerequisite allocation. Local source validation passes 237 core and 1,865 synthesis tests with 92 explicit skips, typecheck, catalogs and standards. The 50 focused selector/image/extractor/reevaluation/archive controls overlap these suites and are not additional totals. [Evaluator11 {rr['workflowRun']}](https://github.com/p2ppsr/interop/actions/runs/{rr['workflowRun']}) and independent frozen replay preserve the original 186-member baseline, 280 native / 77 integrated / 48 Rust criteria, and every original finding with zero new native sessions.

## Remaining findings and cost

The signed-satoshi UInt64 listActions mismatch remains FAIL. Twelve BLOCKED observations retain the broader coverage gates, conflicting-remittance interpretation, basket boundary conflict, whole-cache absence, legacy partial-trace returnTXIDOnly behavior and complete action inventory at the query cut. They require applicable evidence or a separately governed interpretation; current environment qualification does not waive them. The six upstream Go Messaging matrix failures also remain explicit.

Native20 uses {cost['nativeJobSeconds']} job-seconds. Order27 uses {cost['order27JobSeconds']} job-seconds including PR CI, canceled duplicate and retained reevaluation. Completed cohort use is {cost['completedCohortJobSeconds']}, including failed attempts. Final publication CI has a separate bounded work order and is recorded with its actual head in the PR and operations closeout. Monetary charges, operator effort, development-agent usage and allocated owned-capacity costs remain unknown. No accepted-pack cost or measured economic improvement is asserted.

Run `python3 {native.relative_to(r)}/verify.py` for physical archive integrity. `node scripts/verify-published-integrations.mjs --semantic` independently replays accepted archives from frozen source after locked dependency preparation. These commands do not launch another native session. Earlier failures and their original receipts remain in [prior results](native-conformance-results-2026-11-12.md) and append-only journals.
"""
(r/'docs/native-conformance-results-2026-11-13.md').write_text(text)
p=r/'.gitattributes';s=p.read_text();assert 'journals/** linguist-generated=true'not in s;p.write_text(s+'journals/** linguist-generated=true\n')
p=r/'docs/implementation-status.md';s=p.read_text();lines=s.splitlines();i=next(i for i,x in enumerate(lines)if x.startswith('| Yours Wallet candidate completion |'));lines[i]=f'| Yours Wallet candidate completion | [November13 qualification](native-conformance-results-2026-11-13.md): source9 / Go11 qualifies ITCVE-1@4.8 / ISI-4@5.8 with the exact e360e67 candidate. Both clean repetitions retain all 698 native observations, 77 integration and 48 Rust checks; original receipts, mandatory frozen parent plus 12 child replay and complete image reconstruction pass. Original99 map to 98 PASS / one signed-satoshi FAIL. Twelve coverage/interpretation blockers and six upstream Go Messaging matrix findings remain explicit. Complete BRC100 conformance and certification remain unproven; prior failed evidence stays unchanged |';p.write_text('\n'.join(lines)+'\n')
print(json.dumps({'nativeArchive':str(native.relative_to(r)),'source':source,'run':run,'cost':cost}))
