from pathlib import Path
import json,subprocess,datetime,time
r=Path.cwd();h=r/'out/source19-delivery/final-ci';h.mkdir(exist_ok=False);op=Path('/Users/tyeverett/projects/network-ops/artifacts/ops/itcve-native-closure-20261111/attempt-28-final-publication-order/work-order.json');o=json.loads(op.read_bytes());source=o['source'];t=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'));previous={};canceled=set()
def api(p):
 for attempt in range(5):
  x=subprocess.run(['gh','api','repos/p2ppsr/interop/'+p],capture_output=True,timeout=45)
  if x.returncode==0:return json.loads(x.stdout)
  (h/f'api-error-{time.time_ns()}.json').write_text(json.dumps({'endpoint':p,'exitCode':x.returncode,'stderr':x.stderr.decode(errors='replace'),'workflowRerun':False},indent=2)+'\n')
  if attempt==4:raise RuntimeError('Read-only observer failed five times; inspect preserved evidence')
  time.sleep(3)
while True:
 now=datetime.datetime.now(datetime.timezone.utc);raw=api('actions/runs?head_sha='+source+'&per_page=100');runs=raw['workflow_runs'];(h/'runs.json').write_text(json.dumps(raw,indent=2)+'\n');assert len(runs)<=2
 pr=api('pulls/26');(h/'pr-current.json').write_text(json.dumps(pr,indent=2)+'\n');merge=None
 if pr['head']['sha']==source and pr['merge_commit_sha']:
  assert pr['draft']and pr['base']['sha']==o['draftPR']['baseSource'];m=api('git/commits/'+pr['merge_commit_sha'])
  if {p['sha']for p in m['parents']}=={source,o['draftPR']['baseSource']}:
   assert m['tree']['sha']==o['sourceTree'];merge=m;(h/'synthetic-commit.json').write_text(json.dumps(m,indent=2)+'\n')
 rows=[]
 for run in runs:
  assert run['name']=='Foundation checks'and run['event']in['push','pull_request']and run['head_sha']==source and run['run_attempt']==1
  rawJobs=api(f"actions/runs/{run['id']}/jobs?per_page=100");jobs=rawJobs['jobs'];(h/f"{run['id']}-run.json").write_text(json.dumps(run,indent=2)+'\n');(h/f"{run['id']}-jobs.json").write_text(json.dumps(rawJobs,indent=2)+'\n');duplicate=run['event']=='push';limit=300 if duplicate else 4800;total=0;stop=duplicate or now>=t(o['deadline'])
  for j in jobs:
   if j['started_at']and j['conclusion']!='skipped':
    n=((t(j['completed_at'])if j['completed_at']else now)-t(j['started_at'])).total_seconds();total+=n
    if n>o['workflowLimits']['Foundation checks']['jobs'][j['name']]:stop=True
  if total>limit:stop=True
  if stop and run['status']!='completed'and run['id']not in canceled:
   x=subprocess.run(['gh','api','-X','POST',f"repos/p2ppsr/interop/actions/runs/{run['id']}/cancel"],capture_output=True);(h/f"{run['id']}-cancellation.json").write_text(json.dumps({'at':now.isoformat(),'run':run['id'],'reason':'Duplicate push'if duplicate else'Order deadline or bound','exitCode':x.returncode},indent=2)+'\n');assert x.returncode==0;canceled.add(run['id'])
  state=(run['status'],run['conclusion'],[(j['name'],j['conclusion'],[s['name']for s in j['steps']if s['status']=='in_progress'])for j in jobs])
  if previous.get(run['id'])!=state:print(json.dumps({'at':now.isoformat(),'run':run['id'],'event':run['event'],'state':state}),flush=True);previous[run['id']]=state
  rows.append({'run':run['id'],'event':run['event'],'conclusion':run['conclusion'],'status':run['status'],'jobSeconds':int(total)})
 if len(rows)==2 and all(x['status']=='completed'for x in rows):
  assert merge and all(x['conclusion']==('cancelled'if x['event']=='push'else'success')for x in rows);d={'source':source,'sourceTree':o['sourceTree'],'runs':rows,'jobSeconds':sum(x['jobSeconds']for x in rows),'syntheticCommit':merge['sha'],'syntheticTree':merge['tree']['sha'],'qualifiedNativeSource':o['qualifiedNativeSource'],'qualifiedNativeRun':o['qualifiedNativeRun'],'nativeInputsUnchanged':471,'nativeSessions':0,'cohortCompletedJobSeconds':o['completedCohortJobSecondsBefore']+sum(x['jobSeconds']for x in rows)};(h/'completion.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);break
 time.sleep(25)
