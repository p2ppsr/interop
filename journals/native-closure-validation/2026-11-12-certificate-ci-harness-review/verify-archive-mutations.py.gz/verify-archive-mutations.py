from pathlib import Path
import copy,gzip,hashlib,json,shutil,subprocess
root=Path.cwd();base=root/'out/native-closure-20261111/ci-source-map-review';source=root/'journals/native-closure-validation/2026-11-12-certificate-ci-harness';parent=root/'out/ci-harness-archive-adversarial';parent.mkdir(exist_ok=True);target=parent/'fixture';shutil.rmtree(target,ignore_errors=True);shutil.copytree(source,target);original={str(p.relative_to(target)):p.read_bytes() for p in target.rglob('*') if p.is_file()};sha=lambda b:hashlib.sha256(b).hexdigest();results=[]
def reset():
 shutil.rmtree(target);shutil.copytree(source,target)
def manifest(fn):
 p=target/'validation.json';v=json.loads(p.read_text());fn(v);p.write_text(json.dumps(v,indent=2)+'\n')
def raw_digest(fn):manifest(lambda d:fn(d['files'][0]))
def check(name,fn):
 reset();fn();r=subprocess.run(['python3',str(target/'verify.py')],cwd=root,text=True,capture_output=True);assert r.returncode!=0,name;results.append({'name':name,'exitCode':r.returncode,'rejected':True,'stdout':r.stdout,'stderr':r.stderr})
check('changed_stored_member',lambda:(target/'README.md').write_bytes(original['README.md']+b'tamper'))
check('missing_member',lambda:(target/'README.md').unlink())
check('extra_member',lambda:(target/'extra.txt').write_text('extra'))
check('duplicate_manifest_member',lambda:manifest(lambda d:d['files'].append(copy.deepcopy(d['files'][0]))))
check('unsafe_path',lambda:raw_digest(lambda d:d.update(path='../outside')))
check('decoded_digest_mismatch',lambda:raw_digest(lambda d:d.update(rawSha256='0'*64)))
check('false_native_claim',lambda:manifest(lambda d:d.update(nativeSessions=1)))
check('changed_runtime_input',lambda:manifest(lambda d:d['runtimeInputs'].update({next(iter(d['runtimeInputs'])):'0'*64})))
check('changed_plan_binding',lambda:manifest(lambda d:d['nativePlan'].update(sha256='0'*64)))
check('inflated_final_count',lambda:manifest(lambda d:d['finalResults']['fullSynthesis'].update(passed=1082)))
check('omitted_reviewed_failure',lambda:manifest(lambda d:d['reviewBindings'].pop(next(iter(d['reviewBindings'])))))
shutil.rmtree(target)
assert all((source/n).read_bytes()==b for n,b in original.items())
report={'schema':'tpnil-certificate-ci-archive-mutation-review@1','claim':'LOCAL_ARCHIVE_INTEGRITY_CHECK_ONLY','nativeSessions':0,'archiveManifestSha256':sha((source/'validation.json').read_bytes()),'sourceArchiveUnchanged':True,'positiveReceiptSha256':sha((base/'archive-verification.json').read_bytes()),'negativeControls':results,'scriptSha256':sha(Path(__file__).read_bytes()),'result':'PASS'};(base/'archive-mutation-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'result':'PASS','negativeControls':len(results),'receiptSha256':sha((base/'archive-mutation-review.json').read_bytes()),'manifestSha256':report['archiveManifestSha256']},indent=2))
