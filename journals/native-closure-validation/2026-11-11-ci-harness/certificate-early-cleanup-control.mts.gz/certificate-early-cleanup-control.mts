import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {ControlledWalletServices} from '../../synthesis/src/wallet-lab/services.ts'
import {createFixtureWallet} from '../../synthesis/src/storage-sync/fixture-wallet.ts'
const directory=fs.mkdtempSync(path.join(fs.realpathSync(os.tmpdir()),'tpnil-teardown-repro-')),services=new ControlledWalletServices({webroot:directory});let wallet:any, failure:any, servicesClosed=false
try{
 await services.start();wallet=await createFixtureWallet(services,'77'.repeat(32));await wallet.listCertificates({certifiers:[],types:[],limit:10})
 const start=Date.now(); // Close the remote resources while their authenticated connection is active
 try{await wallet.destroy();await services.close();servicesClosed=true;const replayStart=Date.now();while(Date.now()-replayStart<9000){};console.log(JSON.stringify({destroy:'PASS',blockedFor:Date.now()-start}))}catch(e){failure=e;console.log(JSON.stringify({destroy:'FAIL',blockedFor:Date.now()-start,error:String(e),cause:String((e as any).cause)}))}
}finally{try{if(!servicesClosed)await services.close()}finally{fs.rmSync(directory,{recursive:true,force:true})}}
if(failure)process.exitCode=1
