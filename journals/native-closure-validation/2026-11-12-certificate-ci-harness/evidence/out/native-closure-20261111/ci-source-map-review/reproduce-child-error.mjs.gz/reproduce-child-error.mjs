import fs from 'node:fs';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {parseErrorStacktrace} from '../../../synthesis/node_modules/@vitest/utils/dist/source-map.js';
import {extractSourcemapFromFile} from '../../../synthesis/node_modules/@vitest/utils/dist/source-map/node.js';
const base=path.resolve('out/native-closure-20261111/ci-source-map-review'),snapshot=path.join(base,'dependency-absent-2');
const args=['--import',path.join(snapshot,'synthesis/node_modules/tsx/dist/loader.mjs'),path.join(snapshot,'synthesis/src/wallet-lab/native/coverage-certificates-reference.ts'),path.join(base,'dependency-absent-execfile-output')];
const start=Date.now();let child;
try{await promisify(execFile)(process.execPath,args,{cwd:snapshot,timeout:120000,maxBuffer:16*1024*1024});throw Error('Expected missing dependency')}catch(error){child=error;}
if(child.code!==1||!child.stderr.includes("Cannot find module 'mongodb-memory-server'"))throw Error('Wrong reproduction failure');
fs.writeFileSync(path.join(base,'execfile.raw-stack.log'),child.stack);fs.writeFileSync(path.join(base,'execfile.stdout.log'),child.stdout);fs.writeFileSync(path.join(base,'execfile.stderr.log'),child.stderr);
const lookups=[];const getSourceMap=file=>{lookups.push(file);if(fs.existsSync(file))return extractSourcemapFromFile(fs.readFileSync(file,'utf8'),file)?.map;};
let masked;
try{parseErrorStacktrace(child,{getSourceMap});throw Error('Expected masked parser failure')}catch(error){masked={name:error.name,message:error.message};}
const safe=new Error(`Certificate reference child failed (code=${child.code},signal=${child.signal},killed=${child.killed}); raw stdout/stderr retained; stderr=${JSON.stringify(child.stderr)}`);
const safeFrames=parseErrorStacktrace(safe,{getSourceMap});
if(masked.message!==`Unexpected token '�', "�" is not valid JSON`||!safeFrames.length||!safe.message.includes('mongodb-memory-server'))throw Error('Control failed');
const sha=b=>createHash('sha256').update(b).digest('hex');
console.log(JSON.stringify({schema:'tpnil-actual-child-error-rendering-reproduction@1',claim:'LOCAL_DEPENDENCY_REPRODUCTION_ONLY',nativeSessions:0,source:'7bd1480037ddc064f5a8cb2f567f6e58285c5999',node:process.version,elapsedMs:Date.now()-start,child:{code:child.code,signal:child.signal,killed:child.killed,stackSha256:sha(child.stack),stderrSha256:sha(child.stderr)},masked,lookups,safeFailure:{retainsMissingDependencyMessage:safe.message.includes('mongodb-memory-server'),frameCount:safeFrames.length,frames:safeFrames},scriptSha256:sha(fs.readFileSync(import.meta.filename))},null,2));
