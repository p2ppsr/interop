process.stdout.write('before expected missing dependency'); require('__tpnil_intentionally_missing_reference_dependency__')
