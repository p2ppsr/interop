from pathlib import Path
import datetime,hashlib,json,subprocess,shutil
root=Path(__file__).resolve().parents[2]
ops=Path('/Users/tyeverett/projects/network-ops')
out=ops/'artifacts/ops/itcve-native-closure-20261111/attempt-5-order'
assert not out.exists(), 'Do not rewrite an existing execution order'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
planpath='infra/native/conformance/plan-pr368-coverage-1.json'
rustpath='infra/native/conformance/rust-graph-pr368-coverage-1.json'
reevalpath='infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-5.json'
plan=read(root/planpath)
assert plan['admissionState']=='FROZEN'
for p,h in plan['conformanceInputs'].items():
 assert sha(root/p)==h and hashlib.sha256(subprocess.check_output(['git','show',f'{commit}:{p}'],cwd=root)).hexdigest()==h,p
validationpath='journals/native-closure-validation/2026-11-12-coverage1/validation.json'
validation=read(root/validationpath)
assert validation['nativeSessions']==0
now=datetime.datetime.now(datetime.timezone.utc)
order={
 'schema':'network-ops-native-closure-execution-order@1','attempt':5,'status':'COMMITTED_LOCAL_SOURCE_VALIDATED_BEFORE_PUSH',
 'createdAt':now.isoformat(),'source':commit,'branch':'codex/native-wallet-closure-20261111',
 'deadline':(now+datetime.timedelta(hours=3)).isoformat(),
 'cancellationOwner':'acting network-ops operator agent; delegated cost reviewer tracks all jobs and elapsed limits',
 'question':'Measure exact4a954ac native wallet and finalGo storage with fresh-state permissions and109 additional coverage predicates; preserve original99 and all historical outcomes.',
 'changedHypothesis':[
  'Final source-owned wallet validators enforce UTF8 and normalized identifiers and preserve public discovery permission arguments.',
  'Go changes preserve batch subjects, actual dust debit, merged credits, complete caller input ancestry, and bounded typed SQLITE_BUSY_SNAPSHOT rollback/retry.',
  'Valid Board/identity fixture namespaces restore the blocked native integration path.',
  'Independent initial three10000-satoshi output snapshot and early public permission modules establish exact100-satoshi fee-inclusive allowance without refills/private grants.',
  'Four added modules observe permission scope/restarts/concurrency, transaction lifecycle/proofs/merges, namespaces/crypto/queries, and independent-issuer certificates.',
  'Independent parent joins all five browser contexts, public bytes, owned provider snapshots, signatures/funding and complete postclose ledgers; standards conflicts remain strict.'
 ],
 'customerTask':'Native Yours install/onboarding, fresh public permission prelude, ToDo create/cold reload/redeem, remaining public CWI integration/conformance scenarios, and complete shutdown.',
 'variant':'integrated-native-conformance-pr368-coverage-1','profile':plan['itcve'],'program':plan['program'],
 'claim':'ENGINEERING_OBSERVATION_ONLY','completeBRC100Conformance':False,
 'plan':planpath,'planSha256':sha(root/planpath),'rustCompatibility':rustpath,'rustCompatibilitySha256':sha(root/rustpath),
 'wallet':plan['wallet'],'walletOfficialRelease':False,'walletCandidate':plan['walletCandidate'],
 'application':plan['application'],'storagePatchLock':plan['compatibilityPatch'],'storagePatchLockSha256':sha(root/plan['compatibilityPatch']),
 'repetitions':2,'timeoutSecondsPerRepetition':1500,'containerGraceSecondsPerRepetition':60,'workflowTimeoutMinutes':70,
 'observationsPerRepetition':535,'originalFailureComparisonDenominator':99,'maximumNativeWorkflowRuns':1,'automaticRetries':0,'maximumNativeJobSeconds':4200,
 'executionTimeEnvelope':{'maximumRepetitionExecutionAndGraceSeconds':3120,'setupVerificationUploadReserveSeconds':1080,'totalNativeJobSeconds':4200,'ceilingNotTarget':True},
 'automaticValidationEnvelope':{
  'maximumSourcePushes':1,
  'foundation':{'workflow':'.github/workflows/ci.yml','trigger':'push','maximumWorkflowRuns':1,'jobs':[{'name':'offline-core','timeoutMinutes':10,'maximumJobSeconds':600},{'name':'go-components','timeoutMinutes':20,'maximumJobSeconds':1200},{'name':'integrated-components','timeoutMinutes':40,'maximumJobSeconds':2400}],'maximumTotalJobSeconds':4200},
  'retainedReevaluation':{'workflow':'.github/workflows/native-evidence-reevaluation.yml','trigger':'push','plan':reevalpath,'planSha256':sha(root/reevalpath),'maximumWorkflowRuns':1,'job':'retained-native-evidence','timeoutMinutes':20,'maximumJobSeconds':1200,'freshNativeExecutions':0},
  'maximumAutomaticCIJobSeconds':5400,'maximumCombinedNewJobSeconds':9600,
  'additionalPRorPublicationPushRunsIncluded':False,'additionalRunsRule':'Any further push, PR trigger or rerun requires a separate recorded bounded allowance.'
 },
 'cost':{'completedNewCohortJobSecondsBeforePush':14252,'historicalCohortJobSeconds':20670,'priorNativeFailuresRetained':True,'newPaidCapacity':False,'newMonetaryReservationUSD':0,'actualCIChargeUSD':None,'operatorEffortUSD':None,'developmentAgentUsageUSD':None,'allocatedOwnedCapacityUSD':None,'artifactStorageAndTransferUSD':None,'fullMoneyWorstCaseQuoteUSD':None,'unknownCostsAreZero':False,'spendingBlockDeployed':False,'savingClaim':False,'minimum32FoldImprovement':'UNMEASURED','note':'Known job-time bounds are not a monetary quote. Unknown allocated subscription/owned capacity/operator/agent/storage costs remain unreconciled. No new paid capacity, subscription, device lease or mainnet payment.'},
 'fidelity':'Linux/amd64 native Chromium extension with sandbox/network-none, two fresh containers/profiles/identities, exact wallet/app bytes, pinned actual Go services and controlled mined funding proof; no physical-device or official-release claim.',
 'publicMainnetBroadcast':False,
 'funding':{'fixture':'fixtures/teranode/wab-funding-v1.json','reserves':plan['fundingReserves'],'permissionFixture':plan['permissionFixture'],'extraFundingBeyondFrozenPlan':False},
 'requiredBeforeAdmission':['Exact committed source inputs and wallet intake all match independently reviewed hashes.','Network-ops master work order pushed and remote equality verified before interop push.','Interop local/remote source equality and clean input inventory before dispatch.','Final local checks and bounded automatically triggered CI pass before native dispatch.','Watch all job/time limits and absolute deadline through artifacts and cleanup.'],
 'stopConditions':['Source/artifact/policy/hash mismatch or missing preflight.','Sandbox/isolation failure, uncontrolled destination or public broadcast.','Denied-payment/protected-spend safety leak, incomplete final ledger or uncertain cleanup.','Repetition exceeds1500seconds plus60cleanup, native job exceeds4200seconds, per-CI job bound, or absolute deadline reached.','Missing source-bound evidence; no automatic retries or converting FAIL/BLOCKED/observer failures to PASS.'],
 'retryPolicy':'Preserve full failed sample and actual time. Correct a diagnosed cause and independently preflight it, then record a new exact-source bounded attempt; existing user authorization persists.',
 'validation':{'archive':str(Path(validationpath).parent),'manifest':'validation.json','manifestSha256':sha(root/validationpath),'results':validation['results'],'nativeQualification':False},
 'committedInputs':[{'path':p,'frozen':True,'committedSource':commit,'sha256':sha(root/p)} for p in [planpath,rustpath,reevalpath,'.github/workflows/ci.yml','.github/workflows/native-evidence-reevaluation.yml','.github/workflows/isi4-yours-wallet.yml']],
 'oracleSelection':{k:v for k,v in plan.items() if 'Oracle' in k or k in ['headerFixture','finalSubmissionAncestryPolicy','shutdownSubmissionPolicy','permissionFixture','coverageModules']},
 'economicPolicySources':[{'path':p,'sha256':sha(ops/p)} for p in ['docs/systems/shared-device-lab-economic-requirements.md','config/shared-device-economic-policy.json']],
 'dispatchAuthorizedByThisOrder':True
}
receipt_names=['coverage1-freeze.json','coverage1-freeze-independent.json','coverage1-committed-selector.json','coverage1-final-summary.json','permission-prelude-guard-review.json']
for name in receipt_names:
 assert (root/'out/native-closure-20261111'/name).is_file(),name
for path in [root/validationpath,root/'out/permission-fee-review/review.json',root/'out/native-review-4a954ac/intake-independent-review-2.json']:
 assert path.is_file(),path
out.mkdir(parents=True)
for name in receipt_names:
 source=root/'out/native-closure-20261111'/name
 assert source.is_file(),source
 shutil.copyfile(source,out/name)
shutil.copyfile(root/validationpath,out/'validation.json')
shutil.copyfile(root/'out/permission-fee-review/review.json',out/'fresh-permission-pool-review.json')
shutil.copyfile(root/'out/native-review-4a954ac/intake-independent-review-2.json',out/'wallet-intake-review.json')
order['files']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir())]
(out/'work-order.json').write_text(json.dumps(order,indent=2)+'\n')
print(json.dumps({'source':commit,'path':str(out/'work-order.json'),'sha256':sha(out/'work-order.json'),'deadline':order['deadline'],'maximumNewJobSeconds':9600},indent=2))

