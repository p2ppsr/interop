package services_test

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"github.com/bsv-blockchain/go-sdk/chainhash"
	"github.com/bsv-blockchain/go-sdk/transaction"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/defs"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/txutils"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/services"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
	vectors "github.com/bsv-blockchain/universal-test-vectors/pkg/testabilities"
	"github.com/stretchr/testify/require"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
)

type batchHTTPProvider struct {
	url    string
	client *http.Client
}

func (p *batchHTTPProvider) PostTX(ctx context.Context, raw []byte) (*wdk.PostedTxID, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, p.url, bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	response, err := p.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		return nil, fmt.Errorf("provider HTTP %d", response.StatusCode)
	}
	var result wdk.PostedTxID
	if err := json.NewDecoder(response.Body).Decode(&result); err != nil {
		return nil, err
	}
	return &result, nil
}
func batchHTTPServices(t *testing.T, failed string, terminal bool) (*services.WalletServices, func() []string) {
	t.Helper()
	var mu sync.Mutex
	seen := []string{}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
		if err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		tx, err := transaction.NewTransactionFromBytes(raw)
		if err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		id := tx.TxID().String()
		mu.Lock()
		seen = append(seen, id)
		mu.Unlock()
		if id == failed && !terminal {
			http.Error(w, "Controlled provider failure", 503)
			return
		}
		result := wdk.PostedTxID{TxID: id, Result: wdk.PostedTxIDResultSuccess}
		if id == failed {
			result.Result = wdk.PostedTxIDResultError
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(result)
	}))
	t.Cleanup(server.Close)
	provider := &batchHTTPProvider{url: server.URL, client: server.Client()}
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	svc := services.New(logger, defs.WalletServices{Chain: defs.NetworkMainnet}, services.WithHttpClient(server.Client()), services.WithCustomImplementation("tpnil-batch-http", services.ToImplementation(provider)))
	return svc, func() []string { mu.Lock(); defer mu.Unlock(); return append([]string{}, seen...) }
}
func batchBEEF(t *testing.T, subjects ...*transaction.Transaction) *transaction.Beef {
	t.Helper()
	beef := transaction.NewBeefV2()
	for _, tx := range subjects {
		_, err := beef.MergeTransaction(tx)
		require.NoError(t, err)
	}
	return beef
}
func independentBatchTx(amount uint64) *transaction.Transaction {
	return vectors.GivenTX().WithInput(amount).WithP2PKHOutput(amount - 2).TX()
}
func assertBatchSuccess(t *testing.T, results wdk.PostFromBeefResult, ids []string) {
	t.Helper()
	require.Len(t, results, len(ids))
	for i, id := range ids {
		require.NoError(t, results[i].Error)
		require.NotNil(t, results[i].PostedBEEFResult)
		require.Len(t, results[i].PostedBEEFResult.TxIDResults, 1)
		require.Equal(t, id, results[i].PostedBEEFResult.TxIDResults[0].TxID)
		require.Equal(t, wdk.PostedTxIDResultSuccess, results[i].PostedBEEFResult.TxIDResults[0].Result)
	}
}
func TestTPNILBatchSubjectsHTTP(t *testing.T) {
	t.Run("independent subjects retain requested order", func(t *testing.T) {
		a, b := independentBatchTx(101), independentBatchTx(103)
		beef := batchBEEF(t, a, b)
		ids := []string{b.TxID().String(), a.TxID().String()}
		require.Error(t, txutils.ValidateSingleLeafTx(beef), "single-leaf contract remains strict")
		svc, seen := batchHTTPServices(t, "", false)
		results, err := svc.PostFromBEEF(t.Context(), beef, ids)
		require.NoError(t, err)
		assertBatchSuccess(t, results, ids)
		require.Equal(t, ids, seen())
	})
	t.Run("shared-parent siblings preserve shared proof", func(t *testing.T) {
		parent := vectors.GivenTX().WithInput(100).WithP2PKHOutput(40).WithP2PKHOutput(50).TX()
		proof, err := transaction.NewMerklePathFromCoinbaseTxid(parent.TxID(), 900000)
		require.NoError(t, err)
		parent.MerklePath = proof
		a := vectors.GivenTX().WithInputFromUTXO(parent, 0).WithP2PKHOutput(38).TX()
		b := vectors.GivenTX().WithInputFromUTXO(parent, 1).WithP2PKHOutput(48).TX()
		beef := batchBEEF(t, a, b)
		originalProof := proof.Hex()
		ids := []string{a.TxID().String(), b.TxID().String()}
		svc, seen := batchHTTPServices(t, "", false)
		results, err := svc.PostFromBEEF(t.Context(), beef, ids)
		require.NoError(t, err)
		assertBatchSuccess(t, results, ids)
		require.Equal(t, ids, seen())
		require.Equal(t, originalProof, beef.FindTransaction(parent.TxID().String()).MerklePath.Hex())
		require.Len(t, beef.BUMPs, 1)
	})
	t.Run("dependent parent and child are both subjects", func(t *testing.T) {
		parent := independentBatchTx(110)
		child := vectors.GivenTX().WithInputFromUTXO(parent, 0).WithP2PKHOutput(105).TX()
		beef := batchBEEF(t, child)
		ids := []string{parent.TxID().String(), child.TxID().String()}
		svc, seen := batchHTTPServices(t, "", false)
		results, err := svc.PostFromBEEF(t.Context(), beef, ids)
		require.NoError(t, err)
		assertBatchSuccess(t, results, ids)
		require.Equal(t, ids, seen())
	})
	t.Run("duplicate requests keep legacy ordered processing", func(t *testing.T) {
		a := independentBatchTx(115)
		ids := []string{a.TxID().String(), a.TxID().String()}
		svc, seen := batchHTTPServices(t, "", false)
		results, err := svc.PostFromBEEF(t.Context(), batchBEEF(t, a), ids)
		require.NoError(t, err)
		assertBatchSuccess(t, results, ids)
		require.Equal(t, ids, seen())
	})
	for _, name := range []string{"unknown later subject", "omitted independent leaf", "unrelated extra leaf", "txid-only subject", "empty subjects", "nil graph", "inconsistent body identity", "nil BUMP", "nil BUMP bottom element", "nil BUMP upper element"} {
		t.Run(name+" rejects before any HTTP", func(t *testing.T) {
			a, b := independentBatchTx(120), independentBatchTx(122)
			beef := batchBEEF(t, a, b)
			ids := []string{a.TxID().String(), b.TxID().String()}
			switch name {
			case "unknown later subject":
				ids[1] = strings.Repeat("a7", 32)
			case "omitted independent leaf":
				ids = ids[:1]
			case "unrelated extra leaf":
				_, err := beef.MergeTransaction(independentBatchTx(124))
				require.NoError(t, err)
			case "txid-only subject":
				beef.RemoveExistingTxid(b.TxID())
				beef.MergeTxidOnly(b.TxID())
			case "empty subjects":
				ids = nil
			case "nil graph":
				beef = nil
			case "nil BUMP":
				beef.BUMPs = append(beef.BUMPs, nil)
			case "nil BUMP bottom element":
				beef.BUMPs = append(beef.BUMPs, &transaction.MerklePath{Path: [][]*transaction.PathElement{{nil}}})
			case "nil BUMP upper element":
				beef.BUMPs = append(beef.BUMPs, &transaction.MerklePath{Path: [][]*transaction.PathElement{{}, {nil}}})
			case "inconsistent body identity":
				beef.Transactions[*b.TxID()].Transaction = a
			}
			svc, seen := batchHTTPServices(t, "", false)
			results, err := svc.PostFromBEEF(t.Context(), beef, ids)
			require.NoError(t, err)
			require.Len(t, results, 1)
			require.Equal(t, "PostFromBEEF Validation", results[0].Name)
			require.Error(t, results[0].Error)
			require.Empty(t, seen())
		})
	}
	t.Run("missing later direct source cannot partially submit", func(t *testing.T) {
		a, b := independentBatchTx(130), independentBatchTx(132)
		missing, err := chainhash.NewHashFromHex(strings.Repeat("b7", 32))
		require.NoError(t, err)
		b.Inputs[0].SourceTXID = missing
		b.Inputs[0].SourceTransaction = nil
		beef := batchBEEF(t, a, b)
		svc, seen := batchHTTPServices(t, "", false)
		_, err = svc.PostFromBEEF(t.Context(), beef, []string{a.TxID().String(), b.TxID().String()})
		require.Error(t, err)
		require.Contains(t, err.Error(), "hydrate")
		require.Empty(t, seen())
	})
	for _, terminal := range []bool{false, true} {
		t.Run(fmt.Sprintf("provider failure terminal=%t retains every per-item result", terminal), func(t *testing.T) {
			a, b, c := independentBatchTx(140), independentBatchTx(142), independentBatchTx(144)
			ids := []string{a.TxID().String(), b.TxID().String(), c.TxID().String()}
			svc, seen := batchHTTPServices(t, b.TxID().String(), terminal)
			results, err := svc.PostFromBEEF(t.Context(), batchBEEF(t, a, b, c), ids)
			require.NoError(t, err)
			require.Equal(t, ids, seen())
			require.Len(t, results, 3)
			for _, i := range []int{0, 2} {
				assertBatchSuccess(t, results[i:i+1], ids[i:i+1])
			}
			if terminal {
				require.NoError(t, results[1].Error)
				require.Equal(t, b.TxID().String(), results[1].PostedBEEFResult.TxIDResults[0].TxID)
				require.Equal(t, wdk.PostedTxIDResultError, results[1].PostedBEEFResult.TxIDResults[0].Result)
			} else {
				require.Error(t, results[1].Error)
				require.Nil(t, results[1].PostedBEEFResult)
			}
		})
	}
}
