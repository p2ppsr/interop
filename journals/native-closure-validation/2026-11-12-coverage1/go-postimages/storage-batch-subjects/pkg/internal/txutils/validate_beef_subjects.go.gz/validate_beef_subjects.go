package txutils

import (
	"fmt"
	"sort"

	"github.com/bsv-blockchain/go-sdk/chainhash"
	"github.com/bsv-blockchain/go-sdk/transaction"
)

// ValidateBEEFSubjects validates the complete broadcast subject set before any
// provider can receive a transaction. Every graph leaf must be selected, but a
// selected ancestor is also valid (e.g. a held parent and its child). It does not
// reorder/deduplicate the caller's slice or trim shared ancestry and proofs.
// ValidateSingleLeafTx remains unchanged for consumers with that contract.
func ValidateBEEFSubjects(beef *transaction.Beef, txIDs []string) error {
	if beef == nil || len(beef.Transactions) == 0 || len(txIDs) == 0 {
		return fmt.Errorf("expected a nonempty BEEF and broadcast subject set")
	}
	selected := make(map[chainhash.Hash]struct{}, len(txIDs))
	for _, id := range txIDs {
		hash, err := chainhash.NewHashFromHex(id)
		if err != nil {
			return fmt.Errorf("invalid broadcast subject %q: %w", id, err)
		}
		entry, exists := beef.Transactions[*hash]
		if !exists || entry == nil || entry.Transaction == nil {
			return fmt.Errorf("broadcast subject %s has no full transaction body in BEEF", id)
		}
		if *entry.Transaction.TxID() != *hash {
			return fmt.Errorf("broadcast subject %s differs from its transaction body", id)
		}
		selected[*hash] = struct{}{}
	}
	for hash, entry := range beef.Transactions {
		if entry == nil || (entry.Transaction != nil && *entry.Transaction.TxID() != hash) {
			return fmt.Errorf("BEEF transaction entry %s has inconsistent identity", hash.String())
		}
	}
	parents := referencedParentTxIDs(beef)
	var missing []string
	leaves := 0
	for hash := range beef.Transactions {
		if _, referenced := parents[hash]; referenced {
			continue
		}
		leaves++
		if _, requested := selected[hash]; !requested {
			missing = append(missing, hash.String())
		}
	}
	if leaves == 0 {
		return fmt.Errorf("BEEF has no broadcast leaf")
	}
	if len(missing) > 0 {
		sort.Strings(missing)
		return fmt.Errorf("BEEF contains unrequested broadcast leaves: %v", missing)
	}
	// BindBumpsAndTransactions requires bodies for BUMP entries present in the
	// graph. Reject malformed/stub proof targets instead of dereferencing nil.
	// Referenced TxID-only ancestors without such a proof remain unchanged.
	for _, bump := range beef.BUMPs {
		if bump == nil {
			return fmt.Errorf("BEEF contains a nil BUMP")
		}
		for _, layer := range bump.Path {
			for _, element := range layer {
				if element == nil {
					return fmt.Errorf("BEEF contains a nil BUMP path element")
				}
			}
		}
		if len(bump.Path) == 0 {
			continue
		}
		for _, element := range bump.Path[0] {
			if element.Txid != nil && *element.Txid && element.Hash != nil {
				if entry, exists := beef.Transactions[*element.Hash]; exists && entry.Transaction == nil {
					return fmt.Errorf("BUMP target %s has no transaction body", element.Hash.String())
				}
			}
		}
	}
	return nil
}
