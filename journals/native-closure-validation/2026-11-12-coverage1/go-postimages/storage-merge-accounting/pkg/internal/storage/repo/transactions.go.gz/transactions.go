package repo

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/satoshi"
	"github.com/go-softwarelab/common/pkg/is"
	"github.com/go-softwarelab/common/pkg/slices"
	"github.com/go-softwarelab/common/pkg/to"
	"go.opentelemetry.io/otel/attribute"
	"gorm.io/gen"
	"gorm.io/gen/field"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"

	pkgentity "github.com/bsv-blockchain/go-wallet-toolbox/pkg/entity"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/database/genquery"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/database/models"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/database/scopes"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/dbretry"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/entity"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/history"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/queryopts"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/txutils"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/tracing"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk/primitives"
)

// ErrUTXOContention is returned when concurrent transactions attempt to reserve the same UTXOs.
// It wraps the public wdk.ErrUTXOContention sentinel so callers outside this package can match on
// it via errors.Is(err, wdk.ErrUTXOContention). The retry (bounded, on contention only) happens in
// create.Create, not here.
var ErrUTXOContention = fmt.Errorf("storage layer: %w", wdk.ErrUTXOContention)

// ErrProvidedInputConflict is returned when a create action's provided inputs (KnownOutputIDs) or
// noSendChange outputs cannot be claimed because another transaction already set their spent_by.
// Unlike contention over funder-selected UTXOs — which a retry can resolve by locking different
// coins — a provided-input conflict is permanent: the same caller-supplied outpoints are
// re-attempted on every retry, so the bounded funding retry loop (create.retryOnContention) must
// NOT retry it. It wraps ErrUTXOContention so existing callers matching
// errors.Is(err, wdk.ErrUTXOContention) keep working unchanged.
var ErrProvidedInputConflict = fmt.Errorf("provided input already spent: %w", ErrUTXOContention)

// StaleUTXOIndexError reports outputs that the UserUTXO index still advertises
// as fundable even though they are already spent. It wraps ErrUTXOContention —
// and deliberately NOT ErrProvidedInputConflict — so funding retries: the retry
// can only succeed once the listed rows are dropped from the index, which the
// caller must do outside the transaction that produced this error (that
// transaction rolls back).
type StaleUTXOIndexError struct {
	OutputIDs []uint
}

func (e *StaleUTXOIndexError) Error() string {
	return fmt.Sprintf("stale fundable index rows for already-spent outputs %v: %v", e.OutputIDs, ErrUTXOContention)
}

func (e *StaleUTXOIndexError) Unwrap() error { return ErrUTXOContention }

type Transactions struct {
	query *genquery.Query
	db    *gorm.DB
	retry *dbretry.Policy
}

func NewTransactions(db *gorm.DB, query *genquery.Query, retry *dbretry.Policy) *Transactions {
	return &Transactions{db: db, query: query, retry: retry}
}

func (txs *Transactions) CreateTransaction(ctx context.Context, newTx *entity.NewTx) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-CreateTransaction")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	err = runInTransaction(ctx, txs.db, txs.retry, func(tx *gorm.DB) error {
		return txs.createTransactionInTx(tx, newTx)
	})
	if err != nil {
		return fmt.Errorf("failed to create transaction: %w", err)
	}
	return nil
}

// CreateTransactionInTx creates a new transaction record using an externally-managed DB transaction.
// Use this when Fund and CreateTransaction must share a single DB transaction (e.g. SELECT FOR UPDATE).
func (txs *Transactions) CreateTransactionInTx(ctx context.Context, tx *gorm.DB, newTx *entity.NewTx) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-CreateTransactionInTx")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	err = txs.createTransactionInTx(tx.WithContext(ctx), newTx)
	if err != nil {
		return fmt.Errorf("failed to create transaction in tx: %w", err)
	}
	return nil
}

func (txs *Transactions) createTransactionInTx(tx *gorm.DB, newTx *entity.NewTx) error {
	model, err := txs.toTransactionModel(newTx)
	if err != nil {
		return err
	}

	if err = txs.connectOutputsWithBaskets(tx, newTx, model); err != nil {
		return fmt.Errorf("failed to connect outputs with baskets: %w", err)
	}

	if err = tx.Create(model).Error; err != nil {
		return fmt.Errorf("failed to create new transaction model: %w", err)
	}

	if err = txs.reserveUTXOs(tx, model.ID, newTx.UserID, newTx.ReservedOutputIDs); err != nil {
		return err
	}

	if err = txs.markReservedOutputsAsNotSpendable(tx, model.ID, newTx.UserID, newTx.SpentOutputIDs); err != nil {
		return fmt.Errorf("failed to mark reserved outputs as not spendable: %w", err)
	}

	return nil
}

// reserveUTXOs atomically reserves UTXOs for a transaction with a guard to detect concurrent reservation.
// Returns ErrUTXOContention if another transaction already reserved any of the requested UTXOs.
// The bounded retry on this error happens one layer up, in create.Create — this method itself
// does not retry.
func (txs *Transactions) reserveUTXOs(tx *gorm.DB, transactionID uint, userID int, outputIDs []uint) error {
	if len(outputIDs) == 0 {
		return nil
	}

	result := tx.Model(&models.UserUTXO{}).
		Where("user_id = ? AND output_id IN ? AND reserved_by_id IS NULL", userID, outputIDs).
		Update("reserved_by_id", transactionID)
	if result.Error != nil {
		return fmt.Errorf("failed to reserve UTXOs: %w", result.Error)
	}
	if result.RowsAffected != int64(len(outputIDs)) {
		return fmt.Errorf("%w: reserving selected utxos: expected %d, got %d", ErrUTXOContention, len(outputIDs), result.RowsAffected)
	}
	return nil
}

func (txs *Transactions) toTransactionModel(newTx *entity.NewTx) (*models.Transaction, error) {
	outputs, err := slices.MapOrError(newTx.Outputs, func(output *entity.NewOutput) (*models.Output, error) {
		return txs.makeNewOutput(newTx.UserID, output, newTx.UTXOStatus)
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create outputs: %w", err)
	}
	model := &models.Transaction{
		UserID:      newTx.UserID,
		Status:      newTx.Status,
		Reference:   newTx.Reference,
		IsOutgoing:  newTx.IsOutgoing,
		Satoshis:    newTx.Satoshis,
		Description: newTx.Description,
		Version:     newTx.Version,
		LockTime:    newTx.LockTime,
		InputBeef:   newTx.InputBeef,
		TxID:        newTx.TxID,
		Labels: slices.Map(newTx.Labels, func(label primitives.StringUnder300) *models.Label {
			return &models.Label{
				Name:   string(label),
				UserID: newTx.UserID,
			}
		}),
		Outputs: outputs,
		Commission: to.If(newTx.Commission != nil, func() *models.Commission {
			return &models.Commission{
				UserID:        newTx.UserID,
				Satoshis:      newTx.Commission.Satoshis,
				KeyOffset:     newTx.Commission.KeyOffset,
				IsRedeemed:    newTx.Commission.IsRedeemed,
				LockingScript: newTx.Commission.LockingScript,
			}
		}).ElseThen(nil),
	}

	return model, nil
}

func (txs *Transactions) connectOutputsWithBaskets(tx *gorm.DB, newTx *entity.NewTx, model *models.Transaction) error {
	basketMaker := newCachedBasketMaker(tx, newTx.UserID)
	for _, out := range model.Outputs {
		if out.BasketName == nil || *out.BasketName == "" {
			continue
		}
		err := basketMaker.createIfNotExist(tx, *out.BasketName, wdk.NonChangeBasketConfiguration.NumberOfDesiredUTXOs, wdk.NonChangeBasketConfiguration.MinimumDesiredUTXOValue)
		if err != nil {
			return fmt.Errorf("failed to find or create output basket: %w", err)
		}

		if out.UserUTXO != nil {
			out.UserUTXO.BasketName = *out.BasketName
		}
	}
	return nil
}

func (txs *Transactions) makeNewOutput(userID int, output *entity.NewOutput, utxoStatus wdk.UTXOStatus) (*models.Output, error) {
	tags := slices.Map(output.Tags, func(tag string) *models.Tag {
		return &models.Tag{
			Name:   tag,
			UserID: userID,
		}
	})

	var lockingScript []byte
	if output.LockingScript != nil {
		var err error
		lockingScript, err = output.LockingScript.ToBytes()
		if err != nil {
			return nil, fmt.Errorf("failed to convert locking script to bytes: %w", err)
		}
	}

	out := models.Output{
		Vout:               output.Vout,
		UserID:             userID,
		Satoshis:           output.Satoshis.Int64(),
		Spendable:          output.Spendable,
		Change:             output.Change,
		ProvidedBy:         string(output.ProvidedBy),
		Description:        output.Description,
		Purpose:            output.Purpose,
		Type:               string(output.Type),
		DerivationPrefix:   output.DerivationPrefix,
		DerivationSuffix:   output.DerivationSuffix,
		LockingScript:      lockingScript,
		CustomInstructions: output.CustomInstructions,
		SenderIdentityKey:  output.SenderIdentityKey,
		BasketName:         output.BasketName,
		Tags:               tags,
	}

	if out.Spendable && out.Change {
		if is.EmptyString(output.BasketName) {
			return nil, fmt.Errorf("basket not provided for change output")
		}
		if out.Satoshis == 0 {
			return nil, fmt.Errorf("change output with zero satoshis")
		}
		sats, err := to.UInt64(out.Satoshis)
		if err != nil {
			return nil, fmt.Errorf("failed to convert satoshis to uint64: %w", err)
		}

		out.UserUTXO = &models.UserUTXO{
			UserID:             userID,
			Satoshis:           sats,
			EstimatedInputSize: txutils.EstimatedInputSizeByType(output.Type),
			UTXOStatus:         utxoStatus,
		}
	}
	return &out, nil
}

func (txs *Transactions) markReservedOutputsAsNotSpendable(tx *gorm.DB, spendingTransactionID uint, userID int, outputIDs []uint) error {
	if len(outputIDs) == 0 {
		return nil
	}

	result := tx.Model(&models.Output{}).
		Where("id IN ?", outputIDs).
		Where("user_id = ?", userID).
		Where("spent_by IS NULL").
		Updates(map[string]interface{}{
			"spendable": false,
			"spent_by":  spendingTransactionID,
		})
	if result.Error != nil {
		return fmt.Errorf("failed to mark reserved outputs as not spendable: %w", result.Error)
	}
	if result.RowsAffected != int64(len(outputIDs)) {
		// Some selected output was already spent. When the UserUTXO index still
		// lists it as fundable, that index row is provably wrong — and because
		// selection is deterministic (lowest satoshis, then lowest output id),
		// every subsequent attempt picks the same dead row and fails the same
		// way, permanently. Report the stale rows so the caller can drop them
		// (outside this doomed transaction) and retry with fresh inventory.
		if stale := txs.staleIndexedOutputs(tx, userID, outputIDs); len(stale) > 0 {
			return &StaleUTXOIndexError{OutputIDs: stale}
		}
		return fmt.Errorf("%w: claiming provided inputs: expected %d, got %d", ErrProvidedInputConflict, len(outputIDs), result.RowsAffected)
	}
	return nil
}

// staleIndexedOutputs returns the given outputs that are already spent yet still
// present in the UserUTXO (fundable) index.
func (txs *Transactions) staleIndexedOutputs(tx *gorm.DB, userID int, outputIDs []uint) []uint {
	var stale []uint
	err := tx.Model(&models.UserUTXO{}).
		Joins("JOIN bsv_outputs ON bsv_outputs.id = bsv_user_utxos.output_id").
		Where("bsv_user_utxos.user_id = ?", userID).
		Where("bsv_user_utxos.output_id IN ?", outputIDs).
		Where("bsv_outputs.spent_by IS NOT NULL").
		Pluck("bsv_user_utxos.output_id", &stale).Error
	if err != nil {
		// Best-effort detection: on failure fall back to the permanent error.
		return nil
	}
	return stale
}

func (txs *Transactions) FindTransactionByUserIDAndTxID(ctx context.Context, userID int, txID string) (*pkgentity.Transaction, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-FindTransactionByUserIDAndTxID", attribute.Int("UserID", userID), attribute.String("TxID", txID))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	var transaction models.Transaction
	err = txs.db.WithContext(ctx).Scopes(scopes.UserID(userID)).Where("tx_id = ?", txID).Preload("Labels").First(&transaction).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			err = nil
			return nil, nil
		}
		return nil, fmt.Errorf("failed to find transaction: %w", err)
	}

	return txs.mapModelToTransactionEntity(&transaction), nil
}

func (txs *Transactions) FindTransactionIDsByTxID(ctx context.Context, txID string) ([]uint, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-FindTransactionIDsByTxID", attribute.String("TxID", txID))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	var transactions []*models.Transaction
	err = txs.db.WithContext(ctx).
		Select(txs.query.Transaction.ID.ColumnName().String()).
		Where(txs.query.Transaction.TxID.Eq(txID)).
		Find(&transactions).Error
	if err != nil {
		return nil, fmt.Errorf("failed to find transaction IDs by TxID: %w", err)
	}

	return slices.Map(transactions, func(tx *models.Transaction) uint {
		return tx.ID
	}), nil
}

func (txs *Transactions) FindReferencesByTxIDs(ctx context.Context, txIDs []string) (map[string]string, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-FindReferencesByTxIDs")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	if len(txIDs) == 0 {
		return make(map[string]string), nil
	}

	var transactions []*models.Transaction
	err = txs.db.WithContext(ctx).
		Select("tx_id", "reference").
		Where("tx_id IN ?", txIDs).
		Find(&transactions).Error
	if err != nil {
		return nil, fmt.Errorf("failed to find references by TxIDs: %w", err)
	}

	result := make(map[string]string, len(transactions))
	for _, tx := range transactions {
		if tx.TxID != nil {
			result[*tx.TxID] = tx.Reference
		}
	}

	return result, nil
}

func (txs *Transactions) FindTransactionByReference(ctx context.Context, userID int, reference string) (*pkgentity.Transaction, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-FindTransactionByReference", attribute.Int("UserID", userID), attribute.String("Reference", reference))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	var transaction models.Transaction
	err = txs.db.WithContext(ctx).
		Scopes(scopes.UserID(userID)).
		Where("reference = ?", reference).
		Preload("Labels").
		First(&transaction).
		Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			err = nil
			return nil, nil
		}

		return nil, fmt.Errorf("failed to find transaction by reference: %w", err)
	}

	return txs.mapModelToTransactionEntity(&transaction), nil
}

func (txs *Transactions) SpendTransaction(ctx context.Context, updatedTx entity.UpdatedTx, txNote history.Builder) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-SpendTransaction", attribute.Int("UserID", updatedTx.UserID), attribute.String("TransactionID", updatedTx.TxID))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	err = runInTransaction(ctx, txs.db, txs.retry, func(tx *gorm.DB) (err error) {
		err = tx.Model(models.Transaction{}).
			Scopes(scopes.UserID(updatedTx.UserID)).
			Where("id = ?", updatedTx.TransactionID).
			Updates(map[string]any{
				"tx_id":      updatedTx.TxID,
				"input_beef": nil, // input_beef per user's transaction won't be needed anymore; it is moved to the KnownTx (storage-wide)
				"status":     updatedTx.TxStatus,
			}).Error
		if err != nil {
			return err
		}

		err = tx.Delete(models.UserUTXO{}, "reserved_by_id = ?", updatedTx.TransactionID).Error
		if err != nil {
			return err
		}

		var changeOutputs []*models.Output
		err = tx.Model(&models.Output{}).
			Select(txs.query.Output.ID.ColumnName().String(), txs.query.Output.Vout.ColumnName().String()).
			Scopes(scopes.UserID(updatedTx.UserID)).
			Where(txs.query.Output.TransactionID.Eq(updatedTx.TransactionID)).
			Where(txs.query.Output.BasketName.IsNotNull()).
			Where(txs.query.Output.Change.Is(true)).
			Where(txs.query.Output.Satoshis.Gt(0)).
			Where(txs.query.Output.SpentBy.IsNull()).
			Find(&changeOutputs).Error
		if err != nil {
			return fmt.Errorf("failed to find outputs for transaction: %w", err)
		}

		for _, output := range changeOutputs {
			lockingScript, err := updatedTx.GetLockingScriptBytes(output.Vout)
			if err != nil {
				return fmt.Errorf("failed to get locking script: %w", err)
			}

			err = tx.Model(&models.Output{}).
				Where("id = ?", output.ID).
				Updates(map[string]any{
					txs.query.Output.LockingScript.ColumnName().String(): lockingScript,
				}).Error
			if err != nil {
				return fmt.Errorf("failed to update locking script for change output: %w", err)
			}
		}

		return upsertKnownTx(tx, &entity.UpsertKnownTx{
			TxID:            updatedTx.TxID,
			Status:          updatedTx.ReqTxStatus,
			RawTx:           updatedTx.RawTx,
			InputBeef:       updatedTx.InputBeef,
			SkipForStatuses: wdk.ProvenTxReqBeyondBroadcastStageStatuses,
		}, txNote)
	})
	if err != nil {
		return fmt.Errorf("failed to update transaction: %w", err)
	}
	return nil
}

// statusInCondition is the shared WHERE fragment for status-set filters and CAS preconditions.
const statusInCondition = "status IN ?"

// UpdateTransactionStatusByTxID updates every transaction row matching txID to txStatus.
// When expectedCurrent is non-empty it is applied as a positive CAS precondition
// (AND status IN (...)); a zero-row result — absent row or failed precondition —
// returns a %w-wrapped ErrStatusUpdateSkipped instead of a silent no-op.
func (txs *Transactions) UpdateTransactionStatusByTxID(ctx context.Context, txID string, txStatus wdk.TxStatus, expectedCurrent ...wdk.TxStatus) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-UpdateTransactionStatusByTxID", attribute.String("TransactionID", txID), attribute.String("Status", string(txStatus)))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	query := txs.db.WithContext(ctx).Model(models.Transaction{}).
		Where("tx_id = ?", txID)
	if len(expectedCurrent) > 0 {
		query = query.Where(statusInCondition, expectedCurrent)
	}

	result := query.Updates(map[string]any{
		"status": txStatus,
	})
	if result.Error != nil {
		err = fmt.Errorf("failed to update transaction status by txID: %w", result.Error)
		return err
	}
	if result.RowsAffected == 0 {
		err = fmt.Errorf("%w: transaction(s) with txID %s -> %s (expected current %v)", ErrStatusUpdateSkipped, txID, txStatus, expectedCurrent)
		return err
	}

	return nil
}

// UpdateTransactionStatusByID updates a single transaction (by primary key) to txStatus.
// When expectedCurrent is non-empty it is applied as a positive CAS precondition;
// a zero-row result returns a %w-wrapped ErrStatusUpdateSkipped.
func (txs *Transactions) UpdateTransactionStatusByID(ctx context.Context, transactionID uint, txStatus wdk.TxStatus, expectedCurrent ...wdk.TxStatus) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-UpdateTransactionStatusByID", attribute.String("TransactionID", fmt.Sprintf("%d", transactionID)), attribute.String("Status", string(txStatus)))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	table := txs.query.Transaction
	dao := table.WithContext(ctx).Where(table.ID.Eq(transactionID))
	if len(expectedCurrent) > 0 {
		dao = dao.Where(table.Status.In(slices.Map(expectedCurrent, func(s wdk.TxStatus) string { return string(s) })...))
	}

	info, err := dao.Update(table.Status, txStatus)
	if err != nil {
		err = fmt.Errorf("update query for transaction status failed: %w", err)
		return err
	}
	if info.RowsAffected == 0 {
		err = fmt.Errorf("%w: transaction with ID %d -> %s (expected current %v)", ErrStatusUpdateSkipped, transactionID, txStatus, expectedCurrent)
		return err
	}
	return nil
}

func (txs *Transactions) mapModelToTransactionEntity(model *models.Transaction) *pkgentity.Transaction {
	return &pkgentity.Transaction{
		ID:          model.ID,
		CreatedAt:   model.CreatedAt,
		UpdatedAt:   model.UpdatedAt,
		UserID:      model.UserID,
		Status:      model.Status,
		Reference:   model.Reference,
		IsOutgoing:  model.IsOutgoing,
		Satoshis:    model.Satoshis,
		Description: model.Description,
		Version:     model.Version,
		LockTime:    model.LockTime,
		TxID:        model.TxID,
		InputBEEF:   model.InputBeef,
		Labels: slices.Map(model.Labels, func(label *models.Label) string {
			return label.Name
		}),
	}
}

func (txs *Transactions) ListAndCountActions(ctx context.Context, userID int, filter entity.ListActionsFilter) ([]*pkgentity.Transaction, int64, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-ListAndCountActions", attribute.Int("UserID", userID))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	var actions []*models.Transaction
	var total int64

	err = txs.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		query := tx.Model(&models.Transaction{}).
			Where("user_id = ?", userID)

		if len(filter.Status) > 0 {
			query = query.Where(statusInCondition, filter.Status)
		}

		if len(filter.Labels) > 0 {
			query = query.Scopes(labelledWith(tx, userID, filter.Labels, filter.LabelQueryMode))
		}

		query = applyListActionsTimeFilters(query, filter)

		if err = query.Count(&total).Error; err != nil {
			return fmt.Errorf("count failed: %w", err)
		}

		if total == 0 {
			return nil
		}

		if err = query.
			Limit(filter.Limit).
			Offset(filter.Offset).
			Order("id ASC").
			Find(&actions).Error; err != nil {
			return fmt.Errorf("query failed: %w", err)
		}

		return nil
	})
	if err != nil {
		return nil, 0, fmt.Errorf("transaction failed: %w", err)
	}

	return slices.Map(actions, txs.mapModelToTransactionEntity), total, nil
}

// buildSelectedActionsSubQuery constructs a subquery selecting the current page of actions (id, tx_id)
// matching the provided filter. It mirrors ListAndCountActions ordering and pagination so it can be
// reused in JOINs to avoid large IN (...) clauses.
func (txs *Transactions) buildSelectedActionsSubQuery(tx *gorm.DB, userID int, filter entity.ListActionsFilter) *gorm.DB {
	query := tx.Model(&models.Transaction{}).
		Select("id, tx_id").
		Where("user_id = ?", userID)

	if len(filter.Status) > 0 {
		query = query.Where(statusInCondition, filter.Status)
	}
	if len(filter.Labels) > 0 {
		query = query.Scopes(labelledWith(tx, userID, filter.Labels, filter.LabelQueryMode))
	}

	query = applyListActionsTimeFilters(query, filter)

	return query.Order("id ASC").Limit(filter.Limit).Offset(filter.Offset)
}

// GetLabelsForSelectedActions fetches labels via JOIN with the selected actions subquery to avoid IN lists.
func (txs *Transactions) GetLabelsForSelectedActions(ctx context.Context, userID int, filter entity.ListActionsFilter) (map[uint][]string, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-GetLabelsForSelectedActions", attribute.Int("UserID", userID))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	labelsMap := make(map[uint][]string)
	err = txs.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		selected := txs.buildSelectedActionsSubQuery(tx, userID, filter)
		var closeErr error
		var rows *sql.Rows
		rows, err = tx.Table("bsv_transaction_labels tl").
			Select("tl.transaction_id, tl.label_name").
			Joins("JOIN (?) s ON s.id = tl.transaction_id", selected).
			Where("tl.label_name IS NOT NULL").
			Where("tl.deleted_at IS NULL").
			Rows()
		if err != nil {
			return fmt.Errorf("failed to query labels rows: %w", err)
		}
		defer func() {
			if cerr := rows.Close(); cerr != nil {
				closeErr = fmt.Errorf("rows close failed: %w", cerr)
			}
		}()

		for rows.Next() {
			var txID uint
			var label string
			if err = rows.Scan(&txID, &label); err != nil {
				return fmt.Errorf("scan failed: %w", err)
			}
			labelsMap[txID] = append(labelsMap[txID], label)
		}
		if err = rows.Err(); err != nil {
			return fmt.Errorf("rows iteration failed: %w", err)
		}
		return closeErr
	})
	if err != nil {
		return nil, fmt.Errorf("failed to fetch labels for selected actions: %w", err)
	}
	return labelsMap, nil
}

func (txs *Transactions) GetLabelsForTransactions(ctx context.Context, txIDs []uint) (map[uint][]string, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-GetLabelsForTransactions")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	if len(txIDs) == 0 {
		return make(map[uint][]string), nil
	}

	type resultRow struct {
		TransactionID uint
		LabelName     string
	}

	var rows []resultRow
	err = txs.db.WithContext(ctx).
		Model(&models.TransactionLabel{}).
		Select("transaction_id, label_name").
		Where("transaction_id IN ?", txIDs).
		Where("label_name IS NOT NULL").
		Scan(&rows).Error
	if err != nil {
		return nil, fmt.Errorf("failed to batch fetch labels: %w", err)
	}

	labelsMap := make(map[uint][]string)
	for _, row := range rows {
		labelsMap[row.TransactionID] = append(labelsMap[row.TransactionID], row.LabelName)
	}
	return labelsMap, nil
}

func (txs *Transactions) GetLabelsForTxIDs(ctx context.Context, txIDs []string) (map[string][]string, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-GetLabelsForTxIDs")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	if len(txIDs) == 0 {
		return make(map[string][]string), nil
	}

	type resultRow struct {
		TxID      string
		LabelName string
	}

	var rows []resultRow
	err = txs.db.WithContext(ctx).
		Table("bsv_transactions t").
		Select("t.tx_id, tl.label_name").
		Joins("JOIN bsv_transaction_labels tl ON tl.transaction_id = t.id").
		Where("t.tx_id IN ?", txIDs).
		Where("tl.label_name IS NOT NULL").
		Where("tl.deleted_at IS NULL").
		Scan(&rows).Error
	if err != nil {
		return nil, fmt.Errorf("failed to batch fetch labels by txID: %w", err)
	}

	labelsMap := make(map[string][]string)
	for _, row := range rows {
		labelsMap[row.TxID] = append(labelsMap[row.TxID], row.LabelName)
	}
	return labelsMap, nil
}

func (txs *Transactions) AddLabels(ctx context.Context, userID int, transactionID uint, labels ...string) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-AddLabels", attribute.Int("UserID", userID), attribute.String("TransactionID", fmt.Sprintf("%d", transactionID)), attribute.StringSlice("Labels", labels))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	newLabels := slices.Map(labels, func(value string) any {
		return &models.Label{
			Name:   value,
			UserID: userID,
		}
	})

	transactionModel := models.Transaction{}

	err = runInTransaction(ctx, txs.db, txs.retry, func(tx *gorm.DB) error {
		err = tx.Model(models.Transaction{}).
			Select("*").
			Where("id = ?", transactionID).
			Preload("Labels").
			First(&transactionModel).Error
		if err != nil {
			return fmt.Errorf("failed to find transaction: %w", err)
		}

		association := tx.
			Model(&transactionModel).
			Association("Labels")

		err = association.Append(newLabels...)
		if err != nil {
			return fmt.Errorf("failed to append new labels: %w", err)
		}

		return nil
	})
	if err != nil {
		return fmt.Errorf("failed to replace labels: %w", err)
	}

	return nil
}

func (txs *Transactions) FindTransactionIDsByStatuses(ctx context.Context, txStatus []wdk.TxStatus, opts ...queryopts.Options) ([]uint, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-FindTransactionIDsByStatuses")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	table := &txs.query.Transaction
	rows, err := table.WithContext(ctx).
		Select(table.ID).
		Scopes(scopes.FromQueryOptsForGen(table, opts)...).
		Where(table.Status.In(slices.Map(txStatus, func(txStatus wdk.TxStatus) string { return string(txStatus) })...)).
		Find()
	if err != nil {
		return nil, fmt.Errorf("query for finding transaction ids by statuses failed: %w", err)
	}

	return slices.Map(rows, func(row *models.Transaction) uint {
		return row.ID
	}), nil
}

func (txs *Transactions) FindTransactionIDsForAbort(ctx context.Context, opts ...queryopts.Options) ([]uint, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-FindTransactionIDsForAbort")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	txTable := txs.query.Transaction.TableName()
	knownTxTable := txs.query.KnownTx.TableName()

	query := txs.db.WithContext(ctx).
		Model(&models.Transaction{}).
		Select(txTable+".id").
		Joins(fmt.Sprintf("LEFT JOIN %s ON %s.tx_id = %s.tx_id", knownTxTable, knownTxTable, txTable)).
		Where(
			fmt.Sprintf(
				"(%s.status = ? OR (%s.status = ? AND COALESCE(%s.status, ?) = ?))",
				txTable, txTable, knownTxTable,
			),
			wdk.TxStatusUnsigned,
			wdk.TxStatusUnprocessed,
			string(wdk.ProvenTxStatusUnprocessed),
			wdk.ProvenTxStatusUnprocessed,
		).
		Order(txTable + ".created_at ASC")

	options := queryopts.MergeOptions(opts)
	if options.Until != nil {
		options.Until.ApplyDefaults()
		query = query.Where(fmt.Sprintf("%s.created_at <= ?", txTable), options.Until.Time)
	}
	if options.Page != nil {
		options.Page.ApplyDefaults()
		query = query.Offset(options.Page.Offset).Limit(options.Page.Limit)
	}

	var rows []*models.Transaction
	err = query.Find(&rows).Error
	if err != nil {
		return nil, fmt.Errorf("query for finding transaction ids for abort failed: %w", err)
	}

	return slices.Map(rows, func(row *models.Transaction) uint {
		return row.ID
	}), nil
}

func (txs *Transactions) AddTransaction(ctx context.Context, tx *pkgentity.Transaction) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-AddTransaction")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	if tx == nil {
		return fmt.Errorf("transaction cannot be nil")
	}

	labels := make([]primitives.StringUnder300, len(tx.Labels))
	for i, label := range tx.Labels {
		labels[i] = primitives.StringUnder300(label)
	}

	newTx := &entity.NewTx{
		UserID:      tx.UserID,
		Status:      tx.Status,
		Reference:   tx.Reference,
		IsOutgoing:  tx.IsOutgoing,
		Satoshis:    tx.Satoshis,
		Description: tx.Description,
		Version:     tx.Version,
		LockTime:    tx.LockTime,
		TxID:        tx.TxID,
		Labels:      labels,
	}

	return txs.CreateTransaction(ctx, newTx)
}

func (txs *Transactions) UpdateTransaction(ctx context.Context, spec *pkgentity.TransactionUpdateSpecification) error {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-UpdateTransaction", attribute.String("TransactionID", fmt.Sprintf("%d", spec.ID)))
	defer func() {
		tracing.EndTracing(span, err)
	}()

	table := &txs.query.Transaction

	updates := map[string]any{}
	if spec.Status != nil {
		updates[table.Status.ColumnName().String()] = *spec.Status
	}
	if spec.Description != nil {
		updates[table.Description.ColumnName().String()] = *spec.Description
	}

	if len(updates) == 0 {
		return nil
	}

	var info gen.ResultInfo
	info, err = table.WithContext(ctx).Where(table.ID.Eq(spec.ID)).Updates(updates)
	if err != nil {
		return fmt.Errorf("failed to update transaction: %w", err)
	}
	if info.RowsAffected == 0 {
		err = fmt.Errorf("no rows updated for ID=%d", spec.ID)
		return err
	}

	return nil
}

func (txs *Transactions) FindTransactions(ctx context.Context, spec *pkgentity.TransactionReadSpecification, opts ...queryopts.Options) ([]*pkgentity.Transaction, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-FindTransactions")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	table := &txs.query.Transaction

	rows, err := table.WithContext(ctx).
		Scopes(scopes.FromQueryOptsForGen(table, opts)...).
		Where(txs.conditionsBySpec(ctx, spec)...).
		Find()
	if err != nil {
		return nil, fmt.Errorf("failed to find transactions: %w", err)
	}

	if err = txs.loadLabels(ctx, rows); err != nil {
		return nil, err
	}

	return slices.Map(rows, txs.mapModelToTransactionEntity), nil
}

// relationBatchSize bounds the IDs bound into one label or tag query (see
// loadLabels, loadTags), well under the bind-parameter limits of SQLite
// (32,766) and Postgres (65,535).
const relationBatchSize = 5000

// loadLabels fills the Labels of rows. It replaces GORM's Preload of the
// many2many Labels: Label's primary key is (name, user_id), so Preload selected
// labels with a row-value `(name, user_id) IN ((..),(..),...)` list, one tuple
// per distinct label, and Postgres fails to evaluate that list past a few
// thousand labels ("stack depth limit exceeded"). Keying on the single
// transaction_id column avoids it; both of Preload's soft-delete filters, on
// the link and on the label, are kept.
func (txs *Transactions) loadLabels(ctx context.Context, rows []*models.Transaction) error {
	byID := make(map[uint]*models.Transaction, len(rows))
	ids := make([]uint, 0, len(rows))
	for _, row := range rows {
		byID[row.ID] = row
		ids = append(ids, row.ID)
	}

	type labelRow struct {
		TransactionID uint
		Name          string
	}
	for start := 0; start < len(ids); start += relationBatchSize {
		var found []labelRow
		err := txs.db.WithContext(ctx).
			Table("bsv_transaction_labels tl").
			Select("tl.transaction_id, l.name").
			Joins("JOIN bsv_labels l ON l.name = tl.label_name AND l.user_id = tl.label_user_id").
			Where("tl.transaction_id IN ?", ids[start:min(start+relationBatchSize, len(ids))]).
			Where("tl.deleted_at IS NULL").
			Where("l.deleted_at IS NULL").
			Scan(&found).Error
		if err != nil {
			return fmt.Errorf("failed to load transaction labels: %w", err)
		}
		for _, f := range found {
			tx := byID[f.TransactionID]
			tx.Labels = append(tx.Labels, &models.Label{Name: f.Name, UserID: tx.UserID})
		}
	}
	return nil
}

func (txs *Transactions) CountTransactions(ctx context.Context, spec *pkgentity.TransactionReadSpecification, opts ...queryopts.Options) (int64, error) {
	var err error
	ctx, span := tracing.StartTracing(ctx, "Repository-Transaction-CountTransactions")
	defer func() {
		tracing.EndTracing(span, err)
	}()

	table := &txs.query.Transaction

	count, err := table.WithContext(ctx).
		Scopes(scopes.FromQueryOptsForGen(table, opts)...).
		Where(txs.conditionsBySpec(ctx, spec)...).
		Count()
	if err != nil {
		return 0, fmt.Errorf("failed to count transactions: %w", err)
	}

	return count, nil
}

func (txs *Transactions) conditionsBySpec(ctx context.Context, spec *pkgentity.TransactionReadSpecification) []gen.Condition {
	if spec == nil {
		return nil
	}

	table := &txs.query.Transaction
	if spec.ID != nil {
		return []gen.Condition{table.ID.Eq(*spec.ID)}
	}

	var conditions []gen.Condition
	if spec.UserID != nil {
		conditions = append(conditions, cmpCondition(table.UserID, spec.UserID))
	}
	if spec.Status != nil {
		conditions = append(conditions, cmpCondition(table.Status, spec.Status.ToStringComparable()))
	}
	if spec.Reference != nil {
		conditions = append(conditions, cmpCondition(table.Reference, spec.Reference))
	}
	if spec.IsOutgoing != nil {
		conditions = append(conditions, cmpBoolCondition(table.IsOutgoing, spec.IsOutgoing))
	}
	if spec.Satoshis != nil {
		conditions = append(conditions, cmpCondition(table.Satoshis, spec.Satoshis))
	}
	if spec.TxID != nil {
		conditions = append(conditions, cmpCondition(table.TxID, spec.TxID))
	}
	if spec.DescriptionContains != nil {
		conditions = append(conditions, cmpCondition(table.Description, spec.DescriptionContains))
	}
	if spec.Labels != nil {
		conditions = append(conditions, txs.labelConditions(ctx, spec.Labels)...)
	}

	return conditions
}

func (txs *Transactions) labelConditions(ctx context.Context, labels *pkgentity.ComparableSet[string]) []gen.Condition {
	var conds []gen.Condition
	table := &txs.query.Transaction
	txl := &txs.query.TransactionLabel

	if labels.Empty {
		sub := txl.WithContext(ctx).
			Select(txl.TransactionID).
			Where(txl.TransactionID.EqCol(table.ID))

		return []gen.Condition{
			field.Not(field.CompareSubQuery(field.ExistsOp, nil, sub.UnderlyingDB())),
		}
	}

	if len(labels.ContainAny) > 0 {
		sub := txl.WithContext(ctx).
			Select(txl.TransactionID).
			Where(
				txl.LabelName.In(labels.ContainAny...),
				txl.TransactionID.EqCol(table.ID),
			)
		conds = append(conds, gen.Exists(sub))
	}

	if len(labels.ContainAll) > 0 {
		for _, label := range labels.ContainAll {
			sub := txl.WithContext(ctx).
				Select(txl.TransactionID).
				Where(
					txl.LabelName.Eq(label),
					txl.TransactionID.EqCol(table.ID),
				)
			conds = append(conds, gen.Exists(sub))
		}
	}

	return conds
}

// FindTransactionByUserIDAndTxIDForUpdate is used only inside internalization's
// existing unit of work. PostgreSQL/MySQL lock the row before output decisions;
// SQLite serializes conflicting writes and rolls back a stale unit of work.
func (txs *Transactions) FindTransactionByUserIDAndTxIDForUpdate(ctx context.Context, userID int, txID string) (*pkgentity.Transaction, error) {
	var row models.Transaction
	err := txs.db.WithContext(ctx).Clauses(clause.Locking{Strength: "UPDATE"}).Scopes(scopes.UserID(userID)).Where("tx_id = ?", txID).First(&row).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("failed to lock transaction for merge: %w", err)
	}
	return txs.mapModelToTransactionEntity(&row), nil
}

// SetTransactionSatoshis cannot change another owner's row or overwrite a
// concurrent balance. The caller's unit of work includes all output mutations.
func (txs *Transactions) SetTransactionSatoshis(ctx context.Context, userID int, transactionID uint, previous, next int64) error {
	if userID <= 0 || transactionID == 0 {
		return fmt.Errorf("invalid transaction owner")
	}
	if _, err := satoshi.From(previous); err != nil {
		return err
	}
	if _, err := satoshi.From(next); err != nil {
		return err
	}
	query := txs.db.WithContext(ctx).Model(&models.Transaction{}).Where("id = ? AND user_id = ? AND satoshis = ?", transactionID, userID, previous)
	if previous == next {
		var count int64
		if err := query.Count(&count).Error; err != nil {
			return err
		}
		if count != 1 {
			return fmt.Errorf("merged transaction accounting changed or owner differs")
		}
		return nil
	}
	result := query.Update("satoshis", next)
	if result.Error != nil {
		return fmt.Errorf("failed to update transaction satoshis: %w", result.Error)
	}
	if result.RowsAffected != 1 {
		return fmt.Errorf("merged transaction accounting changed or owner differs")
	}
	return nil
}
