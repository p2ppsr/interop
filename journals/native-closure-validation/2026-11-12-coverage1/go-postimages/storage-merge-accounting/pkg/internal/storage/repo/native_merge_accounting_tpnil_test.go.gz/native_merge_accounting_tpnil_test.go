package repo_test

import (
	"errors"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/dbretry"
	storageentity "github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/entity"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/repo"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/testabilities/dbfixtures"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
	"sync"
	"testing"
)

func TestTPNILMergedCreditOwnerCASAndRollback(t *testing.T) {
	db, cleanup := dbfixtures.TestDatabase(t)
	defer cleanup()
	ctx := t.Context()
	repos := repo.NewSQLRepositories(db.DB, dbretry.NoRetry())
	alice, err := repos.CreateUser(ctx, "merge-alice", "storage")
	require.NoError(t, err)
	bob, err := repos.CreateUser(ctx, "merge-bob", "storage")
	require.NoError(t, err)
	require.NoError(t, repos.CreateTransaction(ctx, &storageentity.NewTx{UserID: alice.ID, Status: wdk.TxStatusCompleted, Reference: "merge-accounting-owner", Satoshis: 1000, Version: 1}))
	row, err := repos.FindTransactionByReference(ctx, alice.ID, "merge-accounting-owner")
	require.NoError(t, err)
	require.NotNil(t, row)
	check := func(want int64) {
		t.Helper()
		current, err := repos.FindTransactionByReference(ctx, alice.ID, "merge-accounting-owner")
		require.NoError(t, err)
		require.Equal(t, want, current.Satoshis)
	}
	require.Error(t, repos.SetTransactionSatoshis(ctx, bob.ID, row.ID, 1000, 2000))
	check(1000)
	require.NoError(t, repos.SetTransactionSatoshis(ctx, alice.ID, row.ID, 1000, 2000))
	check(2000)
	require.Error(t, repos.SetTransactionSatoshis(ctx, alice.ID, row.ID, 1000, 3000))
	check(2000)
	require.NoError(t, repos.SetTransactionSatoshis(ctx, alice.ID, row.ID, 2000, 2000))
	check(2000)
	sentinel := errors.New("later output update failed")
	err = db.DB.Transaction(func(tx *gorm.DB) error {
		scoped := repo.NewSQLRepositories(tx, dbretry.NoRetry())
		if err := scoped.SetTransactionSatoshis(ctx, alice.ID, row.ID, 2000, 3000); err != nil {
			return err
		}
		return sentinel
	})
	require.ErrorIs(t, err, sentinel)
	check(2000)
	var group sync.WaitGroup
	success := make(chan bool, 12)
	for i := 0; i < 12; i++ {
		group.Go(func() { success <- repos.SetTransactionSatoshis(ctx, alice.ID, row.ID, 2000, 3000) == nil })
	}
	group.Wait()
	close(success)
	count := 0
	for ok := range success {
		if ok {
			count++
		}
	}
	require.Equal(t, 1, count, "stale concurrent accounting cannot credit twice")
	check(3000)
}
