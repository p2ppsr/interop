package storage_test

import (
	"encoding/json"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/fixtures"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/fixtures/testusers"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/storage/internal/testabilities"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk/primitives"
	vectors "github.com/bsv-blockchain/universal-test-vectors/pkg/testabilities"
	"github.com/stretchr/testify/require"
	"testing"
)

func TestTPNILMergedPaymentsAccountEveryNewCreditOnce(t *testing.T) {
	given, cleanup := testabilities.Given(t)
	defer cleanup()
	provider := given.Provider().GORM()
	tx := vectors.GivenTX().WithInput(5000).WithP2PKHOutput(1000).WithP2PKHOutput(1000).WithP2PKHOutput(7).TX()
	bytes, err := tx.AtomicBEEF(false)
	require.NoError(t, err)
	args := fixtures.DefaultInternalizeActionArgs(t, wdk.WalletPaymentProtocol)
	args.Tx = bytes
	args.Labels = []primitives.StringUnder300{"merge accounting"}
	stop := given.StartedRPCServerFor(provider)
	defer stop()
	check := func(want int64) {
		t.Helper()
		rows, err := provider.TransactionEntity().Read().UserID().Equals(testusers.Alice.ID).TxID().Equals(tx.TxID().String()).Find(t.Context())
		require.NoError(t, err)
		require.Len(t, rows, 1)
		require.Equal(t, want, rows[0].Satoshis)
		response := callJSONRPC(t, given.ServerURL(), testusers.Alice, "listActions", []any{testusers.Alice.AuthID(), wdk.ListActionsArgs{Labels: args.Labels, Limit: 10}})
		require.Nil(t, response.Error)
		var result struct {
			Actions []struct {
				Satoshis int64 `json:"satoshis"`
			}
		}
		require.NoError(t, json.Unmarshal(response.Result, &result))
		require.Len(t, result.Actions, 1)
		require.Equal(t, want, result.Actions[0].Satoshis)
	}
	first, err := provider.InternalizeAction(t.Context(), testusers.Alice.AuthID(), args)
	require.NoError(t, err)
	require.False(t, first.IsMerge)
	check(1000)
	payment := func(index uint32) *wdk.InternalizeOutput {
		return &wdk.InternalizeOutput{OutputIndex: index, Protocol: wdk.WalletPaymentProtocol, PaymentRemittance: args.Outputs[0].PaymentRemittance}
	}
	second := args
	second.Outputs = []*wdk.InternalizeOutput{payment(1), {OutputIndex: 2, Protocol: wdk.BasketInsertionProtocol, InsertionRemittance: &wdk.BasketInsertion{Basket: "merge custom"}}}
	merged, err := provider.InternalizeAction(t.Context(), testusers.Alice.AuthID(), second)
	require.NoError(t, err)
	require.True(t, merged.IsMerge)
	require.Equal(t, int64(1000), merged.Satoshis)
	check(2000)
	repeated, err := provider.InternalizeAction(t.Context(), testusers.Alice.AuthID(), second)
	require.NoError(t, err)
	require.Zero(t, repeated.Satoshis)
	check(2000)
	recovered := args
	recovered.Outputs = []*wdk.InternalizeOutput{payment(2)}
	_, err = provider.InternalizeAction(t.Context(), testusers.Alice.AuthID(), recovered)
	require.NoError(t, err)
	check(2007)
	_, err = provider.InternalizeAction(t.Context(), testusers.Alice.AuthID(), recovered)
	require.NoError(t, err)
	check(2007)
	// An invalid subsequent merge cannot partially credit or erase earlier credits.
	invalid := args
	invalid.Outputs = []*wdk.InternalizeOutput{payment(99)}
	_, err = provider.InternalizeAction(t.Context(), testusers.Alice.AuthID(), invalid)
	require.Error(t, err)
	check(2007)
	denied := callJSONRPC(t, given.ServerURL(), testusers.Bob, "listActions", []any{testusers.Alice.AuthID(), wdk.ListActionsArgs{Labels: args.Labels, Limit: 10}})
	require.NotNil(t, denied.Error)
}
