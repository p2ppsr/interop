package actions

import (
	"context"
	"iter"
	"time"

	"github.com/bsv-blockchain/go-sdk/transaction"

	pkgentity "github.com/bsv-blockchain/go-wallet-toolbox/pkg/entity"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/database/models"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/entity"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/history"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/queryopts"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
)

type BasketRepo interface {
	FindBasketByName(ctx context.Context, userID int, name string) (*pkgentity.OutputBasket, error)
	FindOrCreateBasket(ctx context.Context, userID int, name string) error
}

type OutputRepo interface {
	FindOutputs(ctx context.Context, spec *pkgentity.OutputReadSpecification, opts ...queryopts.Options) ([]*pkgentity.Output, error)
	FindOutputsByIDs(ctx context.Context, outputIDs iter.Seq[uint]) ([]*pkgentity.Output, error)
	FindTxIDsByOutputIDs(ctx context.Context, outputIDs iter.Seq[uint]) ([]string, error)
	FindOutput(ctx context.Context, userID int, outpoint wdk.OutPoint) (*pkgentity.Output, error)
	FindOutputsByTransactionID(ctx context.Context, transactionID uint) ([]*pkgentity.Output, error)
	ListAndCountOutputs(ctx context.Context, filter entity.ListOutputsFilter) ([]*pkgentity.Output, int64, error)
	FindInputsAndOutputsWithBaskets(ctx context.Context, txIDs []uint, includeLockingScripts bool) (inputs, outputs map[uint][]*pkgentity.Output, err error)
	FindInputsAndOutputsForSelectedActions(ctx context.Context, userID int, filter entity.ListActionsFilter, includeLockingScripts bool) (inputs, outputs map[uint][]*pkgentity.Output, err error)
	FindOutputsByOutpoints(ctx context.Context, userID int, outpoints []wdk.OutPoint) ([]*pkgentity.Output, error)
	SaveOutputs(ctx context.Context, output []*pkgentity.Output) error
	RecreateSpentOutputs(ctx context.Context, spendingTransactionID uint) error
	ShouldTxOutputsBeUnspent(ctx context.Context, transactionID uint) error
	MarkCreatedOutputsAsNotSpendable(ctx context.Context, transactionID uint) error
	MarkCreatedOutputsAsSpendableByTxID(ctx context.Context, txID string) error
}

type TransactionsRepo interface {
	CreateTransaction(ctx context.Context, transaction *entity.NewTx) error
	FindTransactions(ctx context.Context, spec *pkgentity.TransactionReadSpecification, opts ...queryopts.Options) ([]*pkgentity.Transaction, error)
	FindTransactionByUserIDAndTxID(ctx context.Context, userID int, txID string) (*pkgentity.Transaction, error)
	FindTransactionByUserIDAndTxIDForUpdate(ctx context.Context, userID int, txID string) (*pkgentity.Transaction, error)
	SetTransactionSatoshis(ctx context.Context, userID int, transactionID uint, previous, next int64) error
	FindTransactionByReference(ctx context.Context, userID int, reference string) (*pkgentity.Transaction, error)
	FindReferencesByTxIDs(ctx context.Context, txIDs []string) (map[string]string, error)
	SpendTransaction(ctx context.Context, updatedTx entity.UpdatedTx, txNote history.Builder) error
	UpdateTransactionStatusByTxID(ctx context.Context, txID string, txStatus wdk.TxStatus, expectedCurrent ...wdk.TxStatus) error
	UpdateTransactionStatusByID(ctx context.Context, transactionID uint, txStatus wdk.TxStatus, expectedCurrent ...wdk.TxStatus) error
	ListAndCountActions(ctx context.Context, userID int, filter entity.ListActionsFilter) ([]*pkgentity.Transaction, int64, error)
	GetLabelsForTransactions(ctx context.Context, txIDs []uint) (map[uint][]string, error)
	GetLabelsForSelectedActions(ctx context.Context, userID int, filter entity.ListActionsFilter) (map[uint][]string, error)
	GetLabelsForTxIDs(ctx context.Context, txIDs []string) (map[string][]string, error)
	AddLabels(ctx context.Context, userID int, transactionID uint, labels ...string) error
	FindTransactionIDsByTxID(ctx context.Context, txID string) ([]uint, error)
	FindTransactionIDsByStatuses(ctx context.Context, txStatus []wdk.TxStatus, opts ...queryopts.Options) ([]uint, error)
	FindTransactionIDsForAbort(ctx context.Context, opts ...queryopts.Options) ([]uint, error)
}

type KnownTxRepo interface {
	UpsertKnownTx(ctx context.Context, req *entity.UpsertKnownTx, txNote history.Builder) error
	FindKnownTxRawTx(ctx context.Context, txID string) ([]byte, error)
	FindKnownTxStatuses(ctx context.Context, txIDs ...string) (map[string]wdk.ProvenTxReqStatus, error)
	FindKnownTxIDsByStatuses(ctx context.Context, txStatus []wdk.ProvenTxReqStatus, opts ...queryopts.Options) ([]*entity.KnownTxForStatusSync, error)
	// FindKnownTxIDsReadyForStatusSync skips reorged txs whose proof was cleared less than
	// reorgReproveDelay ago (zero disables the delay).
	FindKnownTxIDsReadyForStatusSync(ctx context.Context, txStatus []wdk.ProvenTxReqStatus, reorgReproveDelay time.Duration, opts ...queryopts.Options) ([]*entity.KnownTxForStatusSync, error)
	FindKnownTxIDsByStatusesNeedingFailureReview(ctx context.Context, txStatus []wdk.ProvenTxReqStatus, limit int) ([]*entity.KnownTxForStatusSync, error)
	GetBEEFForTxID(ctx context.Context, txID string, opts ...entity.GetBEEFOption) (*transaction.Beef, error)
	UpdateKnownTxAsMined(ctx context.Context, provenTxAsMined *entity.KnownTxAsMined) error
	GetBEEFForTxIDs(ctx context.Context, txids iter.Seq[string], opts ...entity.GetBEEFOption) (*transaction.Beef, error)
	AllKnownTxsExist(ctx context.Context, txIDs []string, sourceTxsStatusFilter []wdk.ProvenTxReqStatus) (bool, error)
	IncreaseKnownTxAttemptsForTxIDs(ctx context.Context, txIDs []string) error
	ApplyProofTimeouts(ctx context.Context, attempts, maxRebroadcastAttempts uint64, statuses []wdk.ProvenTxReqStatus) ([]models.KnownTx, error)
	FindKnownTxRawTxs(ctx context.Context, txIDs []string) (map[string][]byte, error)
	UpdateKnownTxStatus(ctx context.Context, txID string, status wdk.ProvenTxReqStatus, skipForStatuses []wdk.ProvenTxReqStatus, txNotes []history.Builder) error
	// ClaimKnownTxsForBroadcast takes ownership of the given transactions for an imminent
	// post and returns those actually claimed. Transactions that are no longer claimable
	// (aborted/parked, terminal, or already accepted) are not returned and must not be posted.
	ClaimKnownTxsForBroadcast(ctx context.Context, txIDs []string) ([]string, error)
	// ParkUnbroadcastKnownTx marks a KnownTx as invalidTx, but only while it provably never
	// reached a broadcaster (never-posted status, was_broadcast false, zero attempts).
	// Returns applied=false (writing nothing) when the guard holds.
	ParkUnbroadcastKnownTx(ctx context.Context, txID string, txNotes []history.Builder) (bool, error)
	SetBatchForKnownTxs(ctx context.Context, txIDs []string, batch string) error
	// FailKnownTxAsDoubleSpend atomically applies the terminal double-spend failure
	// (KnownTx -> doubleSpend guarded by skipForStatuses FIRST; Transactions -> failed and
	// spent outputs restored only when the guarded transition applied). Returns
	// applied=false (and writes nothing) when the guard held.
	FailKnownTxAsDoubleSpend(ctx context.Context, txID string, skipForStatuses []wdk.ProvenTxReqStatus, txNotes []history.Builder) (bool, error)
	// AdvanceKnownTxToBroadcasted atomically advances a tx to the post-broadcast state
	// (KnownTx -> unmined guarded by skipForStatuses FIRST; Transactions -> unproven and
	// UTXOs for spendable change outputs only when the guarded transition applied). Returns
	// applied=false (and writes nothing) when the guard held.
	AdvanceKnownTxToBroadcasted(ctx context.Context, txID string, skipForStatuses []wdk.ProvenTxReqStatus, txNotes []history.Builder) (bool, error)
	// RequeueKnownTxForRebroadcast atomically demotes an in-flight broadcast tx back to the
	// rebroadcast queue (KnownTx -> unsent with rebroadcast_attempts+1, or terminal invalid
	// when the budget is exhausted), guarded by fromStatuses inside the UPDATE. Returns the
	// resulting status and applied=false (writing nothing) when the guard held.
	RequeueKnownTxForRebroadcast(ctx context.Context, txID string, maxRebroadcastAttempts uint64, fromStatuses []wdk.ProvenTxReqStatus, txNotes []history.Builder) (wdk.ProvenTxReqStatus, bool, error)
}

type KeyValueRepo interface {
	Get(ctx context.Context, key string) ([]byte, bool, error)
	Set(ctx context.Context, key string, value []byte) error
}

type CommissionRepo interface {
	AddCommission(ctx context.Context, commission *pkgentity.Commission) error
	FindCommission(ctx context.Context, userID int, transactionID uint) (*pkgentity.Commission, error)
}

type UTXORepo interface {
	UnreserveUTXOsByTransactionID(ctx context.Context, transactionID uint) error
	CreateUTXOForSpendableOutputsByTxID(ctx context.Context, txID string) error
	MakeChangeSpendableAndIndexByTxID(ctx context.Context, txID string) error
}

type Providers interface {
	TransactionsRepo() TransactionsRepo
	OutputRepo() OutputRepo
	KnownTxRepo() KnownTxRepo
	UTXORepo() UTXORepo
	BasketRepo() BasketRepo
	CommissionRepo() CommissionRepo
	KeyValueRepo() KeyValueRepo
}

type UnitOfWork interface {
	Do(ctx context.Context, fn func(ctx context.Context, p Providers) error) error
}
