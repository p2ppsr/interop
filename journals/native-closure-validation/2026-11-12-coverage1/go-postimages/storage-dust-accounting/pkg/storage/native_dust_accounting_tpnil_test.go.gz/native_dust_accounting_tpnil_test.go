package storage_test

import (
	"encoding/json"
	"fmt"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/defs"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/fixtures"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/fixtures/testusers"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/satoshi"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/storage/internal/testabilities"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk/primitives"
	"github.com/stretchr/testify/require"
	"testing"
)

// Real SQLite allocation -> CreateAction -> authenticated listActions: the
// stored signed-net balance must reflect actual change outputs, including dust.
func TestTPNILDustAccountingStoredDebitRPC(t *testing.T) {
	for _, amount := range []int64{50, 1000} {
		t.Run(fmt.Sprint(amount), func(t *testing.T) {
			given, cleanup := testabilities.Given(t)
			defer cleanup()
			provider := given.Provider().WithFeeModel(defs.FeeModel{Type: defs.SatPerKB, Value: 100}).GORM()
			given.Faucet(provider, testusers.Alice).TopUp(satoshi.Value(amount))
			args := fixtures.DefaultValidCreateActionArgs()
			args.Outputs[0].Satoshis = 13
			args.Labels = []primitives.StringUnder300{"dust accounting"}
			created, err := provider.CreateAction(t.Context(), testusers.Alice.AuthID(), args)
			require.NoError(t, err)
			var allocated, change, outputs int64
			for _, in := range created.Inputs {
				allocated += in.SourceSatoshis
			}
			for _, out := range created.Outputs {
				outputs += int64(out.Satoshis)
				if out.ProvidedBy == wdk.ProvidedByStorage {
					change += int64(out.Satoshis)
				}
			}
			require.Equal(t, amount, allocated)
			require.Greater(t, allocated-outputs, int64(0))
			if amount == 50 {
				require.Zero(t, change)
				require.Equal(t, int64(37), allocated-outputs)
			} else {
				require.Positive(t, change)
			}
			stored, err := provider.TransactionEntity().Read().Reference().Equals(created.Reference).Find(t.Context())
			require.NoError(t, err)
			require.Len(t, stored, 1)
			require.Equal(t, change-allocated, stored[0].Satoshis, "history debit must include dust actually paid to miner")
			stop := given.StartedRPCServerFor(provider)
			defer stop()
			response := callJSONRPC(t, given.ServerURL(), testusers.Alice, "listActions", []any{testusers.Alice.AuthID(), wdk.ListActionsArgs{Labels: args.Labels, Limit: 10}})
			require.Nil(t, response.Error)
			var result struct {
				Actions []struct {
					Satoshis int64 `json:"satoshis"`
				}
			}
			require.NoError(t, json.Unmarshal(response.Result, &result))
			require.Len(t, result.Actions, 1)
			require.Equal(t, change-allocated, result.Actions[0].Satoshis)
			denied := callJSONRPC(t, given.ServerURL(), testusers.Bob, "listActions", []any{testusers.Alice.AuthID(), wdk.ListActionsArgs{Labels: args.Labels, Limit: 10}})
			require.NotNil(t, denied.Error)
		})
	}
}
