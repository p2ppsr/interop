package funder

import (
	"fmt"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/defs"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/satoshi"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/database/models"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/txutils"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
	"github.com/stretchr/testify/require"
	"testing"
)

// Conservation uses only actually emitted change. A discarded dust remainder is
// miner fee, never a wallet credit. Repeated observation must not add it twice.
func TestTPNILDustAccountingConservesActualOutputs(t *testing.T) {
	for _, rate := range []int64{1, 100, 500} {
		for _, amount := range []uint64{50, 100, 500, 1000, 10000} {
			t.Run(fmt.Sprintf("rate%d-input%d", rate, amount), func(t *testing.T) {
				c, err := newCollector(13, 44, 1, 1, 1000, newFeeCalculator(defs.FeeModel{Type: defs.SatPerKB, Value: rate}), 8, false)
				require.NoError(t, err)
				require.NoError(t, c.allocateUTXO(&models.UserUTXO{OutputID: 1, Satoshis: amount, EstimatedInputSize: txutils.P2PKHEstimatedInputSize}))
				if !c.IsFunded() {
					_, err := c.GetResult()
					require.ErrorIs(t, err, wdk.ErrNotEnoughFunds)
					return
				}
				result, err := c.GetResult()
				require.NoError(t, err)
				emitted := result.ChangeAmount
				if result.ChangeOutputsCount == 0 {
					emitted = 0
					require.Zero(t, result.ChangeAmount, "no output cannot credit phantom change")
				}
				require.Equal(t, satoshi.Value(amount), satoshi.MustAdd(13, satoshi.MustAdd(emitted, result.Fee)), "allocated value must equal recipient + emitted change + actual fee")
				again, err := c.GetResult()
				require.NoError(t, err)
				require.Equal(t, result, again, "reading result twice must not double-charge dust")
			})
		}
	}
}
