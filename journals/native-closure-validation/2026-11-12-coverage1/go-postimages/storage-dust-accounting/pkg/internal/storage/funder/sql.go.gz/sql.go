package funder

import (
	"context"
	"fmt"
	"log/slog"
	"math"
	"slices"
	"sync/atomic"

	"github.com/go-softwarelab/common/pkg/must"
	"github.com/go-softwarelab/common/pkg/to"
	"gorm.io/gorm"

	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/defs"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/entity"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/satoshi"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/database/models"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/queryopts"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/txutils"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/logging"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
)

var changeOutputSize = txutils.P2PKHOutputSize

const (
	// utxoBatchSize is the page size of the exhaustive pager used by the sweep path.
	utxoBatchSize = 1000
	// insufficientBatchSize bounds how many largest-insufficient UTXOs are fetched
	// per micro-query on the non-sweep path; it amortizes round trips when many
	// small inputs are needed while keeping the number of locked rows small.
	insufficientBatchSize = 16
)

type UTXORepository interface {
	// FindNotReservedUTXOsForUpdate is the exhaustive, ordered, deduped pager — used
	// only by the sweep path, which genuinely needs every eligible row.
	FindNotReservedUTXOsForUpdate(
		ctx context.Context,
		tx *gorm.DB,
		userID int,
		basketName string,
		page *queryopts.Paging,
		forbiddenOutputIDs []uint,
		includeSending bool,
	) ([]*models.UserUTXO, error)
	// FindSmallestSufficientUTXOForUpdate returns the UTXO with the smallest
	// satoshis >= minSatoshis in q's status tier (nil, nil when none).
	FindSmallestSufficientUTXOForUpdate(
		ctx context.Context,
		tx *gorm.DB,
		q wdk.BoundedUTXOQuery,
		minSatoshis uint64,
	) (*models.UserUTXO, error)
	// FindLargestInsufficientUTXOsForUpdate returns up to limit UTXOs with
	// satoshis < maxSatoshis in q's status tier, largest first.
	FindLargestInsufficientUTXOsForUpdate(
		ctx context.Context,
		tx *gorm.DB,
		q wdk.BoundedUTXOQuery,
		maxSatoshis uint64,
		limit int,
	) ([]*models.UserUTXO, error)
}

type SQL struct {
	logger                *slog.Logger
	utxoRepository        UTXORepository
	feeCalculator         *feeCalc
	maxChangeOutputsPerTx atomic.Uint64
}

// NewSQL creates a new SQL funder. maxChangeOutputsPerTx limits how many change outputs are created
// per transaction; it can be updated at runtime via SetMaxChangeOutputsPerTx.
//
// Without this cap the wallet would attempt to create numberOfDesiredUTXOs change outputs in a
// single transaction, producing a very large transaction whose raw bytes are embedded in the BEEF
// of every subsequent child transaction. With the cap the UTXO pool builds gradually.
func NewSQL(logger *slog.Logger, utxoRepository UTXORepository, feeModel defs.FeeModel, maxChangeOutputsPerTx uint64) *SQL {
	logger = logging.Child(logger, "funderSQL")
	feeCalculator := newFeeCalculator(feeModel)

	s := &SQL{
		logger:         logger,
		utxoRepository: utxoRepository,
		feeCalculator:  feeCalculator,
	}
	s.maxChangeOutputsPerTx.Store(maxChangeOutputsPerTx)
	return s
}

// SetMaxChangeOutputsPerTx updates the per-transaction change output cap at runtime.
// Takes effect on the next Fund() call.
func (f *SQL) SetMaxChangeOutputsPerTx(n uint64) {
	f.maxChangeOutputsPerTx.Store(n)
}

// Constraints tune a single funding call beyond the legacy parameters.
// The zero value reproduces legacy behavior exactly.
type Constraints struct {
	// Tiers overrides the status tier walk when non-nil. nil keeps the legacy
	// tiers: mined, unproven, plus sending when includeSending is set.
	Tiers []wdk.UTXOStatus
	// MaxChangeOutputs caps change outputs for this call when > 0; 0 uses the
	// funder-wide (atomic) maxChangeOutputsPerTx.
	MaxChangeOutputs uint64
}

// SpendTiers maps a spend policy to the status tier walk used by the
// throughput strategy, safest first.
func SpendTiers(policy defs.SpendPolicy) []wdk.UTXOStatus {
	switch policy {
	case defs.SpendPolicyMinedOnly:
		return []wdk.UTXOStatus{wdk.UTXOStatusMined}
	case defs.SpendPolicyAny:
		return []wdk.UTXOStatus{wdk.UTXOStatusMined, wdk.UTXOStatusUnproven, wdk.UTXOStatusSending}
	case defs.SpendPolicyPreferMined:
		return []wdk.UTXOStatus{wdk.UTXOStatusMined, wdk.UTXOStatusUnproven}
	default:
		return []wdk.UTXOStatus{wdk.UTXOStatusMined, wdk.UTXOStatusUnproven}
	}
}

// FundArgs groups the inputs for a single Fund / FundWithConstraints call.
// Existing must be pre-fetched via CountUTXOs BEFORE opening the DB transaction
// to avoid a SQLite connection-pool deadlock (the transaction holds the one connection).
type FundArgs struct {
	TargetSat          satoshi.Value
	CurrentTxSize      uint64
	OutputCount        uint64
	Basket             *entity.OutputBasket
	UserID             int
	ForbiddenOutputIDs []uint
	PriorityOutputs    []*entity.Output
	IncludeSending     bool
	IsSweep            bool
	Existing           int64
	Constraints        Constraints
	Tx                 *gorm.DB
}

// Fund selects and allocates UTXOs to cover targetSat within the provided DB transaction tx.
// existing must be pre-fetched via CountUTXOs BEFORE opening the DB transaction to avoid a
// SQLite connection-pool deadlock (the transaction holds the one connection).
func (f *SQL) Fund(
	ctx context.Context,
	targetSat satoshi.Value,
	currentTxSize uint64,
	outputCount uint64,
	basket *entity.OutputBasket,
	userID int,
	forbiddenOutputIDs []uint,
	priorityOutputs []*entity.Output,
	includeSending bool,
	isSweep bool,
	existing int64,
	tx *gorm.DB,
) (*Result, error) {
	return f.FundWithConstraints(ctx, FundArgs{
		TargetSat:          targetSat,
		CurrentTxSize:      currentTxSize,
		OutputCount:        outputCount,
		Basket:             basket,
		UserID:             userID,
		ForbiddenOutputIDs: forbiddenOutputIDs,
		PriorityOutputs:    priorityOutputs,
		IncludeSending:     includeSending,
		IsSweep:            isSweep,
		Existing:           existing,
		Tx:                 tx,
	})
}

// FundWithConstraints is Fund with per-call Constraints; the zero-value
// Constraints field reproduces Fund exactly.
func (f *SQL) FundWithConstraints(ctx context.Context, args FundArgs) (*Result, error) {
	maxChangeOutputs := f.maxChangeOutputsPerTx.Load()
	if args.Constraints.MaxChangeOutputs > 0 {
		maxChangeOutputs = args.Constraints.MaxChangeOutputs
	}

	collector, err := newCollector(
		args.TargetSat,
		args.CurrentTxSize,
		args.OutputCount,
		args.Basket.NumberOfDesiredUTXOs-args.Existing,
		args.Basket.MinimumDesiredUTXOValue,
		f.feeCalculator,
		maxChangeOutputs,
		args.IsSweep,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to start collecting utxo: %w", err)
	}

	// Phase 1: Allocate priority outputs (noSend change from prior TXs in same batch).
	if err = f.allocatePriorityOutputs(collector, args.PriorityOutputs, args.ForbiddenOutputIDs, args.IsSweep); err != nil {
		return nil, err
	}
	if !args.IsSweep && collector.IsFunded() {
		return collector.GetResult()
	}

	// Phase 2: Sweep mode — load every eligible UTXO and allocate everything.
	if args.IsSweep {
		pool, poolErr := f.loadUTXOPool(ctx, args.Tx, args.UserID, args.Basket.Name, args.ForbiddenOutputIDs, args.IncludeSending)
		if poolErr != nil {
			return nil, poolErr
		}
		return f.allocateSweep(collector, pool)
	}

	// Phase 3: Bounded tiered best-fit selection — per-allocation target-aware
	// micro-queries instead of loading (and locking) the whole pool.
	//
	// Every row allocated is appended to the exclusion list: our own row locks
	// don't block our own queries and reserved_by_id stays NULL until
	// reserveUTXOs runs, so without the exclusion the same row would be returned again.
	allocator := f.newBoundedAllocator(args.Tx, args.UserID, args.Basket.Name, collector, args.ForbiddenOutputIDs)
	if err = allocator.run(ctx, resolveTiers(args.IncludeSending, args.Constraints.Tiers)); err != nil {
		return nil, err
	}

	return collector.GetResult()
}

// resolveTiers returns the status tier walk for a funding call: an explicit
// override when provided, otherwise the legacy mined → unproven (+ sending)
// order used by Fund.
func resolveTiers(includeSending bool, tierOverride []wdk.UTXOStatus) []wdk.UTXOStatus {
	if tierOverride != nil {
		return tierOverride
	}
	tiers := []wdk.UTXOStatus{wdk.UTXOStatusMined, wdk.UTXOStatusUnproven}
	if includeSending {
		tiers = append(tiers, wdk.UTXOStatusSending)
	}
	return tiers
}

// newBoundedAllocator builds the per-call allocator that funds via micro-queries.
func (f *SQL) newBoundedAllocator(
	tx *gorm.DB,
	userID int,
	basketName string,
	collector *utxoCollector,
	forbiddenOutputIDs []uint,
) *boundedAllocator {
	return &boundedAllocator{
		repo:       f.utxoRepository,
		tx:         tx,
		userID:     userID,
		basketName: basketName,
		collector:  collector,
		excluded:   slices.Clone(forbiddenOutputIDs),
	}
}

// boundedAllocator carries the invariant state of a single bounded funding pass so the
// per-round/per-tier helpers stay small (in both parameter count and cognitive complexity).
// excluded grows as rows are allocated and is threaded through every query in the pass: our
// own row locks don't block our own queries and reserved_by_id stays NULL until reserveUTXOs
// runs, so without the exclusion the same row would be returned again.
type boundedAllocator struct {
	repo       UTXORepository
	tx         *gorm.DB
	userID     int
	basketName string
	collector  *utxoCollector
	excluded   []uint
}

// run drives allocation rounds until the collector is funded (nil), a round recomputes a
// non-positive remaining need (nil — GetResult then decides funded vs. ErrNotEnoughFunds),
// or a full pass over all tiers allocates nothing (wdk.ErrNotEnoughFunds).
func (a *boundedAllocator) run(ctx context.Context, tiers []wdk.UTXOStatus) error {
	for !a.collector.IsFunded() {
		remaining := a.collector.remaining()
		if remaining <= 0 {
			return nil
		}

		allocated, err := a.round(ctx, tiers, remaining)
		if err != nil {
			return err
		}
		if !allocated {
			return wdk.ErrNotEnoughFunds
		}
	}
	return nil
}

// round tries each tier safest-first and stops at the first tier that allocates a row.
func (a *boundedAllocator) round(ctx context.Context, tiers []wdk.UTXOStatus, remaining satoshi.Value) (bool, error) {
	for _, tier := range tiers {
		allocated, err := a.fromTier(ctx, tier, remaining)
		if err != nil {
			return false, err
		}
		if allocated {
			return true, nil
		}
	}
	return false, nil
}

// fromTier applies stages 1+2 (smallest sufficient — exact match, else smallest >= remaining)
// then stage 3 (largest insufficient batch) of the old in-memory selectBest within one tier.
func (a *boundedAllocator) fromTier(ctx context.Context, tier wdk.UTXOStatus, remaining satoshi.Value) (bool, error) {
	q := wdk.BoundedUTXOQuery{
		UserID:            a.userID,
		BasketName:        a.basketName,
		Status:            tier,
		ExcludedOutputIDs: a.excluded,
	}

	utxo, err := a.repo.FindSmallestSufficientUTXOForUpdate(ctx, a.tx, q, remaining.MustUInt64())
	if err != nil {
		return false, fmt.Errorf("failed to find sufficient utxo: %w", err)
	}
	if utxo != nil {
		if err = a.collector.allocateUTXO(utxo); err != nil {
			return false, fmt.Errorf("failed to allocate utxo: %w", err)
		}
		a.excluded = append(a.excluded, utxo.OutputID)
		return true, nil
	}

	batch, err := a.repo.FindLargestInsufficientUTXOsForUpdate(ctx, a.tx, q, remaining.MustUInt64(), insufficientBatchSize)
	if err != nil {
		return false, fmt.Errorf("failed to find insufficient utxos: %w", err)
	}
	return a.drainBatch(batch)
}

// drainBatch consumes the DESC largest-insufficient batch while each row stays equivalent to
// the old pool.selectBest stage-3 pick.
//
// Drain rule (per-step equivalence with the old pool.selectBest): the sufficient query in
// fromTier returned nothing, so every eligible row in this tier is < remaining and the DESC
// batch therefore holds the tier's largest rows overall — batch[i] is always the largest
// still-unallocated row of the tier. Consume batch[i] only while !IsFunded() AND
// batch[i].Satoshis is still below the freshly recomputed remaining: in that case no row
// >= remaining exists (batch[i] is the maximum), so selectBest would pick exactly batch[i]
// (stage 3, largest insufficient). The moment batch[i].Satoshis >= remaining — remaining
// shrank past it, or grew via the dust-floor branch — the "largest insufficient" premise
// breaks and selectBest would instead pick the SMALLEST sufficient row, which need not be
// batch[i]; so we stop draining and re-enter the outer loop, whose sufficient query finds
// that row. Allocating batch[i] anyway would merely overfund harmlessly, but it would
// diverge from the old selection.
func (a *boundedAllocator) drainBatch(batch []*models.UserUTXO) (bool, error) {
	allocated := false
	for _, u := range batch {
		if a.collector.IsFunded() {
			break
		}
		remaining := a.collector.remaining()
		if remaining <= 0 || u.Satoshis >= remaining.MustUInt64() {
			break
		}
		if err := a.collector.allocateUTXO(u); err != nil {
			return allocated, fmt.Errorf("failed to allocate utxo: %w", err)
		}
		a.excluded = append(a.excluded, u.OutputID)
		allocated = true
	}
	return allocated, nil
}

func (f *SQL) allocateSweep(collector *utxoCollector, pool *utxoPool) (*Result, error) {
	for _, utxo := range pool.all() {
		if err := collector.allocateUTXO(utxo); err != nil {
			return nil, fmt.Errorf("failed to allocate utxo in sweep: %w", err)
		}
	}
	return collector.GetResult()
}

func (f *SQL) allocatePriorityOutputs(collector *utxoCollector, priorityOutputs []*entity.Output, forbiddenOutputIDs []uint, isSweep bool) error {
	forbiddenIDs := make(map[uint]struct{}, len(forbiddenOutputIDs))
	for _, id := range forbiddenOutputIDs {
		forbiddenIDs[id] = struct{}{}
	}

	for _, output := range priorityOutputs {
		if _, ok := forbiddenIDs[output.ID]; ok {
			continue
		}

		sats, err := to.UInt64(output.Satoshis)
		if err != nil {
			return fmt.Errorf("failed to convert output satoshis: %d to uint64: %w", output.Satoshis, err)
		}

		var basket string
		if output.BasketName != nil {
			basket = *output.BasketName
		}

		utxo := &models.UserUTXO{
			UserID:             output.UserID,
			OutputID:           output.ID,
			BasketName:         basket,
			Satoshis:           sats,
			EstimatedInputSize: txutils.EstimatedInputSizeByType(wdk.OutputType(output.Type)),
			CreatedAt:          output.CreatedAt,
		}

		if err = collector.allocateUTXO(utxo); err != nil {
			return fmt.Errorf("failed to allocate priority output: %w", err)
		}

		if !isSweep && collector.IsFunded() {
			return nil
		}
	}
	return nil
}

// loadUTXOPool exhaustively pages every eligible UTXO into a tiered pool.
// Sweep-only: the non-sweep path uses bounded micro-queries (see allocateBounded).
func (f *SQL) loadUTXOPool(ctx context.Context, tx *gorm.DB, userID int, basketName string, forbiddenOutputIDs []uint, includeSending bool) (*utxoPool, error) {
	// The repository applies its own ORDER BY (status tier, satoshis ASC, output_id ASC);
	// the Paging struct only supplies OFFSET/LIMIT here.
	page := &queryopts.Paging{
		Limit: utxoBatchSize,
	}

	var allUTXOs []*models.UserUTXO
	seen := make(map[uint]struct{})
	for {
		utxos, err := f.utxoRepository.FindNotReservedUTXOsForUpdate(ctx, tx, userID, basketName, page, forbiddenOutputIDs, includeSending)
		if err != nil {
			return nil, fmt.Errorf("failed to load utxos: %w", err)
		}

		// Dedup while accumulating: under concurrent lock churn between pages, OFFSET
		// pagination can return the same row twice across pages even with a stable
		// ORDER BY, if a row is locked/unlocked and shifts across the offset boundary.
		// Loop termination below is based on the raw page length (pre-dedup), since a
		// full page with duplicates removed must still be followed by another fetch.
		for _, utxo := range utxos {
			if _, ok := seen[utxo.OutputID]; ok {
				continue
			}
			seen[utxo.OutputID] = struct{}{}
			allUTXOs = append(allUTXOs, utxo)
		}

		if len(utxos) < utxoBatchSize {
			break
		}
		page.Next()
	}

	return newUTXOPool(allUTXOs), nil
}

type utxoCollector struct {
	txSats satoshi.Value
	txSize uint64

	fee           satoshi.Value
	feeCalculator *feeCalc

	satsCovered    satoshi.Value
	allocatedUTXOs []*UTXO

	outputCount             uint64
	numberOfDesiredUTXOs    uint64
	minimumDesiredUTXOValue uint64
	maxChangeOutputsPerTx   uint64
	changeOutputsCount      uint64
	changeOutputsSize       uint64
	minimumChange           uint64
	// dustFloor is the minimum satoshi value a change output must have to be economically viable.
	// An output below this threshold costs more to spend in a future transaction than it is worth.
	dustFloor satoshi.Value
	isSweep   bool
}

func newCollector(txSats satoshi.Value, txSize, outputCount uint64, numberOfDesiredUTXOs int64, minimumDesiredUTXOValue uint64, feeCalculator *feeCalc, maxChangeOutputsPerTx uint64, isSweep bool) (c *utxoCollector, err error) {
	c = &utxoCollector{
		txSats:      txSats,
		outputCount: outputCount,
		// Clamped to at least 1: a zero value would divide-by-zero in calculateChangeCount.
		// Baskets should never carry 0 here (see ValidBasketConfiguration and UpdateChangeBasket),
		// but this is the last line of defense against any caller/DB state that slips through.
		minimumDesiredUTXOValue: to.NoLessThan(minimumDesiredUTXOValue, 1),
		maxChangeOutputsPerTx:   maxChangeOutputsPerTx,
		feeCalculator:           feeCalculator,
		allocatedUTXOs:          make([]*UTXO, 0),
		isSweep:                 isSweep,
	}

	err = c.increaseSize(txSize)
	if err != nil {
		return nil, fmt.Errorf("failed to increase transaction size: %w", err)
	}

	c.numberOfDesiredUTXOs = must.ConvertToUInt64(to.NoLessThan(numberOfDesiredUTXOs, 1))

	// Calculate dust floor: the minimum satoshi value for a change output to be worth spending.
	// We model the smallest possible future spend (1 P2PKH input + 1 P2PKH output)
	// and require each output to be worth at least 2× that future fee.
	// The absolute floor of 1 prevents nonsensical behavior at fee rate 0.
	minSpendTxSize := txutils.TransactionSizeFromScriptLengths(
		[]uint64{txutils.P2PKHUnlockingScriptLength},
		[]uint64{txutils.P2PKHLockingScriptLength},
	)
	c.dustFloor = satoshi.Value(math.Max(1, math.Ceil(float64(minSpendTxSize)/1000*feeCalculator.value)*2))

	c.calculateMinimumChange()

	err = c.calculateChangeOutputs()
	if err != nil {
		return nil, fmt.Errorf("failed to calculate change outputs: %w", err)
	}

	return c, nil
}

func (c *utxoCollector) remaining() satoshi.Value {
	if c.outputCount == 0 {
		change := c.change()
		if c.changeOutputsCount > 0 && change < c.dustFloor {
			feeWithNextInput, err := c.feeCalculator.Calculate(c.txSize + txutils.P2PKHEstimatedInputSize)
			if err != nil {
				panic(fmt.Errorf("failed to calculate fee for next change input: %w", err))
			}

			toCover := satoshi.MustAdd(satoshi.MustAdd(c.txSats, feeWithNextInput), c.dustFloor)
			if toCover > c.satsCovered {
				return satoshi.MustSubtract(toCover, c.satsCovered)
			}
		}

		if c.changeOutputsCount == 0 {
			feeWithFirstChangeOutput, err := c.feeCalculator.Calculate(c.txSize + txutils.P2PKHEstimatedInputSize + changeOutputSize)
			if err != nil {
				panic(fmt.Errorf("failed to calculate fee for first change output: %w", err))
			}

			toCover := satoshi.MustAdd(satoshi.MustAdd(c.txSats, feeWithFirstChangeOutput), c.dustFloor)
			if toCover > c.satsCovered {
				return satoshi.MustSubtract(toCover, c.satsCovered)
			}
		}
	}

	return satoshi.MustSubtract(c.satsToCover(), c.satsCovered)
}

func (c *utxoCollector) IsFunded() bool {
	// A valid Bitcoin transaction must have at least one output.
	// If no outputs are defined and no change outputs will be created,
	// we must continue allocating UTXOs to ensure at least one change output exists.
	if c.outputCount == 0 {
		return c.changeOutputsCount > 0 && c.change() >= c.dustFloor
	}

	if c.isSweep {
		return false
	}

	return c.satsCovered >= c.satsToCover()
}

func (c *utxoCollector) GetResult() (*Result, error) {
	if c.IsFunded() || c.isSweep {
		return c.prepareResult()
	}
	return nil, wdk.ErrNotEnoughFunds
}

func (c *utxoCollector) allocateUTXO(utxo *models.UserUTXO) (err error) {
	c.addToAllocated(utxo)

	err = c.increaseSize(utxo.EstimatedInputSize)
	if err != nil {
		return fmt.Errorf("failed to increase tx size: %w", err)
	}

	err = c.increaseValue(satoshi.MustFrom(utxo.Satoshis))
	if err != nil {
		return fmt.Errorf("failed to increase tx value: %w", err)
	}

	err = c.calculateChangeOutputs()
	if err != nil {
		return fmt.Errorf("failed to calculate change outputs: %w", err)
	}

	return nil
}

func (c *utxoCollector) addToAllocated(utxo *models.UserUTXO) {
	c.allocatedUTXOs = append(c.allocatedUTXOs, &UTXO{
		OutputID: utxo.OutputID,
		Satoshis: satoshi.MustFrom(utxo.Satoshis),
	})
}

func (c *utxoCollector) increaseSize(size uint64) (err error) {
	c.txSize += size
	c.fee, err = c.feeCalculator.Calculate(c.txSize)
	if err != nil {
		return fmt.Errorf("failed to calculate fee: %w", err)
	}
	return nil
}

func (c *utxoCollector) increaseValue(sats satoshi.Value) error {
	var err error
	c.satsCovered, err = satoshi.Add(c.satsCovered, sats)
	if err != nil {
		return fmt.Errorf("cannot increase tx value: %w", err)
	}
	return nil
}

func (c *utxoCollector) satsToCover() satoshi.Value {
	return satoshi.MustAdd(c.txSats, c.fee)
}

func (c *utxoCollector) change() satoshi.Value {
	return satoshi.MustSubtract(c.satsCovered, c.satsToCover())
}

func (c *utxoCollector) prepareResult() (*Result, error) {
	changeAmount := c.change()
	actualFee := c.fee

	// Discarded dust is paid to the miner, not credited to the wallet. Keep the
	// returned amount equal to the change outputs actually created so action
	// history and spending limits account for the full debit. Do not mutate the
	// collector fee: repeated GetResult calls must not add the remainder twice.
	if changeAmount < c.dustFloor {
		c.changeOutputsCount = 0
		if changeAmount > 0 {
			var err error
			actualFee, err = satoshi.Add(actualFee, changeAmount)
			if err != nil {
				return nil, fmt.Errorf("failed to include discarded change in fee: %w", err)
			}
			changeAmount = 0
		}
	}

	return &Result{
		AllocatedUTXOs:     c.allocatedUTXOs,
		Fee:                actualFee,
		ChangeAmount:       changeAmount,
		ChangeOutputsCount: c.changeOutputsCount,
		DustFloor:          c.dustFloor,
		ChangeInitialValue: c.changeInitialValue(),
	}, nil
}

func (c *utxoCollector) calculateChangeOutputs() error {
	err := c.setChangeOutputsSize(0)
	if err != nil {
		return fmt.Errorf("failed to reset change outputs size: %w", err)
	}

	change := c.change()
	if change <= 0 {
		c.changeOutputsCount = 0
		return nil
	}

	c.calculateChangeCount(must.ConvertToUInt64(change))
	for {
		err = c.setChangeOutputsSize(c.changeOutputsCount * changeOutputSize)
		if err != nil {
			return fmt.Errorf("failed to set change outputs size: %w", err)
		}

		if c.changeOutputsCount <= 1 || c.changeFitsOutputs() {
			return nil
		}
		c.changeOutputsCount--
	}
}

// changeFitsOutputs reports whether the current change (after fee) can be distributed
// among changeOutputsCount outputs the same way the change distribution will do it.
func (c *utxoCollector) changeFitsOutputs() bool {
	change := c.change()
	if change <= 0 {
		return false
	}

	if change.MustUInt64()/c.changeOutputsCount < c.dustFloor.MustUInt64() {
		return false
	}

	return txutils.NewChangeDistribution(c.changeInitialValue(), nil).CanDistribute(c.changeOutputsCount, change)
}

// changeInitialValue is the minimal value of a (saturated) change output used by the change distribution.
func (c *utxoCollector) changeInitialValue() satoshi.Value {
	initialValue := satoshi.MustFrom(c.minimumDesiredUTXOValue)
	if c.dustFloor > initialValue {
		return c.dustFloor
	}
	return initialValue
}

func (c *utxoCollector) setChangeOutputsSize(size uint64) error {
	c.txSize -= c.changeOutputsSize
	c.changeOutputsSize = size
	return c.increaseSize(size)
}

func (c *utxoCollector) calculateChangeCount(changeVal uint64) {
	c.changeOutputsCount = changeVal/c.minimumDesiredUTXOValue + 1

	if changeVal%c.minimumDesiredUTXOValue < c.minimumChange {
		c.changeOutputsCount -= 1
	}

	capCount := c.numberOfDesiredUTXOs
	if c.maxChangeOutputsPerTx < capCount {
		capCount = c.maxChangeOutputsPerTx
	}

	c.changeOutputsCount = to.ValueBetween(c.changeOutputsCount, 1, capCount)

	dustFloorU64 := c.dustFloor.MustUInt64()
	for c.changeOutputsCount > 1 && changeVal/c.changeOutputsCount < dustFloorU64 {
		c.changeOutputsCount--
	}
}

// calculateMinimumChange determines the minimum change amount based on the **Desired** minimum UTXO value.
// The "desired" minimum UTXO value represents the user's preference for common UTXO values in the basket.
// In contrast, the minimum change is the threshold below which a new UTXO is not created.
func (c *utxoCollector) calculateMinimumChange() {
	c.minimumChange = c.minimumDesiredUTXOValue / 4
}
