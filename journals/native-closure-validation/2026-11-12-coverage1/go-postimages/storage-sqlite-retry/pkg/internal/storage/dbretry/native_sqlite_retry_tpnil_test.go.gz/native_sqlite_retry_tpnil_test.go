package dbretry

import (
	"errors"
	"fmt"
	"testing"

	"github.com/mattn/go-sqlite3"
	"github.com/stretchr/testify/require"
)

func TestNativeSQLiteRetryClassificationTPNIL(t *testing.T) {
	snapshot := sqlite3.Error{Code: sqlite3.ErrBusy, ExtendedCode: sqlite3.ErrBusySnapshot}
	for name, err := range map[string]error{"value": snapshot, "pointer": &snapshot, "wrapped": fmt.Errorf("cannot save known tx: %w", snapshot)} {
		t.Run(name, func(t *testing.T) { require.True(t, Retryable(err)) })
	}
	for name, err := range map[string]error{
		"plain busy":           sqlite3.Error{Code: sqlite3.ErrBusy},
		"busy recovery":        sqlite3.Error{Code: sqlite3.ErrBusy, ExtendedCode: sqlite3.ErrBusyRecovery},
		"locked":               sqlite3.Error{Code: sqlite3.ErrLocked},
		"shared cache locked":  sqlite3.Error{Code: sqlite3.ErrLocked, ExtendedCode: sqlite3.ErrLockedSharedCache},
		"constraint":           sqlite3.Error{Code: sqlite3.ErrConstraint, ExtendedCode: sqlite3.ErrConstraintUnique},
		"contradictory code":   sqlite3.Error{Code: sqlite3.ErrConstraint, ExtendedCode: sqlite3.ErrBusySnapshot},
		"unknown text":         errors.New("database is locked"),
		"wrapped unknown text": fmt.Errorf("cannot save known tx: %w", errors.New("database is locked")),
	} {
		t.Run(name, func(t *testing.T) { require.False(t, Retryable(err)) })
	}
}
