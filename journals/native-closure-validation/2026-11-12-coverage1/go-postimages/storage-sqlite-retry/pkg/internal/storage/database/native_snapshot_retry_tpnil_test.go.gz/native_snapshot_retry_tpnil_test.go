package database

import (
	"context"
	"errors"
	"path/filepath"
	"testing"

	"github.com/mattn/go-sqlite3"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"

	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/defs"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/dbretry"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/logging"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/randomizer"
)

// Exercise the actual configured SQLite driver, GORM rollback, and the same
// outer retry owner used by the storage UOW. Ordering is deterministic: another
// pooled connection commits only after the victim holds its read snapshot.
func TestNativeSnapshotRetryTPNIL(t *testing.T) {
	for _, mode := range []string{"recover", "bounded", "cancel", "no-retry", "committed-once"} {
		t.Run(mode, func(t *testing.T) {
			cfg := defs.DefaultDBConfig()
			cfg.SQLite.ConnectionString = filepath.Join(t.TempDir(), "wallet.sqlite")
			db, err := NewDatabase(cfg, logging.NewTestLogger(t))
			require.NoError(t, err)
			t.Cleanup(func() { require.NoError(t, db.Close()) })
			require.NoError(t, db.DB.Exec("CREATE TABLE snapshot_retry (id INTEGER PRIMARY KEY, value INTEGER NOT NULL)").Error)
			require.NoError(t, db.DB.Exec("INSERT INTO snapshot_retry VALUES (1, 0)").Error)
			var journal string
			var timeout int
			require.NoError(t, db.DB.Raw("PRAGMA journal_mode").Scan(&journal).Error)
			require.NoError(t, db.DB.Raw("PRAGMA busy_timeout").Scan(&timeout).Error)
			require.Equal(t, "wal", journal)
			require.Equal(t, 5000, timeout)
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			attempts, conflicts := 0, 0
			seen := []int{}
			work := func() error {
				attempts++
				return db.DB.Transaction(func(tx *gorm.DB) error {
					var before int
					if err := tx.Raw("SELECT value FROM snapshot_retry WHERE id=1").Scan(&before).Error; err != nil {
						return err
					}
					seen = append(seen, before)
					if mode != "committed-once" && (attempts == 1 || mode == "bounded") {
						if err := db.DB.Exec("UPDATE snapshot_retry SET value=value+10 WHERE id=1").Error; err != nil {
							return err
						}
					}
					err := tx.Exec("UPDATE snapshot_retry SET value=value+1 WHERE id=1").Error
					if err != nil {
						var typed sqlite3.Error
						require.True(t, errors.As(err, &typed))
						require.Equal(t, sqlite3.ErrBusySnapshot, typed.ExtendedCode)
						conflicts++
						if mode == "cancel" {
							cancel()
						}
					}
					return err
				})
			}
			if mode == "no-retry" {
				err = dbretry.NoRetry().Do(ctx, work)
			} else {
				err = dbretry.Do(ctx, logging.NewTestLogger(t), randomizer.New(), work)
			}
			var final int
			require.NoError(t, db.DB.Raw("SELECT value FROM snapshot_retry WHERE id=1").Scan(&final).Error)
			switch mode {
			case "recover":
				require.NoError(t, err)
				require.Equal(t, 2, attempts)
				require.Equal(t, 1, conflicts)
				require.Equal(t, []int{0, 10}, seen)
				require.Equal(t, 11, final)
			case "bounded":
				require.Error(t, err)
				require.Equal(t, dbretry.MaxAttempts, attempts)
				require.Equal(t, attempts, conflicts)
				require.Equal(t, []int{0, 10, 20}, seen)
				require.Equal(t, 30, final)
				var typed sqlite3.Error
				require.True(t, errors.As(err, &typed))
				require.Equal(t, sqlite3.ErrBusySnapshot, typed.ExtendedCode)
			case "cancel":
				require.ErrorIs(t, err, context.Canceled)
				require.Equal(t, 1, attempts)
				require.Equal(t, 10, final)
			case "no-retry":
				require.Error(t, err)
				require.Equal(t, 1, attempts)
				require.Equal(t, 10, final)
			case "committed-once":
				require.NoError(t, err)
				require.Equal(t, 1, attempts)
				require.Zero(t, conflicts)
				require.Equal(t, 1, final)
			}
			t.Logf("mode=%s attempts=%d conflicts=%d seen=%v final=%d error=%v", mode, attempts, conflicts, seen, final, err)
		})
	}
}
