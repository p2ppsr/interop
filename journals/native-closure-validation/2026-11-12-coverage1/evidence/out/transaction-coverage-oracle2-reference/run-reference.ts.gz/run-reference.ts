import fs from 'node:fs'
import { CandidateStorageClient as StorageClient } from './candidate-fixture.ts'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import path from 'node:path'
import { P2PKH, PublicKey } from '@bsv/sdk'
import { ControlledWalletServices } from './isolated-reference/synthesis/src/wallet-lab/services.js'
import { createCandidateFixtureWallet as createFixtureWallet } from './candidate-fixture.ts'
import { EvidenceBundle } from './isolated-reference/synthesis/src/wallet-lab/evidence.js'
import { runNativeTransactionCoverage } from './isolated-reference/synthesis/src/wallet-lab/native/coverage-transactions-producer.js'
import { verifyNativeTransactionCoverage } from './isolated-reference/synthesis/src/wallet-lab/native/coverage-transactions-verifier.js'
const root = "/Users/tyeverett/tmp/network-ops/worktrees/p2ppsr/interop/codex/lab-integration-20261106", out = path.join(import.meta.dirname, `attempt-${Date.now()}`)
fs.mkdirSync(out)
const paths = [...Object.keys(JSON.parse(fs.readFileSync(path.join(import.meta.dirname, 'isolated-reference/source-inventory.json'), 'utf8'))).map(name => 'out/transaction-coverage-oracle2-reference/isolated-reference/' + name), 'out/transaction-coverage-oracle2-reference/isolated-reference/source-inventory.json', 'programs/ISI-4/profiles/native-coverage-transactions-1.0.0/policy.json', 'programs/ISI-4/profiles/native-coverage-transactions-2.0.0/policy.json', 'out/transaction-coverage-oracle2-reference/candidate-fixture.ts', 'out/transaction-coverage-oracle2-reference/candidate-files.json', 'synthesis/package-lock.json', 'out/itcve-go-storage-input-ancestry.json']
const capture = () => Object.fromEntries(paths.map(name => [name, createHash('sha256').update(fs.readFileSync(path.join(root, name))).digest('hex')]))
const before = capture(); fs.writeFileSync(path.join(out,'source-before.json'), JSON.stringify(before,null,2)+'\n')
for(const name of paths) { const dest = path.join(out,'source',name); fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(path.join(root,name),dest) }

const services = new ControlledWalletServices({ webroot: out, components: { storage: 'go' }, go: { binary: path.join(root, 'out/itcve-go-storage-input-ancestry'), storageInputAncestryPatch: true, terminalRejectionReceipts: true } })
const storageTrace: any[] = []
const tracedClient = (owner: any, endpoint: string) => {
  const client: any = new StorageClient(owner, endpoint)
  for (const method of ['createAction', 'internalizeAction']) {
    const original = client[method].bind(client)
    client[method] = async (...args: any[]) => {
      const row: any = { method, args: structuredClone(args) }; storageTrace.push(row)
      try { row.result = await original(...args); return row.result } catch (error: any) { row.error = {name:error.name,message:error.message,code:error.code}; throw error }
    }
  }
  return client
}
let wallet: any, funder: any
try {
  await services.start(); await services.fundRemoteWalletFromTeranode('77'.repeat(32), JSON.parse(fs.readFileSync(path.join(root, 'fixtures/teranode/wab-funding-v1.json'), 'utf8')))
  wallet = await createFixtureWallet(services, '78'.repeat(32), tracedClient); funder = await createFixtureWallet(services, '77'.repeat(32))
  const identity = (await wallet.getPublicKey({ identityKey: true })).publicKey, senderIdentityKey = (await funder.getPublicKey({ identityKey: true })).publicKey
  const derivationPrefix = Buffer.from('extension initial funding').toString('base64'), derivationSuffix = Buffer.from('funding').toString('base64')
  const key = await funder.getPublicKey({ protocolID: [2, '3241645161d8'], keyID: `${derivationPrefix} ${derivationSuffix}`, counterparty: identity })
  const seed = await funder.createAction({ description: 'Transaction coverage reference funding', outputs: [{ satoshis: 50000, lockingScript: new P2PKH().lock(PublicKey.fromString(key.publicKey).toAddress()).toHex(), outputDescription: 'Transaction coverage controlled wallet funds' }], options: { randomizeOutputs: false, acceptDelayedBroadcast: false } })
  await wallet.internalizeAction({ tx: seed.tx, outputs: [{ outputIndex: 0, protocol: 'wallet payment', paymentRemittance: { derivationPrefix, derivationSuffix, senderIdentityKey } }], description: 'Transaction coverage controlled funds' })
  const evidence = new EvidenceBundle(out)
  const report = await runNativeTransactionCoverage({ wallet, funder, identity, services, evidence }, 2); evidence.flush()
  const result = await verifyNativeTransactionCoverage(report)
  fs.writeFileSync(path.join(out, 'verification.json'), JSON.stringify({ ...result, claim: 'LAB_SELF_TEST_ONLY', actualNative: false, calls: report.trace.length, assertions: report.assertions }, null, 2)+'\n')
  fs.writeFileSync(path.join(out, 'global-submissions.json'), JSON.stringify(services.submissions.map(r => ({ txid: r.txid, beefHex: Buffer.from(r.bytes).toString('hex'), verdict: r.verdict })),null,2)+'\n')
  console.log(JSON.stringify({out,calls:report.trace.length,counts:result.counts,failures:report.assertions.filter(x=>x.result!=='PASS')}))
} finally {
  fs.writeFileSync(path.join(out,'storage-client-trace.json'),JSON.stringify(storageTrace,null,2)+'\n')
  const closure = services.observeSubmissionClosure(), startedAt = new Date().toISOString()
  await wallet?.destroy(); await funder?.destroy()
  fs.writeFileSync(path.join(out,'final-storage-transactions.json'),JSON.stringify(await services.nativeTransactions(),null,2)+'\n')
  await services.close()
  const providers = closure.readFinalProviders()
  fs.writeFileSync(path.join(out,'final-submissions.json'),JSON.stringify(providers.flatMap(provider => provider.submissions),null,2)+'\n')
  fs.writeFileSync(path.join(out,'local-service-closure.json'),JSON.stringify({claim:'LAB_SELF_TEST_ONLY',actualNative:false,startedAt,completedAt:new Date().toISOString(),servicesClosed:true,initialProviders:closure.initialProviders,finalProviders:providers},null,2)+'\n')
  const after=capture(); fs.writeFileSync(path.join(out,'source-after.json'),JSON.stringify(after,null,2)+'\n'); assert.deepEqual(after,before,'Executed source changed during reference run') }
