import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { Beef,P2PKH,PrivateKey,ProtoWallet,PublicKey,Transaction } from '@bsv/sdk'
import { observedSubmissionTransactions } from '../transaction-coverage-sqlite-retry-reference/isolated-reference/synthesis/src/wallet-lab/native/verify-transaction-state-bindings.ts'
const root=path.resolve(import.meta.dirname,'../..'),directory=path.join(import.meta.dirname,'fresh-pool-1794471403923')
const json=(n:string)=>JSON.parse(fs.readFileSync(path.join(directory,n),'utf8'))
const trace=json('trace.json'),initial=json('initial-outputs.json'),result=json('result.json'),storage=new Map<string,string>(json('final-storage.json').map((r:any)=>[r.txid,r.rawTxHex])),events=json('events.json'),providers=json('final-submissions.json')
assert.deepEqual(json('source-before.json'),json('source-after.json'))
const fixture=JSON.parse(fs.readFileSync(path.join(root,'fixtures/teranode/wab-funding-v1.json'),'utf8')),tracker={currentHeight:async()=>fixture.fundingHeight+fixture.maturityDepth,isValidRootForHeight:async(r:string,h:number)=>r===fixture.merkleRoot&&h===fixture.fundingHeight}
const graph=new Map<string,Transaction>(),visit=(tx:Transaction)=>{const id=tx.id('hex');if(graph.has(id)){assert.equal(graph.get(id)!.toHex(),tx.toHex());return}graph.set(id,tx);for(const input of tx.inputs)if(input.sourceTransaction)visit(input.sourceTransaction)}
const rows=trace.filter((r:any)=>r.result?.tx)
assert.deepEqual(rows.map((r:any)=>r.id),['funding-0','funding-1','funding-2','setup-basket','payment-0','payment-1','payment-2'])
for(const row of rows){const tx=Transaction.fromAtomicBEEF(row.result.tx);assert.equal(tx.id('hex'),row.result.txid);assert.equal(storage.get(row.result.txid),tx.toHex());assert.ok(await tx.verify(tracker));const beef=Beef.fromBinary(tx.toAtomicBEEF());assert.equal(beef.findTxid(fixture.txid)?.tx?.toHex(),fixture.rawHex);assert.ok(await beef.verify(tracker));visit(tx)}
assert.equal(initial.providers.length,1);const outputs=initial.providers[0].snapshot.outputs;assert.equal(outputs.length,3)
const sender=new ProtoWallet(PrivateKey.fromHex('77'.repeat(32))),senderIdentityKey=(await sender.getPublicKey({identityKey:true})).publicKey
for(let index=0;index<3;index++){
 const row=trace.find((r:any)=>r.id===`funding-${index}`),internalized=trace.find((r:any)=>r.id===`internalize-${index}`),point=`${row.result.txid}.0`,observed=outputs.find((r:any)=>r.outpoint===point)
 assert.ok(observed);assert.equal(observed.satoshis,10000);assert.equal(observed.basketName,'default');assert.equal(observed.spendable,true);assert.equal(observed.rawTx,storage.get(row.result.txid))
 const derivationPrefix=Buffer.from('fresh permission reserves').toString('base64'),derivationSuffix=Buffer.from(`reserve${index}`).toString('base64')
 const key=await sender.getPublicKey({protocolID:[2,'3241645161d8'],keyID:`${derivationPrefix} ${derivationSuffix}`,counterparty:initial.identityKey})
 assert.equal(observed.lockingScript,new P2PKH().lock(PublicKey.fromString(key.publicKey).toAddress()).toHex());assert.deepEqual(internalized.args.outputs,[{outputIndex:0,protocol:'wallet payment',paymentRemittance:{derivationPrefix,derivationSuffix,senderIdentityKey}}]);assert.equal(internalized.result.accepted,true)
}
const script=new P2PKH().lock(PrivateKey.fromHex('68'.repeat(32)).toPublicKey().toAddress()).toHex()
const debits=[]
for(let index=0;index<3;index++){
 const call=trace.find((r:any)=>r.id===`payment-${index}`);assert.equal(call.args.inputs,undefined);assert.equal(call.args.inputBEEF,undefined);assert.deepEqual(call.args.options,{randomizeOutputs:false,acceptDelayedBroadcast:false})
 const tx=graph.get(call.result.txid)!;assert.equal(tx.inputs.length,1);assert.equal(tx.outputs.length,2);assert.equal(tx.outputs[0]!.lockingScript.toHex(),script);assert.equal(tx.outputs[0]!.satoshis,[11,13,7][index])
 const fee=tx.inputs[0]!.sourceTransaction!.outputs[tx.inputs[0]!.sourceOutputIndex]!.satoshis!-tx.outputs.reduce((n,o)=>n+o.satoshis!,0);assert.equal(fee,23);debits.push(fee+tx.outputs[0]!.satoshis!)
}
assert.deepEqual(debits,[34,36,30]);assert.equal(events.filter((e:any)=>e.kind==='group').length,1);assert.equal(events.find((e:any)=>e.kind==='group').event.permissions.spendingAuthorization.amount,100)
const overflow=trace.find((r:any)=>r.id==='overflow');assert.equal(overflow.result,undefined);assert.equal(overflow.error.code,'ERR_PERMISSION_DENIED')
const ledger=providers.flatMap((p:any)=>p.submissions);assert.equal(ledger.length,7);assert.equal(new Set(ledger.map((r:any)=>r.txid)).size,7)
let inspected=0
for(const row of ledger){assert.ok(rows.some((r:any)=>r.result.txid===row.txid));for(const entry of observedSubmissionTransactions(row,{resolvedTransactions:graph,requireResolvedAncestors:true,trustedMinedRoot:fixture})){inspected++;assert.ok(!entry.transaction.outputs.some(o=>o.satoshis===53&&o.lockingScript.toHex()===script),'Denied payment leaked in final target/ancestor')}}
const receipt={claim:'LAB_SELF_TEST_ONLY',actualNative:false,verified:true,exactInitialManagedOutputs:3,initialSatoshisEach:10000,publicGroupedCap:100,actualFees:[23,23,23],debits,exactTotal:100,fullSignedTransactionStorageAndMinedProofs:rows.length,finalLedgerTargets:ledger.length,reachableFinalTransactionsInspected:inspected,deniedPaymentAbsent:true,files:Object.fromEntries(['trace.json','initial-outputs.json','final-storage.json','events.json','result.json','final-submissions.json','source-before.json','source-after.json'].map(n=>[n,createHash('sha256').update(fs.readFileSync(path.join(directory,n))).digest('hex')]))}
fs.writeFileSync(path.join(directory,'independent-verification.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt))
