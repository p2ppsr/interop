import fs from 'node:fs'
import path from 'node:path'
import http from 'node:http'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { P2PKH, PrivateKey, PublicKey, Transaction } from '@bsv/sdk'
import { ControlledWalletServices } from '../transaction-coverage-sqlite-retry-reference/isolated-reference/synthesis/src/wallet-lab/services.ts'
import { createCandidateFixtureWallet } from '../transaction-coverage-sqlite-retry-reference/candidate-fixture.ts'
import { LocalWalletPermissionsManager, InMemoryPermissionStore } from '/Users/tyeverett/tmp/network-ops/worktrees/ty-everett/yours-wallet/codex/ghsa-5vmp-dependency-upgrade/node_modules/@1sat/wallet/dist/permissions/index.js'

const root=path.resolve(import.meta.dirname,'../..'),out=path.join(import.meta.dirname,`fresh-pool-${Date.now()}`);fs.mkdirSync(out)
const yours='/Users/tyeverett/tmp/network-ops/worktrees/ty-everett/yours-wallet/codex/ghsa-5vmp-dependency-upgrade'
const inputs=[import.meta.filename,path.join(root,'out/itcve-go-storage-sqlite-retry.json'),path.join(root,'out/transaction-coverage-sqlite-retry-reference/candidate-fixture.ts'),path.join(root,'out/transaction-coverage-sqlite-retry-reference/candidate-package/out/index.client.mjs'),path.join(yours,'node_modules/@bsv/wallet-toolbox-client/out/index.client.mjs'),...['manager.js','key.js','in-memory-store.js','index.js'].map(n=>path.join(yours,'node_modules/@1sat/wallet/dist/permissions',n))]
const snapshotRoot=path.join(root,'out/transaction-coverage-sqlite-retry-reference/isolated-reference')
inputs.push(...Object.keys(JSON.parse(fs.readFileSync(path.join(snapshotRoot,'source-inventory.json'),'utf8'))).map(n=>path.join(snapshotRoot,n)))
const hash=(p:string)=>createHash('sha256').update(fs.readFileSync(p)).digest('hex')
const capture=()=>Object.fromEntries(inputs.map(p=>[p,hash(p)]));const before=capture();fs.writeFileSync(path.join(out,'source-before.json'),JSON.stringify(before,null,2)+'\n')
assert.equal(hash(inputs[3]!),hash(inputs[4]!), 'Manager and underlying Wallet must use exact same candidate package')
const services=new ControlledWalletServices({webroot:out,components:{storage:'go'},go:{binary:path.join(root,'out/itcve-go-storage-sqlite-retry'),storageSQLiteRetryPatch:true,terminalRejectionReceipts:true}})
const trace:any[]=[],events:any[]=[],manifest={name:'TPNIL fresh reserve permission preflight',metanet:{groupPermissions:{description:'Standing allowance preflight',spendingAuthorization:{amount:100,description:'100-satoshi monthly allowance'}}}}
const server=http.createServer((req,res)=>{events.push({kind:'manifest-request',url:req.url});if(req.url!='/manifest.json'){res.writeHead(404);res.end();return}res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(manifest))})
let wallet:any,funder:any,manager:any
const call=async(id:string,target:any,method:string,args:any,origin?:string)=>{const row:any={id,method,args,origin};trace.push(row);try{row.result=await target[method](args,origin);return row.result}catch(e:any){row.error={name:e.name,message:e.message,code:e.code};throw e}}
const store=new InMemoryPermissionStore()
let origin=''
const makeManager=()=>{const value=new LocalWalletPermissionsManager(wallet,'yours-wallet',{encryptWalletMetadata:false,seekGroupedPermission:true,seekPermissionWhenApplyingActionLabels:false},{store});value.bindCallback('onGroupedPermissionRequested',async(event:any)=>{events.push({kind:'group',event});assert.equal(event.permissions.spendingAuthorization.amount,100);await value.grantGroupedPermission({requestID:event.requestID,granted:event.permissions,expiry:0})});value.bindCallback('onSpendingAuthorizationRequested',async(event:any)=>{events.push({kind:'spending',event});await value.denyPermission(event.requestID)});return value}
try{
 await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));origin=`localhost:${(server.address() as any).port}`
 await services.start();await services.fundRemoteWalletFromTeranode('77'.repeat(32),JSON.parse(fs.readFileSync(path.join(root,'fixtures/teranode/wab-funding-v1.json'),'utf8')))
 funder=await createCandidateFixtureWallet(services,'77'.repeat(32));wallet=await createCandidateFixtureWallet(services,'78'.repeat(32))
 const identity=(await wallet.getPublicKey({identityKey:true})).publicKey,senderIdentityKey=(await funder.getPublicKey({identityKey:true})).publicKey
 const roots=[]
 for(let i=0;i<3;i++){
  const derivationPrefix=Buffer.from('fresh permission reserves').toString('base64'),derivationSuffix=Buffer.from(`reserve${i}`).toString('base64')
  const key=await funder.getPublicKey({protocolID:[2,'3241645161d8'],keyID:`${derivationPrefix} ${derivationSuffix}`,counterparty:identity})
  const seed=await call(`funding-${i}`,funder,'createAction',{description:'Fresh permission initial reserve',outputs:[{satoshis:10000,lockingScript:new P2PKH().lock(PublicKey.fromString(key.publicKey).toAddress()).toHex(),outputDescription:'Initial native-owned reserve'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}})
  await call(`internalize-${i}`,wallet,'internalizeAction',{tx:seed.tx,outputs:[{outputIndex:0,protocol:'wallet payment',paymentRemittance:{derivationPrefix,derivationSuffix,senderIdentityKey}}],description:'Fresh permission reserve'})
  roots.push(`${seed.txid}.0`)
 }
 const initial=await services.nativeOutputSnapshots(identity);fs.writeFileSync(path.join(out,'initial-outputs.json'),JSON.stringify(initial,null,2)+'\n')
 const owned=initial.providers.flatMap((p:any)=>p.snapshot.outputs);assert.equal(owned.length,3);assert.deepEqual(owned.map((r:any)=>r.satoshis).sort(),[10000,10000,10000])
 await call('setup-basket',wallet,'createAction',{description:'TPNIL permission coverage basket fixture',outputs:[{satoshis:3,lockingScript:'51',basket:'tpnil coverage persistence v1',outputDescription:'Native permission coverage fixture',customInstructions:'tpnil:permission-coverage:1'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}})
 manager=makeManager();await call('manifest-grant',manager,'waitForAuthentication',{},origin)
 const script=new P2PKH().lock(PrivateKey.fromHex('68'.repeat(32)).toPublicKey().toAddress()).toHex(),payments:any[]=[]
 for(const [index,amount] of [11,13,7].entries()){
  const value=await call(`payment-${index}`,manager,'createAction',{description:`TPNIL coverage allowance ${['first','second','third'][index]}`,outputs:[{satoshis:amount,lockingScript:script,outputDescription:'Native coverage allowance recipient'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}},origin)
  const tx=Transaction.fromAtomicBEEF(value.tx);assert.equal(tx.id('hex'),value.txid)
  const tracker={currentHeight:async()=>900100,isValidRootForHeight:async(root:string,height:number)=>services.headers.get(height)?.merkleRoot===root};assert.ok(await tx.verify(tracker))
  const inputSatoshis=tx.inputs.reduce((n,i)=>n+i.sourceTransaction!.outputs[i.sourceOutputIndex]!.satoshis!,0),outputs=tx.outputs.map(o=>o.satoshis!),fee=inputSatoshis-outputs.reduce((a,b)=>a+b,0)
  const tokens=await manager.listSpendingAuthorizations({originator:origin});assert.equal(tokens.length,1)
  const spent=await manager.querySpentSince(tokens[0]);payments.push({txid:value.txid,inputSatoshis,outputs,fee,debit:amount+fee,spent})
  assert.equal(fee,23);assert.equal(spent,payments.reduce((n,p)=>n+p.debit,0))
  if(index===0){manager=makeManager();events.push({kind:'manager-reconstructed',sameStore:true,nativeBrowserRestart:false})}
 }
 assert.deepEqual(payments.map(r=>r.debit),[34,36,30]);assert.equal(events.filter(r=>r.kind==='group').length,1);assert.equal(events.filter(r=>r.kind==='spending').length,0)
 await assert.rejects(()=>call('overflow',manager,'createAction',{description:'TPNIL coverage allowance overflow',outputs:[{satoshis:53,lockingScript:script,outputDescription:'Native coverage allowance recipient'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}},origin))
 assert.equal(events.filter(r=>r.kind==='spending').length,1)
 const stored=await services.nativeTransactions();for(const row of payments)assert.equal(stored.find((r:any)=>r.txid===row.txid)?.rawTxHex,Transaction.fromAtomicBEEF(trace.find(r=>r.result?.txid===row.txid).result.tx).toHex())
 const result={claim:'LAB_SELF_TEST_ONLY',actualNative:false,groupGrantViaPublicManifest:true,permissionStoreSeededPrivately:false,initialOwnedRoots:roots,initialManagedAmounts:[10000,10000,10000],ordinaryPaymentsNoCallerInputs:true,payments,totalDebit:payments.reduce((n,p)=>n+p.debit,0),cap:100,overflowRejected:true,reactivePaymentPromptsBeforeOverflow:0,managerReconstructionOnly:true}
 fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({out,...result}))
}finally{
 fs.writeFileSync(path.join(out,'trace.json'),JSON.stringify(trace,null,2)+'\n');fs.writeFileSync(path.join(out,'events.json'),JSON.stringify(events,null,2)+'\n')
 const closure=services.observeSubmissionClosure();await wallet?.destroy();await funder?.destroy();fs.writeFileSync(path.join(out,'final-storage.json'),JSON.stringify(await services.nativeTransactions(),null,2)+'\n');await services.close();fs.writeFileSync(path.join(out,'final-submissions.json'),JSON.stringify(closure.readFinalProviders(),null,2)+'\n');await new Promise<void>((resolve,reject)=>server.close(e=>e?reject(e):resolve()))
 const after=capture();fs.writeFileSync(path.join(out,'source-after.json'),JSON.stringify(after,null,2)+'\n');assert.deepEqual(after,before)
}
