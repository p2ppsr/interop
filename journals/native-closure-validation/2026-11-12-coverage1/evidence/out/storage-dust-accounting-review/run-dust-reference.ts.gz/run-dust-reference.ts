import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { P2PKH, PublicKey, Transaction } from '@bsv/sdk'
import { ControlledWalletServices } from './isolated-reference/synthesis/src/wallet-lab/services.js'
import { createFixtureWallet } from './isolated-reference/synthesis/src/storage-sync/fixture-wallet.js'
const root=path.resolve(import.meta.dirname,'../..'), out=path.join(import.meta.dirname,`attempt-${Date.now()}`)
fs.mkdirSync(out)
const files=[...Object.keys(JSON.parse(fs.readFileSync(path.join(import.meta.dirname,'isolated-reference/source-inventory.json'),'utf8'))).map(name=>'out/storage-dust-accounting-review/isolated-reference/'+name),'out/itcve-go-storage-dust-accounting.json','out/storage-dust-accounting-review/run-dust-reference.ts','synthesis/package-lock.json']
const capture=()=>Object.fromEntries(files.map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')]))
const before=capture();fs.writeFileSync(path.join(out,'source-before.json'),JSON.stringify(before,null,2)+'\n')
const services=new ControlledWalletServices({webroot:out,components:{storage:'go'},go:{binary:path.join(root,'out/itcve-go-storage-dust-accounting'),storageNativeContractsPatch:true,terminalRejectionReceipts:true}})
let wallet:any,funder:any
const trace:any[]=[]
const call=async(actor:string,target:any,method:string,args:any)=>{const row:any={actor,method,args};trace.push(row);try{row.result=await target[method](args);return row.result}catch(e:any){row.error={name:e.name,message:e.message,code:e.code};throw e}}
try {
 await services.start();await services.fundRemoteWalletFromTeranode('77'.repeat(32),JSON.parse(fs.readFileSync(path.join(root,'fixtures/teranode/wab-funding-v1.json'),'utf8')))
 funder=await createFixtureWallet(services,'77'.repeat(32));wallet=await createFixtureWallet(services,'78'.repeat(32))
 const identity=(await call('wallet',wallet,'getPublicKey',{identityKey:true})).publicKey,senderIdentityKey=(await call('funder',funder,'getPublicKey',{identityKey:true})).publicKey
 const derivationPrefix=Buffer.from('dust accounting initial funding').toString('base64'),derivationSuffix=Buffer.from('fifty sats').toString('base64')
 const key=await call('funder',funder,'getPublicKey',{protocolID:[2,'3241645161d8'],keyID:`${derivationPrefix} ${derivationSuffix}`,counterparty:identity})
 const seed=await call('funder',funder,'createAction',{description:'Dust accounting controlled funding',outputs:[{satoshis:50,lockingScript:new P2PKH().lock(PublicKey.fromString(key.publicKey).toAddress()).toHex(),outputDescription:'Fifty satoshi source'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}})
 await call('wallet',wallet,'internalizeAction',{tx:seed.tx,outputs:[{outputIndex:0,protocol:'wallet payment',paymentRemittance:{derivationPrefix,derivationSuffix,senderIdentityKey}}],description:'Dust accounting fifty sats'})
 const paid=await call('wallet',wallet,'createAction',{description:'Dust accounting recipient thirteen',labels:['dust accounting signed'],outputs:[{satoshis:13,lockingScript:'51',outputDescription:'Controlled thirteen sats'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}})
 const tx=Transaction.fromAtomicBEEF(paid.tx);assert.equal(tx.id('hex'),paid.txid);assert.equal(tx.inputs.length,1);assert.equal(tx.outputs.length,1);assert.equal(tx.outputs[0].satoshis,13);assert.equal(tx.inputs[0].sourceTransaction!.outputs[tx.inputs[0].sourceOutputIndex].satoshis,50)
 assert.equal(await tx.verify({isValidRootForHeight:async(root:string,height:number)=>services.headers.get(height)?.merkleRoot===root,currentHeight:async()=>900100}),true)
 const listed=await call('wallet',wallet,'listActions',{labels:['dust accounting signed'],includeOutputs:true,includeInputs:true,limit:10});assert.equal(listed.actions.length,1);assert.equal(listed.actions[0].txid,paid.txid);assert.equal(listed.actions[0].satoshis,-50)
 const go=(services as any).goServices,response=await fetch(`${go.origin}/control/v2/native-output-snapshot?identityKey=${identity}`,{headers:{authorization:`Bearer ${go.token}`}});assert.equal(response.status,200);const snapshot=await response.json();fs.writeFileSync(path.join(out,'output-snapshot.json'),JSON.stringify(snapshot,null,2)+'\n')
 const storage=await services.nativeTransactions();assert.equal(storage.find(row=>row.txid===paid.txid)?.rawTxHex,tx.toHex())
 fs.writeFileSync(path.join(out,'storage-transactions.json'),JSON.stringify(storage,null,2)+'\n')
 fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify({claim:'LAB_SELF_TEST_ONLY',actualNative:false,calls:trace.length,inputSatoshis:50,recipientSatoshis:13,changeSatoshis:0,actualFee:37,publicActionSatoshis:listed.actions[0].satoshis,transactionProof:true,storageBytesMatch:true,txid:paid.txid},null,2)+'\n')
 console.log(JSON.stringify({out,inputSatoshis:50,recipientSatoshis:13,actualFee:37,publicActionSatoshis:-50,proof:true}))
} finally {
 fs.writeFileSync(path.join(out,'trace.json'),JSON.stringify(trace,null,2)+'\n')
 await wallet?.destroy();await funder?.destroy();await services.close();const after=capture();fs.writeFileSync(path.join(out,'source-after.json'),JSON.stringify(after,null,2)+'\n');assert.deepEqual(after,before)
}
