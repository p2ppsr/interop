import fs from 'node:fs'
import path from 'node:path'
import { Transaction } from '../../synthesis/node_modules/@bsv/sdk/dist/esm/mod.js'
import { verifyCertificateCoverageParentBindings } from '../../synthesis/src/wallet-lab/native/coverage-certificates-verify.js'
const directory = process.argv[2]!, report=JSON.parse(fs.readFileSync(path.join(directory,'report.json'),'utf8')), ledger=JSON.parse(fs.readFileSync(path.join(directory,'parent-ledgers.json'),'utf8'))
const fixture=JSON.parse(fs.readFileSync('fixtures/teranode/wab-funding-v1.json','utf8'))
const graph=new Map<string,Transaction>(); const add=(tx:Transaction)=>{if(graph.has(tx.id('hex')))return;graph.set(tx.id('hex'),tx);for(const i of tx.inputs)if(i.sourceTransaction)add(i.sourceTransaction)}
for(const row of report.trace)if(['createAction','signAction'].includes(row.method)&&row.result?.tx)add(Transaction.fromAtomicBEEF(row.result.tx))
const result=await verifyCertificateCoverageParentBindings(report,{...ledger,finalSubmissions:ledger.globalSubmissions,browserContexts:[],storageTransactions:new Map(ledger.storageTransactions.map((r:any)=>[r.txid,Transaction.fromHex(r.rawTxHex)])),resolvedTransactions:graph,trustedMinedRoot:{txid:fixture.txid,rawHex:fixture.rawHex}})
console.log(JSON.stringify({claim:'LAB_SELF_TEST_ONLY',native:false,storageBinding:ledger.storageBinding,...result}))
