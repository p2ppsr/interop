import fs from 'node:fs'
import { deriveCertificateCoverageOutcomes } from '../../synthesis/src/wallet-lab/native/coverage-certificates-verify.js'
console.log(JSON.stringify(await deriveCertificateCoverageOutcomes(JSON.parse(fs.readFileSync(process.argv[2]!, 'utf8')))))
