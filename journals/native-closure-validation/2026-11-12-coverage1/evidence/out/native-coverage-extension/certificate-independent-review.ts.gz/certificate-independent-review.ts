import fs from 'node:fs'
import {createHash} from 'node:crypto'
import {deriveCertificateCoverageOutcomes} from '../../synthesis/src/wallet-lab/native/coverage-certificates-verify.js'
const file='out/certificate-coverage-reference/attempt-5/report.json',source='synthesis/src/wallet-lab/native/coverage-certificates-verify.ts'
const report=JSON.parse(fs.readFileSync(file,'utf8')),original=await deriveCertificateCoverageOutcomes(report)
const variants=[]
for(const kind of ['trailing-atomic-beef','restored-output-count-contradiction']){
 const r=structuredClone(report)
 if(kind==='trailing-atomic-beef')r.trace.find((x:any)=>x.id==='publication').result.tx.push(0)
 else r.settings.restoredOutputs.outputs.push({outpoint:`${'ab'.repeat(32)}.0`,satoshis:1,lockingScript:'51'})
 const outcomes=await deriveCertificateCoverageOutcomes(r)
 variants.push({kind,unchanged:JSON.stringify(outcomes)===JSON.stringify(original),target:outcomes.find((x:any)=>x.id===`coverage-certificates.${kind==='trailing-atomic-beef'?'fixture-authentication':'cleanup'}`)})
}
const sha=(p:string)=>createHash('sha256').update(fs.readFileSync(p)).digest('hex')
const result={claim:'ADVERSARIAL_ENGINEERING_REVIEW_NOT_NATIVE',source:{path:source,sha256:sha(source)},fixture:{path:file,sha256:sha(file)},variants}
fs.writeFileSync('out/native-coverage-extension/certificate-independent-review.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
