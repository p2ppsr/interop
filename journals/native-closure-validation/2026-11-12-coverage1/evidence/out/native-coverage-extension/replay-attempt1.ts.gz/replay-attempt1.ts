import fs from 'node:fs'
import {deriveCoverageExtensionOutcomes,verifyNativeCoverageExtension} from '../../synthesis/src/wallet-lab/native/coverage-extension-verifier.js'
const original=JSON.parse(fs.readFileSync('out/native-coverage-extension/reference-attempt1/conformance/coverage-extension.json','utf8')),r=structuredClone(original)
r.assertions=await deriveCoverageExtensionOutcomes(r);r.result=r.assertions.some((x:any)=>x.result==='FAIL')?'FAIL':r.assertions.some((x:any)=>x.result==='BLOCKED')?'BLOCKED':'PASS'
const verified=await verifyNativeCoverageExtension(r)
fs.writeFileSync('out/native-coverage-extension/replay-attempt1.json',JSON.stringify({claim:'ENGINEERING_VERIFIER_CORRECTION_NOT_NEW_NATIVE',counts:verified.counts,delta:r.assertions.filter((x:any,i:number)=>x.result!==original.assertions[i].result).map((x:any)=>({id:x.id,prior:original.assertions.find((a:any)=>a.id===x.id).result,next:x.result})),transactions:verified.transactions.map(x=>({callId:x.callId,txid:x.txid})),assertions:r.assertions},null,2)+'\n')
console.log(JSON.stringify(verified.counts))
