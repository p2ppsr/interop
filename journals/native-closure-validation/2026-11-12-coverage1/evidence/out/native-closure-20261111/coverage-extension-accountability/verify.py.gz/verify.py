from pathlib import Path
import json,hashlib,collections,gzip
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();file=Path('programs/ISI-4/proposals/native-coverage-accountability-20261112-extension-delta.json');j=json.loads(file.read_text())
assert j['completeBRC100Conformance']is False and j['nativeQualification']is None and j['historicalInputsMutable']is False
for p,digest in j['inputs'].items():assert sha(Path(p))==digest,p
assert len(j['rows'])==306 and len({r['id']for r in j['rows']})==306
assert collections.Counter(r['status']for r in j['rows'])==j['counts'];assert all(r['nativeVerdict']is None for r in j['rows'])
base=json.loads(Path('programs/ISI-4/proposals/native-coverage-accountability-20261111.json').read_text());index={r['caseId']+'/'+r['variantId']:r for r in base['variantRows']}
for r in j['rows']:assert r['baselineStatus']==index[r['id']]['status']and r['methods']==index[r['id']]['methods']
assert sum(m['assertionCount']for m in j['newModules'].values())==109
for m in j['newModules'].values():
 assert sha(Path(m['path']))==m['sha256'];p=json.loads(Path(m['path']).read_text());ids=p.get('assertionIds',p.get('assertions',p.get('variantIds')))
 if m['oracle']=='tpnil-native-coverage-certificates-oracle@1.0.0':ids=['coverage-certificates.'+x for x in ids]
 assert ids==m['assertionIds']and len(ids)==len(set(ids))==m['assertionCount']
for r in j['rows']:
 b=r['predicateBindings']
 if b:
  assert sha(Path(b['policy']))==b['policySha256']
  if b['module']!='existing-identity-trust':assert set(b['predicateIds'])<=set(j['newModules'][b['module']]['assertionIds'])
assert j['baselineGate']['result']=='BLOCKED' and j['retainedFailure']['result']=='FAIL'
proposal=Path('programs/ISI-4/proposals/brc100-list-actions-signed-value-clarification-20261112.json');p=json.loads(proposal.read_text());assert p['status']=='DRAFT_NOT_SENT'and p['oracleChanged']is False and p['runtimeChanged']is False;assert sha(Path(p['proposal']['path']))==p['proposal']['sha256']
for name,digest in p['receipts'].items():assert sha(Path(name))==digest
receipt={'verified':True,'claim':'PROSPECTIVE_MAPPING_AND_UNSENT_STANDARDS_DRAFT_ONLY','planningRows':306,'newAssertionSlots':109,'newlyMappedRows':65,'implementedNewRowsPendingNative':64,'mappedInterpretationBlocked':1,'existingScopedRow':1,'unchangedRows':240,'nativeVerdicts':None,'accountabilitySha256':sha(file),'standardsDraftSha256':sha(proposal)}
Path('out/native-closure-20261111/coverage-extension-accountability/verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
