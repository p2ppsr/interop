from pathlib import Path
import json,hashlib,collections,gzip
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
basepath=Path('programs/ISI-4/proposals/native-coverage-accountability-20261111.json'); originalpath=Path('programs/ISI-4/proposals/native-coverage-closure-20261111.json'); reviewpath=Path('journals/native-closure-validation/2026-11-11-observer3/reviews/remaining-coverage/review.json.gz')
base=json.loads(basepath.read_text()); review=json.loads(gzip.decompress(reviewpath.read_bytes())); policies={};mapping={}
for name in ['extension-2.0.0','permissions-1.0.0','certificates-1.0.0','transactions-2.0.0']:
 p=Path('programs/ISI-4/profiles/native-coverage-'+name+'/policy.json');j=json.loads(p.read_text());ids=j.get('assertionIds',j.get('assertions',j.get('variantIds')))
 if name.startswith('certificates'):ids=['coverage-certificates.'+x for x in ids]
 policies[name]={'path':str(p),'sha256':sha(p),'oracle':j['oracle'],'assertionIds':ids,'assertionCount':len(ids),'nativeVerdict':None}
 if name.startswith('extension'): pairs=[(r['row'],r['predicates'])for r in j['variantRows']]
 elif name.startswith('permissions'):pairs=[(r,[a])for r,a in zip(j['planningRows'],ids)]
 elif name.startswith('transactions'):pairs=[(r,[r])for r in j['variantIds']]
 else:
  pairs=[('certificate.'+r,['coverage-certificates.'+a])for r,a in [('issuance/wrong-auth-identity','wrong-auth-identity'),('inventory/restart','inventory-restart'),('revocation/relinquish-revoked','relinquish-revoked'),('discovery/attribute-no-match','attribute-no-match'),('discovery/multiple-certifiers','multiple-certifiers'),('discovery/bad-signature','bad-signature'),('discovery/bad-keyring','bad-keyring'),('discovery/default-seekPermission-false','default-seekPermission-false'),('discovery/explicit-seekPermission-true','explicit-seekPermission-true')]]
 for r,pp in pairs:
  assert r not in mapping;assert set(pp)<=set(ids);mapping[r]={'module':name,'oracle':j['oracle'],'policy':str(p),'policySha256':sha(p),'predicateIds':pp,'nativeVerdict':None}
assert len(mapping)==65
trust=Path('infra/native/integrated/identity-trust-oracle-2.0.0.json');mapping['certificate.discovery/untrusted-excluded']={'module':'existing-identity-trust','oracle':'tpnil-native-identity-trust-oracle@2.0.0','policy':str(trust),'policySha256':sha(trust),'predicateIds':['identity-trust.initial-exclusion'],'nativeVerdict':None}
assert set(mapping)=={r['id']for r in review['variants']}; assert sum(p['assertionCount']for p in policies.values())==109
rows=[]
for r in base['variantRows']:
 id=r['caseId']+'/'+r['variantId'];entry={'id':id,'baselineStatus':r['status'],'status':r['status'],'nativeVerdict':None,'scope':r['scope'],'remainingWork':r['remainingWork'],'methods':r['methods'],'predicateBindings':mapping.get(id),'baselinePredicateBindings':r['predicateBindings']}
 if id in mapping:
  if id=='transaction.internalization/conflicting-remittance':entry.update(status='INTERPRETATION_REQUIRED',remainingWork='The new transaction module deliberately emits BLOCKED. Pinned remittance selection does not prescribe inactive-field exclusivity; no native execution can resolve the normative interpretation itself.')
  elif id=='certificate.discovery/untrusted-excluded':entry.update(status='EXISTING_SCOPED_IMPLEMENTATION_PENDING_CURRENT_NATIVE',remainingWork='Existing exact issuer/subject/serial trust exclusion predicate is reused; require the new admitted native source and parent publication/trust bindings. This contributes no new predicate slot.')
  else:entry.update(status='NEW_IMPLEMENTATION_PENDING_NATIVE',remainingWork='Run the separately admitted native4.3 source/artifact profile with complete independent parent joins and final shutdown evidence. Local TS/library/Go references are not native verdicts; every linked predicate must pass within the declared scope.')
  if id=='basket.unicode-and-namespace/uppercase':entry['scopeCaveat']='Explicitly versioned normalization-consistency compatibility rule across create/internalize/list/relinquish; not a claim that the pinned prose universally requires raw uppercase rejection.'
  if id.startswith('privileged.authorization/'):entry['scopeCaveat']='All nine privileged-capable raw requests must reject the reason error before missing secondary-key capability; this does not qualify successful privileged authorization or a distinct secondary keyring.'
 rows.append(entry)
assert len(rows)==306 and len({r['id']for r in rows})==306
unmapped=[r for r in rows if r['predicateBindings'] is None];assert len(unmapped)==240
j={'schema':'tpnil-native-coverage-extension-accountability@1.0.0','claim':'PROSPECTIVE_SOURCE_MAPPING_ONLY','completeBRC100Conformance':False,'nativeQualification':None,'historicalInputsMutable':False,'profile':'ITCVE-1@4.3.0','program':'ISI-4@5.3.0','candidateSource':'4a954ac6bb0cb4403fb8ed548efd0cd8d1ba11b1','inputs':{str(p):sha(p)for p in [basepath,originalpath,reviewpath,trust,Path('programs/ISI-4/profiles/native-conformance-5.0.0/permission-coverage-5.0.0.json')]},'denominators':{'immutablePlanningRows':306,'immutableCaseGroups':36,'reviewedFeasibleRows':66,'newModuleAssertionSlots':109,'newlyMappedPlanningRows':65,'newlyImplementedRowsPendingNative':64,'mappedButStillInterpretationBlocked':1,'existingScopedPredicateRows':1,'unchangedPlanningRows':240,'prospectiveNativeObservationsPerRepetition':535,'predecessorNativeObservationsPerRepetition':426,'note':'Planning rows, predicate slots, calls, and repeated native results are distinct units. New slots include fixture/cleanup predicates and one intentionally blocked placeholder; no count is a passed-coverage percentage.'},'newModules':policies,'counts':dict(sorted(collections.Counter(r['status']for r in rows).items())),'baselineGate':{'id':'coverage.remaining-obligations','result':'BLOCKED','unchanged':True,'reason':'Neither65 mapped rows nor535 per-repetition predicate slots prove all306 variant requirements. Unmapped partial branches, supported capability gaps and interpretations remain open.'},'retainedFailure':{'id':'output.listActions','result':'FAIL','reason':'Pinned positive-only SatoshiValue conflicts with observed signed-net action history; no absolute-value projection, clamp, filtering or oracle change is admitted.'},'openRequirements':{'nativeCapabilities':{'rows':69,'groups':dict(collections.Counter(r['id'].split('/')[0]for r in rows if r['status']=='BLOCKED_NATIVE_CAPABILITY')),'note':'Requires a supported admitted native secondary keyring, finite-expiry UI and binary-wire ingress. Library/codecs or private state mutation cannot substitute.'},'publicObservability':{'rows':1,'id':'permissions.finite-expiry/expiry-zero','note':'Indefinite grants exist; their literal expiry0 representation is not publicly observed.'},'calendar':{'rows':1,'id':'permissions.allowance-boundaries/calendar-rollover','note':'Real bounded month transition or separately supported time control required; current wall clock is not mutated.'},'interpretations':{'rows':15,'ids':[r['id']for r in rows if r['status']=='INTERPRETATION_REQUIRED']},'unchangedPartialRows':124,'unchangedPriorImplementedAwaitingCurrentNative':31,'exactCapFixture':'Prospective permission5 replaces the empirical114 fixture with fixed100 before payments and an independently parent-bound fresh managed funding prelude: exactlythree10000-satoshi native default outputs before any customer transactions. Actual fees are still derived from signed bytes and must total the fixed cap exactly; no post-result adjustment. Policies1–4 and their original samples remain unchanged.'},'rows':rows,'economics':{'newNativeRunsFromThisMapping':0,'actualMonetaryCost':None,'reservationsAreNotActualCharges':True,'nativeDeviceSubstitutionAllowed':False}}
out=Path('programs/ISI-4/proposals/native-coverage-accountability-20261112-extension-delta.json');out.write_text(json.dumps(j,indent=2)+'\n');print(out,sha(out));print(j['counts'])
md=f'''# Prospective coverage delta for ITCVE-1 4.3

This append-only mapping preserves the original306 planning rows and36 case groups. The proposed535 observations per repetition combine426 predecessor predicate slots and109 new slots. They are not535 passed requirements.

| New module | Predicate slots | Newly mapped planning rows |
| --- | ---: | ---: |
| General extension oracle2 |61|19|
| Permission extension oracle1 |15|15|
| Certificate extension oracle1 |11|9|
| Transaction extension oracle2 |22|22|
| Total |109|65|

The66th reviewed row, `certificate.discovery/untrusted-excluded`, reuses `identity-trust.initial-exclusion` and contributes no new predicate. Of the65 new mappings,64 have prospective behavior predicates; `transaction.internalization/conflicting-remittance` deliberately remains BLOCKED pending interpretation. Fixture/cleanup slots and the blocked placeholder are included in109. Every native verdict in the JSON is null.

The remaining240 planning rows retain their exact prior classification:69 lack admitted native capabilities, one lacks public representation evidence,14 await interpretation, one needs a real calendar boundary,124 have only partial implementations, and31 have earlier implementations whose full current-profile native proof remains pending. The new blocked remittance row raises the explicit interpretation total to15. Neither a native method call nor a passing local reference fills its untested variants.

The69 native capability rows require a supported distinct secondary keyring and lifecycle, finite-expiry controls, or native binary-wire ingress. The expiry-zero row concerns observable representation, not absence of indefinite grants. Calendar rollover requires real supported time behavior. Tests of library codecs, injected clocks, private wallet state, or browser substitutes do not close these gaps.

Prospective permission5 uses a fixed100-satoshi cap and independently bound fresh managed funding before any customer transactions: exactlythree10000-satoshi native default outputs. Both permission modules execute first. Actual signed fees and final UI totals must still reach exactly100; the cap is never adjusted after results. The earlier empirical114 policy4 and all earlier samples remain unchanged. Source and local proofs support this fixture design; an admitted native execution is still required.

`coverage.remaining-obligations` remains BLOCKED. `output.listActions` remains FAIL under the pinned positive-only type while actual history is signed net value; the separate standards draft changes neither implementation nor oracle. All earlier failed native and local samples remain retained. This mapping creates no native evidence, cost saving, or full-conformance claim.

The companion JSON binds each policy digest, all109 exact predicate IDs, and every306 row's retained or new status. It records scope limits, including raw privileged-reason validation and uppercase basket normalization consistency.
'''
Path('programs/ISI-4/proposals/native-coverage-accountability-20261112-extension-delta.md').write_text(md)
