"""Prospective files only; invoke after the parent confirms all runtime sources stable."""
from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[2]
assert (root/'package.json').is_file()
def digest(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
def read(p):return json.loads((root/p).read_text())
def write(p,x):(root/p).write_text(json.dumps(x,indent=2)+'\n')
source='69b1b52f0c3d46cbfac91c78b38eb2e4dffbac99'
oldpaths=subprocess.check_output(['git','ls-tree','-r','--name-only',source,'infra/native/conformance','itcves/ITCVE-1/4.2.0','programs/ISI-4/5.2.0'],cwd=root,text=True).splitlines()
for p in oldpaths:
 if p.endswith('.json'):
  assert (root/p).read_bytes()==subprocess.check_output(['git','show',f'{source}:{p}'],cwd=root),f'Executed profile changed: {p}'
planpath='infra/native/conformance/plan-pr368-coverage-1.json';rustpath='infra/native/conformance/rust-graph-pr368-coverage-1.json'
plan=read(planpath)
assert plan['itcve']=='ITCVE-1@4.3.0' and plan['expectedObservations']==535
assert plan['walletCandidate']['sourceCommit']=='4a954ac6bb0cb4403fb8ed548efd0cd8d1ba11b1'
intake=read(plan['walletCandidate']['manifest'])
assert digest(plan['walletCandidate']['manifest'])==plan['walletCandidate']['manifestSha256']
assert intake['wallet']==plan['wallet'] and digest(intake['archive'])==plan['wallet']['sha256']
assert plan['compatibilityPatch']=='infra/adapters/storage-sqlite-retry/patch.lock.json'
lock=read(plan['compatibilityPatch']);assert lock['parent']=='infra/adapters/storage-input-ancestry/patch.lock.json'
assert digest(lock['parent'])==lock['parentSha256']
assert digest(str(Path(plan['compatibilityPatch']).parent/lock['patch']))==lock['patchSha256']
build=read('out/itcve-go-storage-sqlite-retry.json');assert build['schema']=='tpnil-storage-sqlite-retry-go-build@1.0.0'
assert build['patchLockSha256']==digest(plan['compatibilityPatch'])
assert build['binarySha256']==digest('out/itcve-go-storage-sqlite-retry')
for group in ['inputs','patchInputs']:
 for p,h in build[group].items():assert digest(p)==h,f'Build input changed: {p}'
inputs=set(plan['conformanceInputs'])
inputs.update([plan['compatibilityPatch'],'infra/adapters/storage-sqlite-retry/go-wallet-toolbox-v0.191.4.patch','scripts/prepare-storage-sqlite-retry-go.mjs'])
for cmd in [['git','diff','--name-only'],['git','ls-files','--others','--exclude-standard']]:
 for p in subprocess.check_output(cmd,cwd=root,text=True).splitlines():
  if (p.startswith('synthesis/src/') or p.startswith('integrations/services/src/')) and p.endswith('.ts'):inputs.add(p)
  if p.startswith('synthesis/go/cmd/') and p.endswith('.go'):inputs.add(p)
for name,module in plan['coverageModules'].items():
 policy=read(module['manifest']);assert policy['oracle']==module['oracle']
 assert module['assertions']==len(module['assertionIds'])
 inputs.add(module['manifest'])
assert sum(m['assertions'] for m in plan['coverageModules'].values())==109
for field in ['compatibilityPatch','boundaryProfile','identityTrustProfile','headerFixturePolicy','identityTrustOraclePolicy']:
 plan[field+'Sha256']=digest(plan[field])
plan['conformanceInputs']={p:digest(p) for p in sorted(inputs)}
plan['admissionState']='FROZEN';plan['pendingInputs']=[]
assert 'PENDING_' not in json.dumps(plan)
write(planpath,plan)
rust=read(rustpath);rust['nativePlan']['sha256']=digest(planpath)
for p in rust['sources']:rust['sources'][p]=digest(p)
assert digest(rust['predecessor']['manifest'])==rust['predecessor']['sha256']
write(rustpath,rust)
reevalpath='infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-5.json';reeval=read(reevalpath)
assert reeval['sourceBindingRevision']==5 and digest(reeval['predecessor']['path'])==reeval['predecessor']['sha256']
for p in reeval['evaluatorSources']:reeval['evaluatorSources'][p]=digest(p)
write(reevalpath,reeval)
print(json.dumps({'claim':'SOURCE_FREEZE_ONLY_NOT_NATIVE_QUALIFICATION','inputs':len(inputs),'plan':{'path':planpath,'sha256':digest(planpath)},'rust':{'path':rustpath,'sha256':digest(rustpath)},'reevaluation':{'path':reevalpath,'sha256':digest(reevalpath)},'compatibilityPatchSha256':plan['compatibilityPatchSha256'],'candidate':plan['wallet'],'originalProfileSource':source,'originalJsonFilesUnchanged':len([p for p in oldpaths if p.endswith('.json')])},indent=2))
