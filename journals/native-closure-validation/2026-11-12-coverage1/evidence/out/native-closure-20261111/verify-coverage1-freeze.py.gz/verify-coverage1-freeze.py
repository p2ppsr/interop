from pathlib import Path
import json,hashlib,subprocess,zipfile
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
yours=Path('/Users/tyeverett/tmp/network-ops/worktrees/ty-everett/yours-wallet/codex/ghsa-5vmp-dependency-upgrade')
def b(p):return (root/p).read_bytes()
def sha(v):return hashlib.sha256(v).hexdigest()
def h(p):return sha(b(p))
def read(p):return json.loads(b(p))
pp='infra/native/conformance/plan-pr368-coverage-1.json';rp='infra/native/conformance/rust-graph-pr368-coverage-1.json';ep='infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-5.json'
p=read(pp);r=read(rp);e=read(ep)
assert p['admissionState']=='FROZEN' and p['pendingInputs']==[] and 'PENDING_' not in json.dumps(p)
assert (p['itcve'],p['program'],p['expectedObservations'],p['browserContexts'])==('ITCVE-1@4.3.0','ISI-4@5.3.0',535,5)
assert p['permissionCoverageOracle']=='tpnil-native-permission-coverage-oracle@5.0.0' and p['permissionFixture']=='fresh-managed-funding-v1'
assert read(p['permissionCoverageOracleManifest'])['configuration']['allowanceSatoshis']==100
for name in ['synthesis/src/wallet-lab/native/permission-prelude.ts',p['permissionCoverageOracleManifest']]:assert name in p['conformanceInputs']
for name,digest in p['conformanceInputs'].items():assert h(name)==digest,name
assert [m['assertions'] for m in p['coverageModules'].values()]==[15,22,61,11]
for m in p['coverageModules'].values():assert read(m['manifest'])['oracle']==m['oracle'] and len(m['assertionIds'])==m['assertions']
assert r['nativePlan']=={'path':pp,'sha256':h(pp),'profile':p['itcve'],'program':p['program']}
assert r['sourceBindingRevision']==4 and r['variant']=='integrated-native-conformance-pr368-coverage-1'
for n,s in r['sources'].items():assert h(n)==s,n
assert h(r['predecessor']['manifest'])==r['predecessor']['sha256']
assert e['sourceBindingRevision']==5 and h(e['predecessor']['path'])==e['predecessor']['sha256']
assert e['expected']=={'repetitions':2,'nativeAssertions':280,'integratedAssertions':77,'rustAssertions':48}
for n,s in e['evaluatorSources'].items():assert h(n)==s,n
previous=read(e['predecessor']['path'])
for k in ['original','rust','expected']:assert e[k]==previous[k]
for k in ['compatibilityPatch','boundaryProfile','identityTrustProfile','headerFixturePolicy','identityTrustOraclePolicy']:assert h(p[k])==p[k+'Sha256']
old='69b1b52f0c3d46cbfac91c78b38eb2e4dffbac99';oldfiles=subprocess.check_output(['git','ls-tree','-r','--name-only',old,'infra/native/conformance','itcves/ITCVE-1/4.2.0','programs/ISI-4/5.2.0'],cwd=root,text=True).splitlines();unchanged=[]
for n in oldfiles:
 if n.endswith('.json'):
  assert b(n)==subprocess.check_output(['git','show',f'{old}:{n}'],cwd=root),n;unchanged.append(n)
# Independently join the complete parent patch chain to current final source postimages.
g=read('out/itcve-go-storage-sqlite-retry.json');assert g['schema']=='tpnil-storage-sqlite-retry-go-build@1.0.0';assert g['patchLockSha256']==p['compatibilityPatchSha256'];assert g['binarySha256']==h('out/itcve-go-storage-sqlite-retry')
for group in ['inputs','patchInputs']:
 for n,s in g[group].items():assert h(n)==s,n
postimages={};layers=[]
def layer(name):
 lock=read(name)
 assert lock['module']==g['upstream']['module'] and lock['version']==g['upstream']['version'] and lock['sum']==g['upstream']['sum']
 if lock.get('parent'):assert h(lock['parent'])==lock['parentSha256'];layer(lock['parent'])
 assert h(str(Path(name).parent/lock['patch']))==lock['patchSha256']
 layers.append(name)
 for n,x in lock['files'].items():
  if n in postimages:assert postimages[n]==x['before'],n
  postimages[n]=x['after']
layer(p['compatibilityPatch'])
for n,s in postimages.items():assert sha((Path(g['replacementModule'])/n).read_bytes())==s,n
# Exact immutable candidate files, all ZIP members and installed patched postimages.
mp=p['walletCandidate']['manifest'];m=read(mp);base=root/Path(mp).parent
assert h(mp)==p['walletCandidate']['manifestSha256'] and m['wallet']==p['wallet'];assert m['sourceCommit']==p['walletCandidate']['sourceCommit']=='4a954ac6bb0cb4403fb8ed548efd0cd8d1ba11b1'
assert m['claim']=='ENGINEERING_OBSERVATION_ONLY' and m['officialRelease'] is False
actual={str(f.relative_to(base)):sha(f.read_bytes()) for f in base.rglob('*') if f.is_file() and f!=base/'provenance.json'};assert actual==m['files'] and len(actual)==345
assert h(m['archive'])==m['wallet']['sha256'] and len(b(m['archive']))==m['wallet']['size']
with zipfile.ZipFile(base/f"ci/artifact-{m['artifactId']}.zip") as z:assert z.read('pw-v5.1.1.zip')==b(m['archive'])
installed=read(str(Path(mp).parent/'source/installed-patched-files.json'))['files'];frozen=read(str(Path(mp).parent/'source/frozen-installed-byte-equality.json'))
assert installed==frozen['installedFiles'] and len(installed)==8
assert frozen['bunLockSha256']==sha((base/'source/bun.lock').read_bytes())
assert frozen['patchSha256']==sha((base/'source/patches/@bopen-io%2Fwallet-toolbox-client@2.14.8.patch').read_bytes())
for row in installed:
 content=(yours/'node_modules/@bsv/wallet-toolbox-client'/row['path']).read_bytes();assert sha(content)==row['sha256'] and len(content)==row['bytes'],row['path']
review=json.loads((base/'ci-review.json').read_bytes());members=json.loads((base/'zip-members.json').read_bytes())
with zipfile.ZipFile(base/'pw-v5.1.1.zip') as z:
 assert z.testzip() is None and len(members)==45
 assert sorted(x.filename for x in z.infolist() if not x.is_dir())==sorted(x['name'] for x in members)
 for row in members:assert len(z.read(row['name']))==row['size'] and sha(z.read(row['name']))==row['sha256']
 for local,proofs in review['patchedDependencySourceProof'].items():
  content=(yours/local).read_bytes()
  for proof in proofs:
   sm=json.loads(z.read(proof['map']));i=sm['sources'].index(proof['source']);assert sm['sourcesContent'][i].encode()==content and sha(content)==proof['sha256']
for name in ['package.json','bun.lock','patches/@1sat%2Fwallet@0.0.121.patch','patches/@bopen-io%2Fwallet-toolbox-client@2.14.8.patch']:
 assert (base/'source'/name).read_bytes()==subprocess.check_output(['git','show',f"{m['sourceCommit']}:{name}"],cwd=yours),name
result={'schema':'tpnil-coverage1-freeze-independent-verification@1','claim':'SOURCE_FREEZE_ONLY_NOT_NATIVE_QUALIFICATION','verified':True,'sourceInputs':len(p['conformanceInputs']),'newPlanSha256':h(pp),'newRustManifestSha256':h(rp),'newReevaluationPlanSha256':h(ep),'oldExecutedSource':old,'oldJsonFilesUnchanged':len(unchanged),'permissionOracle':p['permissionCoverageOracle'],'permissionFixture':p['permissionFixture'],'candidate':{'source':m['sourceCommit'],'files':len(actual),'zipMembers':len(members),'patchedInstalledPostimages':len(installed),'bundledPatchedModules':len(review['patchedDependencySourceProof']),'sha256':m['wallet']['sha256']},'go':{'manifestSha256':h('out/itcve-go-storage-sqlite-retry.json'),'patchLayers':len(layers),'currentPatchedPostimages':len(postimages),'inputs':len(g['inputs']),'patchInputs':len(g['patchInputs']),'binarySha256':g['binarySha256']},'nativeSessions':0}
(out/'coverage1-freeze-independent.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
