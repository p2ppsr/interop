import fs from 'node:fs'
import {createRequire} from 'node:module'
import {createHash} from 'node:crypto'
const require=createRequire(import.meta.url)
const {StorageClient}=require('../../synthesis/node_modules/@bsv/wallet-toolbox')
const {Beef,ProtoWallet,PrivateKey}=require('../../synthesis/node_modules/@bsv/sdk')
const source=JSON.parse(fs.readFileSync('out/storage-dust-accounting-review/attempt-1794467632844/storage-client-trace.json','utf8'))
const actual=source.find((row:any)=>row.method==='createAction'&&row.args[1].description==='TPNIL transaction extension proof conflicting')
const client=new StorageClient(new ProtoWallet(PrivateKey.fromHex('78'.repeat(32))),'http://127.0.0.1:1')
let outgoing:any
client.rpcCall=async(method:any,params:any)=>{outgoing={method,params};return {}}
await client.createAction(...structuredClone(actual.args))
const inspect=async(bytes:number[])=>{const b=Beef.fromBinary(bytes);return {bytes:bytes.length,sha256:createHash('sha256').update(Buffer.from(bytes)).digest('hex'),transactions:b.txs.length,bumps:b.bumps.length,verifies:await b.verify({isValidRootForHeight:async()=>true,currentHeight:async()=>900100},true)}}
console.log(JSON.stringify({claim:'ENGINEERING_SOURCE_REPLAY_NO_HTTP',before:await inspect(actual.args[1].inputBEEF),after:await inspect(outgoing.params[1].inputBEEF),rpcMethod:outgoing.method},null,2))
