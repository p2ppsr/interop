import fs from 'node:fs'
import {Beef, Transaction} from '../../synthesis/node_modules/@bsv/sdk/dist/esm/mod.js'
import {createRequire} from 'node:module'
const require=createRequire(import.meta.url)
const {canonicalizeAtomicBeef}=require('../../synthesis/node_modules/@bsv/wallet-toolbox/out/src/utility/canonicalizeAtomicBeef.js')
const inputs=JSON.parse(fs.readFileSync(new URL('./contradictory-inputs.json',import.meta.url),'utf8'))
const rows=[]
for(const [id,bytes] of Object.entries(inputs)) {const b=Beef.fromBinary(bytes as number[]), c=canonicalizeAtomicBeef(bytes);rows.push({id,original:{bumps:b.bumps.length,transactions:b.txs.length,roots:b.bumps.map(m=>({height:m.blockHeight,root:m.computeRoot()})),verifies:await b.verify({isValidRootForHeight:async()=>true,currentHeight:async()=>900100},true)},canonical:{bumps:c.bumps.length,transactions:c.txs.length,roots:c.bumps.map(m=>({height:m.blockHeight,root:m.computeRoot()})),verifies:await c.verify({isValidRootForHeight:async()=>true,currentHeight:async()=>900100},true)}})}
console.log(JSON.stringify(rows,null,2))
