package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/bsv-blockchain/go-sdk/chainhash"
	"github.com/bsv-blockchain/go-sdk/transaction"
	"os"
)

type tracker struct{}

func (tracker) IsValidRootForHeight(_ context.Context, root *chainhash.Hash, height uint32) (bool, error) {
	fmt.Printf("tracker height%d root%s\n", height, root.String())
	return true, nil
}
func (tracker) CurrentHeight(context.Context) (uint32, error) { return 900100, nil }
func main() {
	raw, _ := os.ReadFile(os.Args[1])
	var values map[string][]byte
	if err := json.Unmarshal(raw, &values); err != nil {
		panic(err)
	}
	for name, data := range values {
		fmt.Println(name)
		if len(data) == 0 {
			continue
		}
		b, err := transaction.NewBeefFromBytes(data)
		if err != nil {
			fmt.Println("parse", err)
			continue
		}
		fmt.Printf("raw bumps%d txs%d\n", len(b.BUMPs), len(b.Transactions))
		for _, bump := range b.BUMPs {
			root, err := bump.ComputeRoot(nil)
			fmt.Println("bump", bump.BlockHeight, root, err)
		}
		valid, err := b.Verify(context.Background(), tracker{}, true)
		fmt.Println("parsed verify", valid, err)
		m := transaction.NewBeefV2()
		err = m.MergeBeefBytes(data)
		fmt.Println("merged", len(m.BUMPs), len(m.Transactions), err)
		valid, err = m.Verify(context.Background(), tracker{}, true)
		fmt.Println("merged verify", valid, err)
	}
}
