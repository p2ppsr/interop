from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
lockpath=root/'infra/adapters/storage-sqlite-retry/patch.lock.json';lock=load(lockpath);buildpath=root/'out/itcve-go-storage-sqlite-retry.json';build=load(buildpath)
assert sha(lockpath)=='dd00ac15acdc7e612802e299cbe7dbcf9f184422f08cf685b80fe4cc9163fc38'
assert sha(buildpath)=='900f09c770cbc73113a622443db287fb996fc343762e08fc90257b191e4986a2'
assert sha(root/'out/itcve-go-storage-sqlite-retry')==build['binarySha256']=='703abe5ec5d3268d4e042f63e40b6a1d7bb5c1389487ddfd98cbf7f0e4aa75f0'
assert build['patchLockSha256']==sha(lockpath)
for key in ['patchInputs','inputs']:
 for p,h in build[key].items():assert sha(root/p)==h,p
assert sha(root/lock['parent'])==lock['parentSha256']
assert sha(lockpath.parent/lock['patch'])==lock['patchSha256']
for p,h in lock['files'].items():
 assert sha(Path(build['replacementModule'])/p)==h['after'],p
 before=root/'out/storage-input-ancestry-go-source'/p
 assert not before.exists() if h['before'] is None else sha(before)==h['before']
for p,h in load(out/'baseline-source-binding.json').items():assert sha(out/'baseline-source'/p)==h,p
for p in ['pkg/internal/storage/dbretry/native_sqlite_retry_tpnil_test.go','pkg/internal/storage/database/native_snapshot_retry_tpnil_test.go']:
 assert (out/'baseline-source'/p).read_bytes()==(Path(build['replacementModule'])/p).read_bytes()
after=(out/'after-focused.log').read_text();before=(out/'before-final-tests.log').read_text();full=(out/'full-build.log').read_text()
for mode in ['recover','bounded','cancel','no-retry','committed-once']:assert f'--- PASS: TestNativeSnapshotRetryTPNIL/{mode}' in after
for mode in ['recover','bounded','cancel']:assert f'--- FAIL: TestNativeSnapshotRetryTPNIL/{mode}' in before
assert '--- FAIL: TestNativeSQLiteRetryClassificationTPNIL' in before
assert '--- PASS: TestNativeSQLiteRetryClassificationTPNIL' in after
assert not any(line.startswith('FAIL') for line in full.splitlines())
files=[lockpath,lockpath.parent/lock['patch'],root/'scripts/prepare-storage-sqlite-retry-go.mjs',buildpath,*[out/name for name in ['baseline-source-binding.json','before-final-tests.log','after-focused.log','full-build.log','before.log','full-build-attempt1.log','initial-git-header-lock.json','initial-git-header.patch','source-before.json']]]
receipt={'schema':'tpnil-independent-source-review@1','claim':'SOURCE_AND_LOCAL_ENGINEERING_EVIDENCE_REVIEW_ONLY','reviewed':True,'findings':[], 'verifiedBuildInputs':len(build['inputs']),'verifiedPatchInputs':len(build['patchInputs']),'unchangedBaselineFinalTests':2,'typedConflict':'SQLite ErrBusy + ErrBusySnapshot only; value, pointer and wrapped error supported','review':['Top-level repository transaction runners and provider UOW own GORM rollback before retry; nested repositories retain NoRetry.','Read-only review confirms exact classifier excludes generic busy, locked, constraints and matching error text.','Deterministic real SQLite WAL/5000ms schedule proves fresh snapshot retry, bounded original error, cancellation, no-retry and single commit.','Initial preparation failure, exact source-bound baseline failures and corrected passing execution remain separate.'], 'limits':['No fresh independent Go execution was run for this review; source hashes and retained before/after/build receipts were independently inspected.','Earlier transaction reference generic database-is-locked sample has UNKNOWN extended code; this review does not attribute it or claim all SQLite contention fixed.','No native or full BRC100 qualification.'], 'files':[{'path':str(p.relative_to(root)),'size':p.stat().st_size,'sha256':sha(p)} for p in files]}
(out/'independent-review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'verified':True,'receiptSha256':sha(out/'independent-review.json'),'buildInputs':len(build['inputs']),'patchInputs':len(build['patchInputs'])}))
