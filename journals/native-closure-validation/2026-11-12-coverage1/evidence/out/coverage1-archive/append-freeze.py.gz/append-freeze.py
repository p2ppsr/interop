from pathlib import Path
import json,hashlib,gzip,subprocess,datetime
root=Path(__file__).resolve().parents[2];dest=root/'journals/native-closure-validation/2026-11-12-coverage1'
sha=lambda b:hashlib.sha256(b).hexdigest()
freeze=json.loads((root/'out/native-closure-20261111/coverage1-freeze.json').read_text())
plan=json.loads((root/freeze['plan']['path']).read_text())
assert len(plan['conformanceInputs'])==157
assert sha((root/freeze['plan']['path']).read_bytes())==freeze['plan']['sha256']
changed=set(subprocess.check_output(['git','diff','--name-only','109705c'],cwd=root,text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
changed={p for p in changed if not p.startswith(('journals/','fixtures/artifacts/','out/')) and not any(x in p for x in ['/reference/','/reference-sqlite-retry/','/prior-source/']) and (root/p).is_file()}
names=changed|set(plan['conformanceInputs'])|{freeze[k]['path'] for k in ['plan','rust','reevaluation']}
for name,digest in plan['conformanceInputs'].items():assert sha((root/name).read_bytes())==digest,name
rows=[]
def retain(name,target):
 raw=(root/name).read_bytes();packed=gzip.compress(raw,compresslevel=9,mtime=0);p=dest/(target+'.gz');p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==packed,('Refusing source substitution',name)
 else:p.write_bytes(packed)
 rows.append({'path':str(p.relative_to(dest)),'source':name,'encoding':'gzip','bytes':len(packed),'sha256':sha(packed),'rawBytes':len(raw),'rawSha256':sha(raw)})
for name in sorted(names):retain(name,'source/'+name)
extra=['coverage1-freeze.json','coverage1-freeze-independent.json','freeze-coverage1.py','verify-coverage1-freeze.py','permission-prelude-guard-review.ts','permission-prelude-guard-review.json','coverage1-synthesis-tests-3.log','coverage1-core-tests-3.log','coverage1-frozen-core-tests-1.log','coverage1-typecheck-2.log','coverage1-catalog-2.log']
for n in extra:
 p='out/native-closure-20261111/'+n
 if (root/p).is_file():retain(p,'evidence/'+p)
retain('out/coverage1-archive/append-freeze.py','evidence/out/coverage1-archive/append-freeze.py')
receipt={'schema':'tpnil-native-coverage1-source-freeze-index@1.0.0','claim':'SOURCE_FREEZE_ONLY_NOT_NATIVE_QUALIFICATION','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nativeSessions':0,'completeBRC100Conformance':False,'comparisonBase':'109705c','sourceHeadAtSnapshot':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'plan':freeze['plan'],'runtimeInputs':plan['conformanceInputs'],'changedSourceInventory':sorted(changed),'results':{'corePassed':173,'coreFailed':0,'coreSkipped':0,'synthesisPassed':1079,'synthesisSkipped':23,'synthesisFiles':66,'focusedCorePassed':57,'finalPublishedSemanticReplay':'PENDING_ROOT_TERMINAL_REVIEW'},'files':rows}
(dest/'source-freeze-index.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'files':len(rows),'changedSources':len(changed),'runtimeInputs':len(plan['conformanceInputs']),'indexSha256':sha((dest/'source-freeze-index.json').read_bytes())}))
