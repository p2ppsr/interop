from pathlib import Path
import json,hashlib,gzip,subprocess,datetime
root=Path(__file__).resolve().parents[2]
dest=root/'journals/native-closure-validation/2026-11-12-coverage1'
dest.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
selected={}; references={}; missing=[]; mismatches=[]; resolutions=[]
historical=json.loads((root/'out/coverage1-archive/historical-source-resolution.json').read_text())
def select(p,expected=None,destination=None):
 p=Path(p);p=p if p.is_absolute() else root/p
 if not p.is_file():missing.append(str(p));return
 data=p.read_bytes()
 if expected and sha(data)!=expected:
  if expected in historical:
   prior=root/historical[expected];assert sha(prior.read_bytes())==expected
   resolutions.append({'originalPath':str(p),'expected':expected,'retainedSource':str(prior),'currentHash':sha(data)})
   select(prior,expected,'historical-source/'+expected+'/'+p.name);return
  mismatches.append({'path':str(p),'expected':expected,'actual':sha(data)});return
 try: relative=str(p.relative_to(root));target=destination or ('source/'+relative if not relative.startswith('out/') else 'evidence/'+relative)
 except ValueError:target=destination or 'reviews/yours/'+p.name
 if p.stat().st_size>100_000_000 or p.suffix=='.zip':
  references[str(p)]={'sha256':sha(data),'bytes':len(data),'reason':'Rebuildable executable or original ZIP is retained at its separately bound location; not duplicated.'};return
 target=target+'.gz'
 if target in selected:assert selected[target]['sha256']==sha(data),target
 selected[target]={'source':str(p),'sha256':sha(data),'bytes':len(data)}
def top(name):
 p=root/name
 if not p.exists():missing.append(str(p));return
 for f in sorted(p.iterdir()):
  if f.is_file():select(f)
def declared(review):
 review=Path(review);review=review if review.is_absolute() else root/review
 select(review);value=json.loads(review.read_text());files=value.get('files',{})
 rows=files.items() if isinstance(files,dict) else [(x['path'],x) for x in files]
 for name,row in rows:
  digest=row if isinstance(row,str) else row.get('sha256')
  p=Path(name)
  if not p.is_absolute():p=(root/name) if (root/name).is_file() else review.parent/name
  select(p,digest)
def link(p,reason):
 p=root/p;assert p.is_file(),p
 references[str(p.relative_to(root))]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'reason':reason}

go_layers=['batch-subjects','dust-accounting','merge-accounting','input-ancestry','sqlite-retry']
for layer in go_layers:
 folder='storage-'+layer
 top('infra/adapters/'+folder);select('scripts/prepare-'+folder+'-go.mjs')
 build=root/f'out/itcve-go-{folder}.json';select(build);manifest=json.loads(build.read_text())
 for p,digest in {**manifest['inputs'],**manifest['patchInputs']}.items():select(p,digest)
 lock=json.loads((root/'infra/adapters'/folder/'patch.lock.json').read_text())
 for p,digests in lock['files'].items():select(root/'out'/f'{folder}-go-source'/p,digests['after'],f'go-postimages/{folder}/{p}')
 for p,digest in manifest['generatedHost'].items():select(root/'out'/f'{folder}-host'/p,digest,f'generated-host/{folder}/{p}')
 top('out/'+folder+'-review');declared('out/'+folder+'-review/review.json')

for name in ['storage-sqlite-contention-review','storage-proof-merge-review','permission-fee-review','native-coverage-extension','native-review-4a954ac','native-review-ced590f']:
 top('out/'+name)
declared('out/storage-proof-merge-review/review.json')
declared('out/storage-sqlite-contention-review/review.json')
declared('out/permission-fee-review/review.json')
select('out/storage-sqlite-contention-review/source/pkg/internal/storage/database/native_snapshot_diagnostic_test.go')
for name in ['native-coverage-extension-v2-independent-review.json','native-coverage-extension-v2-independent-review.log']:
 select('out/'+name)

# The certificate reference is not yet published separately. Retain the exact
# original reports, including failures, plus the reviewed final source snapshot.
top('out/certificate-coverage-reference');declared('out/certificate-coverage-reference/final-review.json')
for p in (root/'out/certificate-coverage-reference').glob('attempt-*'):
 if p.is_dir():
  for f in p.iterdir():
   if f.is_file():select(f)

for name in ['transaction-coverage-reference','transaction-coverage-oracle2-reference','transaction-coverage-sqlite-retry-reference']:
 top('out/'+name)

ops=root/'out/native-closure-20261111'
for pattern in ['coverage1-*.log','permission5-*.json','permission5-*.log','permission-extension-*.json','permission-extension-*.log','coverage-*-review.json','coverage-*-tests*.log']:
 for p in ops.glob(pattern):select(p)
for p in (ops/'coverage-extension-accountability').iterdir():
 if p.is_file():select(p)
for p in (root/'programs/ISI-4/proposals').glob('*coverage*20261112*'):select(p)
select(ops/'write-attempt5-order.py')
for name in ['build-preflight.py','build-preflight-attempt1.log','selection-review-attempt1.json','historical-source-resolution.json','historical-input-ancestry-admission.test.ts']:
 select(root/'out/coverage1-archive'/name)

yours=Path('/Users/tyeverett/tmp/network-ops/worktrees/ty-everett/yours-wallet/codex/ghsa-5vmp-dependency-upgrade/.cache/native-final-contract')
for name in ['review.json','readable-runtime.diff','full-tests.log','typecheck.log','build.log','verify-build.log','format.log','predecessor-tests-2.log','proof-diagnosis.json','normalization-diagnosis.json','normalization-corrected.json','frozen-installed-byte-equality-restored-context.json','final-restored-context-focused-tests.log','diff-check-source.log','diff-check-patch-format.log','frozen-install-context-format.log','final-context-focused-tests.log']:
 select(yours/name,destination='reviews/yours/'+name)

for wallet in ['ced590f','4a954ac']:
 for name in ['provenance.json','ci-review.json']:
  link(f'fixtures/artifacts/yours-wallet-pr368-{wallet}/{name}','Candidate intake with original ZIPs and full files already retained separately; this archive does not duplicate it.')
for profile in ['native-coverage-extension-1.0.0','native-coverage-extension-2.0.0','native-coverage-transactions-1.0.0','native-coverage-transactions-2.0.0']:
 for name in ['reference/manifest.json','prior-source/manifest.json','reference-sqlite-retry/manifest.json']:
  p=f'programs/ISI-4/profiles/{profile}/{name}'
  if (root/p).is_file():link(p,'Exact module reference pack retained separately, including its original failures and source snapshots.')
for p in (root/'journals').rglob('*.json'):
 if '43165501159' in str(p) and p.name in ['manifest.json','validation.json','review-closeout.json']:
  link(str(p.relative_to(root)),'Original failed native attempt4 retained separately; no new native session in this archive.')

# All hash-bound files above must remain reproducible. Changed sources are not
# silently substituted into old receipts.
report={'missing':missing,'mismatches':mismatches,'selected':len(selected),'references':len(references)}
(root/'out/coverage1-archive/selection-review.json').write_text(json.dumps(report,indent=2)+'\n')
assert not missing and not mismatches,report
rows=[]
for name,item in sorted(selected.items()):
 raw=Path(item['source']).read_bytes();assert sha(raw)==item['sha256']
 packed=gzip.compress(raw,compresslevel=9,mtime=0);target=dest/name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==packed,'Refusing to overwrite archive evidence: '+name
 else:target.write_bytes(packed)
 rows.append({'path':name,'source':item['source'],'encoding':'gzip','sha256':sha(packed),'bytes':len(packed),'rawSha256':sha(raw),'rawBytes':len(raw)})
index={'schema':'tpnil-native-coverage1-preflight-index@1.0.0','claim':'LOCAL_ENGINEERING_PREFLIGHT_ONLY','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nativeSessions':0,'completeBRC100Conformance':False,'sourceBaseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'finalSourceFreeze':'PENDING_ROOT_FINAL_CHECKS','nativeQualification':'NOT_EXECUTED','finalValidationManifest':'PENDING_ROOT_FINAL_TEST_AND_FREEZE_ADDITIONS','cost':{'actualMoneyUSD':None,'operatorCostUSD':None,'agentCostUSD':None,'ownedCapacityCostUSD':None,'unknownCostsAreZero':False},'historicalSourceResolutions':resolutions,'files':rows,'externalReferences':references}
(dest/'preflight-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'files':len(rows),'rawBytes':sum(x['rawBytes'] for x in rows),'storedBytes':sum(x['bytes'] for x in rows),'externalReferences':len(references),'indexSha256':sha((dest/'preflight-index.json').read_bytes())}))
