from pathlib import Path
import gzip,json,hashlib
root=Path.cwd();base=root/'out/transaction-coverage-sqlite-retry-reference';attempt=base/'attempt-1794470821895';dest=root/'programs/ISI-4/profiles/native-coverage-transactions-2.0.0/reference-sqlite-retry';dest.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();files={}
items={name:attempt/rel for name,rel in [('report.json','evidence/conformance/coverage-transactions.json'),('verification.json','verification.json'),('submissions.json','global-submissions.json'),('final-submissions.json','final-submissions.json'),('final-storage-transactions.json','final-storage-transactions.json'),('closure.json','local-service-closure.json'),('source-before.json','source-before.json'),('source-after.json','source-after.json')]}
items.update({'parent-verification.json':base/'reference-candidate-verification.json','run-reference.ts':base/'run-reference.ts','replay-parent.ts':base/'replay-parent.ts','run.log':base/'run-reference.log','parent.log':base/'replay-parent.log','storage-build.json':root/'out/itcve-go-storage-sqlite-retry.json'})
for name,p in items.items():
 b=p.read_bytes();z=gzip.compress(b,mtime=0);(dest/(name+'.gz')).write_bytes(z);files[name+'.gz']={'sha256':sha(z),'uncompressedSha256':sha(b),'uncompressedBytes':len(b)}
original=json.loads(items['report.json'].read_text());derived=json.loads((base/'reference-candidate.json').read_text());assert original==derived
v=json.loads(items['parent-verification.json'].read_text());assert v['counts']=={'PASS':21,'FAIL':0,'BLOCKED':1}and v['binding']['verified']
m={'schema':'tpnil-native-transaction-sqlite-retry-reference@1.0.0','claim':'LOCAL_CANDIDATE_LIBRARY_EXECUTION_WITH_OBSERVED_SERVICE_CLOSURE','actualNative':False,'nativeQualification':None,'candidateSource':'4a954ac6bb0cb4403fb8ed548efd0cd8d1ba11b1','storageBuildSha256':sha(items['storage-build.json'].read_bytes()),'counts':v['counts'],'publicCalls':121,'signedTransactions':23,'actualFeeSatoshis':414,'postCloseParentVerified':True,'originalAssertionsUnchanged':True,'publicWalletMethodRetries':0,'predecessorReferencePreserved':'../reference/manifest.json','monetaryCost':None,'files':files}
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(sha((dest/'manifest.json').read_bytes()))
