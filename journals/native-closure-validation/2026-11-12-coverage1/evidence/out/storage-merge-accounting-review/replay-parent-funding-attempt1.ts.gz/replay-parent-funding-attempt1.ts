import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { P2PKH, PrivateKey, ProtoWallet, PublicKey, Transaction } from '@bsv/sdk'
import { verifyCoverageModuleFunding } from '../../synthesis/src/wallet-lab/native/verify-coverage-suite.js'
const root=path.resolve(import.meta.dirname,'../..'),dir=path.join(import.meta.dirname,'attempt-1794468345225')
const report=JSON.parse(fs.readFileSync(path.join(dir,'evidence/conformance/coverage-transactions.json'),'utf8')),fixture=JSON.parse(fs.readFileSync(path.join(root,'fixtures/teranode/wab-funding-v1.json'),'utf8'))
const paths=fs.readdirSync(path.join(root,'synthesis/src'),{recursive:true,withFileTypes:true}).filter(p=>p.isFile()).map(p=>path.join(p.parentPath,p.name)).concat(import.meta.filename,path.join(dir,'evidence/conformance/coverage-transactions.json'))
const capture=()=>Object.fromEntries(paths.map(p=>[path.relative(root,p),createHash('sha256').update(fs.readFileSync(p)).digest('hex')]))
const before=capture();fs.writeFileSync(path.join(import.meta.dirname,'funding-source-before.json'),JSON.stringify(before,null,2)+'\n')
const stored=new Map<string,Transaction>(),graph=new Map<string,Transaction>()
for(const row of report.storageTransactions){const tx=Transaction.fromHex(row.rawTxHex);assert.equal(tx.id('hex'),row.txid);stored.set(row.txid,tx);graph.set(row.txid,Transaction.fromHex(row.rawTxHex))}
const add=(tx:Transaction)=>{const id=tx.id('hex');if(graph.has(id))assert.equal(graph.get(id)!.toHex(),tx.toHex());graph.set(id,tx);for(const input of tx.inputs)if(input.sourceTransaction)add(input.sourceTransaction)}
add(Transaction.fromAtomicBEEF([...Buffer.from(fixture.atomicBeefHex,'hex')]))
for(const s of [...report.submissionPrefix,...report.submissions])add(Transaction.fromAtomicBEEF([...Buffer.from(s.beefHex,'hex')]))
for(const row of report.trace)for(const bytes of[row.result?.tx,row.error?.tx])if(bytes)add(Transaction.fromAtomicBEEF(bytes))
for(const tx of graph.values())for(const input of tx.inputs){const parent=graph.get(input.sourceTXID??input.sourceTransaction?.id('hex')??'');if(parent)input.sourceTransaction=parent}
assert.equal(report.submissionPrefix.length,1)
const seed=graph.get(report.submissionPrefix[0].txid)!,sender=new ProtoWallet(PrivateKey.fromHex('77'.repeat(32)))
const prefix=Buffer.from('extension initial funding').toString('base64'),suffix=Buffer.from('funding').toString('base64')
const expected=(await sender.getPublicKey({protocolID:[2,'3241645161d8'],keyID:`${prefix} ${suffix}`,counterparty:report.identity})).publicKey
assert.equal(seed.outputs[0].satoshis,50000);assert.equal(seed.outputs[0].lockingScript.toHex(),new P2PKH().lock(PublicKey.fromString(expected).toAddress()).toHex())
const binding={identity:report.identity,fixture,storageTransactions:stored,resolvedTransactions:graph,declaredNativePayments:[`${seed.id('hex')}.0`]}
const result=await verifyCoverageModuleFunding(report.trace,binding)
const after=capture();assert.deepEqual(after,before);fs.writeFileSync(path.join(import.meta.dirname,'funding-source-after.json'),JSON.stringify(after,null,2)+'\n')
const receipt={claim:'LAB_SELF_TEST_ONLY',actualNative:false,initialNativePayment:binding.declaredNativePayments[0],initialNativePaymentAmount:50000,explicitlyNotFaucetRoot:true,...result}
fs.writeFileSync(path.join(import.meta.dirname,'parent-funding-verification.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({verified:result.verified,admitted:result.admitted.length,nativeRoot:binding.declaredNativePayments[0]}))
