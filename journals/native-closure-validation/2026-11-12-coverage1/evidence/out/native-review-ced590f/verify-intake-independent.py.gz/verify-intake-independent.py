from pathlib import Path,PurePosixPath
import json,hashlib,gzip,zipfile,re,subprocess,posixpath,datetime,collections
root=Path.cwd();p=root/'fixtures/artifacts/yours-wallet-pr368-ced590f';out=root/'out/native-review-ced590f';yours=Path('/Users/tyeverett/tmp/network-ops/worktrees/ty-everett/yours-wallet/codex/ghsa-5vmp-dependency-upgrade');sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_bytes())
m=read('provenance.json');c=read('ci-review.json');assert m['claim']=='ENGINEERING_OBSERVATION_ONLY' and m['officialRelease']==False;assert m['wallet']['version']=='5.1.1-pr368.ced590f';assert m['sourceCommit']=='ced590f9016b7071a366af9cfd069b8984c8a241';assert m['buildCommit']=='8e7e5d152b93078e6c8f55680d3dcb73d2df5e6c'
actual={x.relative_to(p).as_posix():sha(x.read_bytes()) for x in p.rglob('*') if x.is_file() and x.name!='provenance.json'};assert actual==m['files'] and len(actual)==343
inner=(p/'pw-v5.1.1.zip').read_bytes();assert sha(inner)==m['wallet']['sha256']=='4e2bfbc2434974197a24c421efd5e7a23878f74a0420a5a2cf21c3b3c17137ee';assert len(inner)==m['wallet']['size']==13243765
outerpath=p/f"ci/artifact-{m['artifactId']}.zip";assert sha(outerpath.read_bytes())==m['outerArtifactSha256'];assert sha(outerpath.read_bytes())=='e14660132769a7dc08e1d9df4f679d5b2b90a673f568ee92330e7c0518436492'
with zipfile.ZipFile(outerpath) as outer:
 assert sorted(outer.namelist())==['SHA256SUMS','pw-v5.1.1.zip','pw-v5.1.1.zip.sha256'];assert outer.read('pw-v5.1.1.zip')==inner;assert outer.testzip() is None
 assert sha(inner) in outer.read('pw-v5.1.1.zip.sha256').decode()
maps={};contents={}
with zipfile.ZipFile(p/'pw-v5.1.1.zip') as z:
 files=[i for i in z.infolist() if not i.is_dir()]; names=[i.filename for i in files];assert len(names)==len(set(names))==45 and len(set(n.lower() for n in names))==45;assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names);assert z.testzip() is None
 members=read('zip-members.json');assert {x['name'] for x in members}==set(names)
 for x in members:
  b=z.read(x['name']);assert len(b)==x['size'] and sha(b)==x['sha256'];contents[x['name']]=b
 for n in names:
  if n.endswith('.map'):maps[n]=json.loads(contents[n])
 manifest=json.loads(contents['build/manifest.json']);assert manifest['version']==m['manifestVersion']=='5.1.1'
run=read('ci/run.json');jobs=read('ci/jobs.json');arts=read('ci/artifacts.json');head=read('ci/source-head-commit.json');merge=read('ci/built-merge-commit.json')
assert run['id']==m['workflowRun']==43172062868 and run['conclusion']=='success' and run['event']=='pull_request' and run['head_sha']==m['sourceCommit']
assert head['sha']==m['sourceCommit'] and merge['sha']==m['buildCommit'];assert head['tree']['sha']==merge['tree']['sha']==m['gitTreeSha']=='5045bf6f88ddaf8de7b22def8aaa56e5fb2603f1';assert [x['sha'] for x in merge['parents']]==m['buildParents'];assert m['sourceCommit'] in m['buildParents']
artifact=next(a for a in arts['artifacts'] if a['id']==m['artifactId']);assert artifact['digest']=='sha256:'+m['outerArtifactSha256'];assert artifact['workflow_run']['id']==m['workflowRun'] and artifact['workflow_run']['head_sha']==m['sourceCommit']
parse=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'));seconds=sum((parse(j['completed_at'])-parse(j['started_at'])).total_seconds() for j in jobs['jobs'] if j['conclusion']!='skipped');assert seconds==c['cost']['completedJobSeconds']==95
log=gzip.decompress((p/m['rawJobLog']['path']).read_bytes());assert len(log)==m['rawJobLog']['uncompressedBytes'] and sha(log)==m['rawJobLog']['uncompressedSha256'];text=log.decode();assert re.search(r'\b207 pass\b',text) and re.search(r'\b0 fail\b',text) and '1367 expect() calls' in text and 'Ran 207 tests across 15 files.' in text;assert m['buildCommit'] in text and m['sourceCommit'] in text
# Independently bind every retained own-source proof to committed source and exact ZIP sourcemap bytes.
proofcount=0
for source,entries in c['sourceMapProof'].items():
 committed=subprocess.check_output(['git','show',f"{m['sourceCommit']}:{source}"],cwd=yours)
 for entry in entries:
  a=maps[entry['map']];ix=a['sources'].index(entry['source']);b=a['sourcesContent'][ix].encode();assert sha(b)==entry['sha256']==sha(committed),(source,entry['map']);proofcount+=1
# The patched dependency proof is actual source content from the frozen installed source-owned patches.
patched=0
for source,entries in c['patchedDependencySourceProof'].items():
 installed=(yours/'.cache/native-final-contract/package-after/out/index.client.mjs').read_bytes() if source=='node_modules/@bsv/wallet-toolbox-client/out/index.client.mjs' else (yours/source).read_bytes()
 for entry in entries:
  a=maps[entry['map']];b=a['sourcesContent'][a['sources'].index(entry['source'])].encode();assert sha(b)==entry['sha256']==sha(installed),(source,entry['map']);patched+=1
for x in (p/'source').rglob('*'):
 if x.is_file():assert x.read_bytes()==subprocess.check_output(['git','show',f"{m['sourceCommit']}:{x.relative_to(p/'source').as_posix()}"],cwd=yours)
licenses=read('licenses.json');assert len(licenses['packages'])==licenses['packageVersions']==139
licensed=set();installs=set();package_names=set()
for pkg in licenses['packages']:
 package_names.add(pkg['package']);installs.update(pkg['installPaths']);metadata=[]
 for f in pkg['retained']:
  b=(p/f['path']).read_bytes();assert sha(b)==f['sha256']
  if f['path'].endswith('/package.json'):metadata.append(json.loads(b))
 assert len(metadata)==1 and metadata[0]['name']==pkg['resolvedName'] and metadata[0]['version']==pkg['version']
 for e in pkg['sourceMapPaths']:
  key=(e['map'],e['source']);a=maps[key[0]];b=a['sourcesContent'][a['sources'].index(key[1])].encode();assert sha(b)==e['sha256'];assert key not in licensed;licensed.add(key)
actual_modules={(n,s) for n,a in maps.items() for s in a['sources'] if 'node_modules/' in s};assert licensed==actual_modules,(len(licensed),len(actual_modules))
assert len(package_names)==licenses['packageNames']==134 and len(installs)==licenses['installationPaths']==145
prior=root/m['predecessorIntake']['path'];assert sha(prior.read_bytes())==m['predecessorIntake']['sha256'];prior_m=json.loads(prior.read_bytes())
for n,digest in prior_m['files'].items():assert sha((prior.parent/n).read_bytes())==digest
receipt={'schema':'tpnil-candidate-intake-independent-review@1','claim':'CI_ENGINEERING_ARTIFACT_INTEGRITY_ONLY','qualifiedNativeEvidence':False,'newNativeSessions':0,'manifestSha256':sha((p/'provenance.json').read_bytes()),'files':len(actual),'innerMembers':45,'innerZipSha256':sha(inner),'innerZipBytes':len(inner),'outerZipSha256':sha(outerpath.read_bytes()),'sourceCommit':m['sourceCommit'],'buildCommit':m['buildCommit'],'equalGitTree':m['gitTreeSha'],'workflowRun':m['workflowRun'],'actualCIJobSeconds':seconds,'sourceFilesComparedToGit':len(c['sourceMapProof']),'sourceMapOccurrences':proofcount,'patchedDependencySourceOccurrences':patched,'licensePackageNames':len(package_names),'licensePackageVersions':len(licenses['packages']),'licenseInstallationPaths':len(installs),'licenseSourceMapOccurrences':len(licensed),'testsFromRawLog':{'PASS':207,'FAIL':0,'expectations':1367,'files':15},'priorCbIntakeUnchanged':True,'reviewerScriptSha256':sha(Path(__file__).read_bytes())}
f=out/'intake-independent-review.json';f.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print('receiptSHA',sha(f.read_bytes()))
