import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { Beef, P2PKH, PublicKey, Transaction } from '@bsv/sdk'
import { StorageClient } from '@bsv/wallet-toolbox'
const mode=process.argv[2];assert.ok(mode==='baseline'||mode==='corrected')
const root=path.resolve(import.meta.dirname,'../..'), binaryName=mode==='baseline'?'storage-merge-accounting':'storage-input-ancestry'
const snapshot=path.join(import.meta.dirname,mode),out=path.join(import.meta.dirname,`${mode}-${Date.now()}`);fs.mkdirSync(out)
const {ControlledWalletServices}=await import(path.join(snapshot,'synthesis/src/wallet-lab/services.ts'))
const {createFixtureWallet}=await import(path.join(snapshot,'synthesis/src/storage-sync/fixture-wallet.ts'))
const files=[...Object.keys(JSON.parse(fs.readFileSync(path.join(snapshot,'source-inventory.json'),'utf8'))).map(n=>path.join(snapshot,n)),path.join(root,`out/itcve-go-${binaryName}.json`),path.join(root,'synthesis/package-lock.json'),import.meta.filename]
const capture=()=>Object.fromEntries(files.map(n=>[path.relative(root,n),createHash('sha256').update(fs.readFileSync(n)).digest('hex')]))
const before=capture();fs.writeFileSync(path.join(out,'source-before.json'),JSON.stringify(before,null,2)+'\n')
const services=new ControlledWalletServices({webroot:out,components:{storage:'go'},go:{binary:path.join(root,`out/itcve-go-${binaryName}`),storageNativeContractsPatch:true,terminalRejectionReceipts:true}})
let wallet:any,funder:any;const trace:any[]=[],storageTrace:any[]=[]
const call=async(actor:string,target:any,method:string,args:any)=>{const row:any={actor,method,args};trace.push(row);try{row.result=await target[method](args);return row.result}catch(e:any){row.error={name:e.name,message:e.message,code:e.code};throw e}}
const tracedClient=(owner:any,endpoint:string)=>{const c:any=new StorageClient(owner,endpoint),original=c.createAction.bind(c);c.createAction=async(...args:any[])=>{const row:any={args:structuredClone(args)};storageTrace.push(row);try{row.result=await original(...args);return row.result}catch(e:any){row.error={name:e.name,message:e.message};throw e}};return c}
try {
 await services.start();await services.fundRemoteWalletFromTeranode('77'.repeat(32),JSON.parse(fs.readFileSync(path.join(root,'fixtures/teranode/wab-funding-v1.json'),'utf8')))
 funder=await createFixtureWallet(services,'77'.repeat(32));wallet=await createFixtureWallet(services,'78'.repeat(32),tracedClient)
 const identity=(await call('wallet',wallet,'getPublicKey',{identityKey:true})).publicKey,senderIdentityKey=(await call('funder',funder,'getPublicKey',{identityKey:true})).publicKey
 const derivationPrefix=Buffer.from('input ancestry initial funding').toString('base64'),derivationSuffix=Buffer.from('reserve').toString('base64')
 const key=await call('funder',funder,'getPublicKey',{protocolID:[2,'3241645161d8'],keyID:`${derivationPrefix} ${derivationSuffix}`,counterparty:identity})
 const seed=await call('funder',funder,'createAction',{description:'Input ancestry controlled funding',outputs:[{satoshis:50000,lockingScript:new P2PKH().lock(PublicKey.fromString(key.publicKey).toAddress()).toHex(),outputDescription:'Controlled ancestry source'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}})
 await call('wallet',wallet,'internalizeAction',{tx:seed.tx,outputs:[{outputIndex:0,protocol:'wallet payment',paymentRemittance:{derivationPrefix,derivationSuffix,senderIdentityKey}}],description:'Input ancestry wallet funding'})
 const fanout=await call('wallet',wallet,'createAction',{description:'Input ancestry owned custom source',outputs:[{satoshis:100,lockingScript:'7551',basket:'ancestry source',outputDescription:'Caller selected owned input'}],options:{randomizeOutputs:false,acceptDelayedBroadcast:false}})
 await wallet.destroy();wallet=await createFixtureWallet(services,'78'.repeat(32),tracedClient)
 const paid=await call('wallet',wallet,'createAction',{description:'Input ancestry omitted input proof',inputBEEF:new Beef().toBinary(),inputs:[{outpoint:`${fanout.txid}.0`,inputDescription:'Stored caller input',unlockingScript:'51'}],outputs:[{satoshis:2,lockingScript:'51',outputDescription:'Ancestry result first'},{satoshis:3,lockingScript:'51',outputDescription:'Ancestry result second'}],options:{acceptDelayedBroadcast:false}})
 const tx=Transaction.fromAtomicBEEF(paid.tx);assert.equal(tx.id('hex'),paid.txid);assert.equal(tx.inputs.length,1);assert.equal(tx.inputs[0].sourceTXID,fanout.txid);assert.equal(tx.inputs[0].sourceOutputIndex,0);assert.equal(tx.inputs[0].unlockingScript?.toHex(),'51')
 const tracker={isValidRootForHeight:async(r:string,h:number)=>services.headers.get(h)?.merkleRoot===r,currentHeight:async()=>900100}
 const publicProof=await tx.verify(tracker),responseBeef=Beef.fromBinary(storageTrace.at(-1).result.inputBeef)
 const stored=await services.nativeTransactions();assert.equal(stored.find((r:any)=>r.txid===paid.txid)?.rawTxHex,tx.toHex())
 const callerSource=responseBeef.findTxid(fanout.txid),receipt={claim:'LAB_SELF_TEST_ONLY',actualNative:false,mode,calls:trace.length,txid:paid.txid,publicProof,storageBytesMatch:true,responseGraphTransactions:responseBeef.txs.length,responseCallerSourceBody:!!callerSource?.tx,publicBytes:paid.tx.length}
 fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');fs.writeFileSync(path.join(out,'storage-transactions.json'),JSON.stringify(stored,null,2)+'\n');fs.writeFileSync(path.join(out,'submissions.json'),JSON.stringify(services.submissions.map((r:any)=>({txid:r.txid,beefHex:Buffer.from(r.bytes).toString('hex'),verdict:r.verdict})),null,2)+'\n')
 assert.equal(publicProof,mode==='corrected');assert.equal(!!callerSource?.tx,mode==='corrected');console.log(JSON.stringify({out,...receipt}))
}finally{fs.writeFileSync(path.join(out,'trace.json'),JSON.stringify(trace,null,2)+'\n');fs.writeFileSync(path.join(out,'storage-client-trace.json'),JSON.stringify(storageTrace,null,2)+'\n');await wallet?.destroy();await funder?.destroy();await services.close();const after=capture();fs.writeFileSync(path.join(out,'source-after.json'),JSON.stringify(after,null,2)+'\n');assert.deepEqual(after,before)}
