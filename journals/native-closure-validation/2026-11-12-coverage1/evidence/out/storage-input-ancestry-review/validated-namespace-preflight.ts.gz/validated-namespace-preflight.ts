import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { PrivateKey, ProtoWallet, PushDrop, Utils } from '@bsv/sdk'
import { Wallet } from './candidate-package/out/index.client.mjs'
import { CachedKeyDeriver, PrivateKey as CandidatePrivateKey } from './candidate-package/node_modules/@bsv/sdk/dist/esm/mod.js'
import { encodeBoardToken, decodeAndVerifyBoardToken } from '../../synthesis/src/board.js'
const key='21'.repeat(32),deriver=new CachedKeyDeriver(CandidatePrivateKey.fromHex(key)),trace:any[]=[]
const storage:any={_authId:{identityKey:deriver.identityKey},setServices(){},getSettings:()=>({storageIdentityKey:deriver.identityKey,storageName:'public-crypto-fixture'})}
const wallet=new Wallet({chain:'main',keyDeriver:deriver,storage,services:{} as any,actionBatchMode:'legacy'})
const boundary:any=new Proxy(wallet,{get(target,method){if(typeof method!=='string'||!['getPublicKey','createSignature'].includes(method))return (target as any)[method];return async(args:any)=>{const r:any={method,args};trace.push(r);try{r.result=await(target as any)[method](args);return r.result}catch(e:any){r.error={name:e.name,message:e.message};throw e}}}})
const input={id:'a1'.repeat(32),key:'validated fixture',revision:1,previous:null,createdAt:0,body:'Validated lowercase fixture',attachment:{assetId:'b2'.repeat(32),plaintextSha256:'c3'.repeat(32),lch:'retained controlled header',mediaType:'text/plain'}}
const board=await encodeBoardToken(boundary,input,'validated-v2'),independent=await encodeBoardToken(new ProtoWallet(PrivateKey.fromHex(key)),input,'validated-v2')
assert.equal(board.lockingScriptHex,independent.lockingScriptHex);assert.deepEqual(await decodeAndVerifyBoardToken(board.lockingScriptHex,'validated-v2'),board.record)
const fields=[Utils.toArray('SLAP','utf8'),Utils.toArray(deriver.identityKey,'hex'),Utils.toArray('https://overlay.itcve.test','utf8'),Utils.toArray('ls_identity','utf8')]
const slap=await new PushDrop(boundary).lock(structuredClone(fields),[2,'service lookup availability'],'1','anyone',true)
const expectedSlap=await new PushDrop(new ProtoWallet(PrivateKey.fromHex(key))).lock(structuredClone(fields),[2,'service lookup availability'],'1','anyone',true)
assert.equal(slap.toHex(),expectedSlap.toHex())
const paths=['synthesis/src/board.ts','integrations/services/src/identity.ts','out/storage-input-ancestry-review/validated-namespace-preflight.ts','out/storage-input-ancestry-review/candidate-package/out/index.client.mjs'],root=path.resolve(import.meta.dirname,'../..')
const receipt={claim:'LAB_SELF_TEST_ONLY',actualNative:false,actualWallet:'copied source-owned2.14.8 client',boardScriptMatchesIndependentKey:true,boardSignatureVerified:true,slapScriptMatchesIndependentKey:true,publicCalls:trace.length,trace,files:Object.fromEntries(paths.map(p=>[p,createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex')]))}
fs.writeFileSync(path.join(import.meta.dirname,'validated-namespace-preflight.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({board:true,slap:true,calls:trace.length}))
