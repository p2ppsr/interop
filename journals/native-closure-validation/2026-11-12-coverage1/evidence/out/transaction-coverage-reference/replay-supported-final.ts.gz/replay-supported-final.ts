import fs from 'node:fs'; import path from 'node:path'
import { Transaction } from '@bsv/sdk'
import { deriveTransactionCoverageOutcomes, verifyNativeTransactionCoverage, verifyTransactionCoverageParentBindings } from '../../synthesis/src/wallet-lab/native/coverage-transactions-verifier.js'
import { coverageAtomic, coverageDuplicateControlAtomic } from '../../synthesis/src/wallet-lab/native/coverage-transactions-program.js'
const root=path.resolve(import.meta.dirname,'../..'), dir=path.join(import.meta.dirname,'attempt-1794465655230'), report=JSON.parse(fs.readFileSync(path.join(dir,'evidence/conformance/coverage-transactions.json'),'utf8'))
report.assertions=await deriveTransactionCoverageOutcomes(report); report.result=report.assertions.some((r:any)=>r.result==='FAIL')?'FAIL':report.assertions.some((r:any)=>r.result==='BLOCKED')?'BLOCKED':'PASS'
const fixture=JSON.parse(fs.readFileSync(path.join(root,'fixtures/teranode/wab-funding-v1.json'),'utf8')), graph=new Map<string,Transaction>(), stored=new Map<string,Transaction>()
for(const r of report.storageTransactions){const tx=Transaction.fromHex(r.rawTxHex);stored.set(r.txid,tx);graph.set(r.txid,tx)}
const add=(tx:Transaction)=>{if(graph.has(tx.id('hex'))&&graph.get(tx.id('hex'))!.toHex()!==tx.toHex())throw Error('body mismatch');graph.set(tx.id('hex'),tx);for(const i of tx.inputs)if(i.sourceTransaction)add(i.sourceTransaction)}
add(coverageAtomic([...Buffer.from(fixture.atomicBeefHex,'hex')]))
for(const r of report.trace)for(const bytes of[r.result?.tx,r.error?.tx,r.id.endsWith('-control')?r.args?.tx:undefined])if(bytes)try{add(r.id==='proof-duplicate-control'&&bytes===r.args.tx?coverageDuplicateControlAtomic(bytes):coverageAtomic(bytes))}catch{}
const global=JSON.parse(fs.readFileSync(path.join(dir,'global-submissions.json'),'utf8'))
const result=await verifyNativeTransactionCoverage(report)
let binding:any; try{binding=await verifyTransactionCoverageParentBindings(report,{identity:report.identity,globalSubmissions:global,finalSubmissions:global,storageTransactions:stored,graph:{resolvedTransactions:graph,requireResolvedAncestors:true,trustedMinedRoot:{txid:fixture.txid,rawHex:fixture.rawHex}}})}catch(e){binding={error:String(e),stack:(e as Error).stack}}
fs.writeFileSync(path.join(import.meta.dirname,'reference-supported-final.json'),JSON.stringify(report));fs.writeFileSync(path.join(import.meta.dirname,'reference-supported-final-verification.json'),JSON.stringify({claim:'LAB_SELF_TEST_ONLY',actualNative:false,...result,binding},null,2)+'\n')
console.log(JSON.stringify({counts:result.counts,calls:report.trace.length,binding,nonpass:report.assertions.filter((r:any)=>r.result!=='PASS')}))
