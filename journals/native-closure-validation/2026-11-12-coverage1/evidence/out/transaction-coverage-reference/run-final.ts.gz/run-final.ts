import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import path from 'node:path'
import { P2PKH, PublicKey } from '@bsv/sdk'
import { ControlledWalletServices } from '../../synthesis/src/wallet-lab/services.js'
import { createFixtureWallet } from '../../synthesis/src/storage-sync/fixture-wallet.js'
import { EvidenceBundle } from '../../synthesis/src/wallet-lab/evidence.js'
import { runNativeTransactionCoverage } from '../../synthesis/src/wallet-lab/native/coverage-transactions-producer.js'
import { verifyNativeTransactionCoverage } from '../../synthesis/src/wallet-lab/native/coverage-transactions-verifier.js'
const root = path.resolve(import.meta.dirname, '../..'), out = path.join(import.meta.dirname, `attempt-${Date.now()}`)
fs.mkdirSync(out)
const paths = [...execFileSync('git', ['ls-tree', '-r', '--name-only', '69b1b52', '--', 'synthesis/src'], { cwd: root, encoding: 'utf8' }).trim().split('\n'), ...['model','program','producer','verifier'].map(name => `synthesis/src/wallet-lab/native/coverage-transactions-${name}.ts`), 'programs/ISI-4/profiles/native-coverage-transactions-1.0.0/policy.json', 'synthesis/package-lock.json', 'out/itcve-go-storage-native-contracts.json']
const capture = () => Object.fromEntries(paths.map(name => [name, createHash('sha256').update(fs.readFileSync(path.join(root, name))).digest('hex')]))
const before = capture(); fs.writeFileSync(path.join(out,'source-before.json'), JSON.stringify(before,null,2)+'\n')
for(const name of paths) { const dest = path.join(out,'source',name); fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(path.join(root,name),dest) }

const services = new ControlledWalletServices({ webroot: out, components: { storage: 'go' }, go: { binary: path.join(root, 'out/itcve-go-storage-native-contracts'), storageNativeContractsPatch: true, terminalRejectionReceipts: true } })
let wallet: any, funder: any
try {
  await services.start(); await services.fundRemoteWalletFromTeranode('77'.repeat(32), JSON.parse(fs.readFileSync(path.join(root, 'fixtures/teranode/wab-funding-v1.json'), 'utf8')))
  wallet = await createFixtureWallet(services, '78'.repeat(32)); funder = await createFixtureWallet(services, '77'.repeat(32))
  const identity = (await wallet.getPublicKey({ identityKey: true })).publicKey, senderIdentityKey = (await funder.getPublicKey({ identityKey: true })).publicKey
  const derivationPrefix = Buffer.from('extension initial funding').toString('base64'), derivationSuffix = Buffer.from('funding').toString('base64')
  const key = await funder.getPublicKey({ protocolID: [2, '3241645161d8'], keyID: `${derivationPrefix} ${derivationSuffix}`, counterparty: identity })
  const seed = await funder.createAction({ description: 'Transaction coverage reference funding', outputs: [{ satoshis: 50000, lockingScript: new P2PKH().lock(PublicKey.fromString(key.publicKey).toAddress()).toHex(), outputDescription: 'Transaction coverage controlled wallet funds' }], options: { randomizeOutputs: false, acceptDelayedBroadcast: false } })
  await wallet.internalizeAction({ tx: seed.tx, outputs: [{ outputIndex: 0, protocol: 'wallet payment', paymentRemittance: { derivationPrefix, derivationSuffix, senderIdentityKey } }], description: 'Transaction coverage controlled funds' })
  const evidence = new EvidenceBundle(out)
  const report = await runNativeTransactionCoverage({ wallet, funder, identity, services, evidence }); evidence.flush()
  const result = await verifyNativeTransactionCoverage(report)
  fs.writeFileSync(path.join(out, 'verification.json'), JSON.stringify({ ...result, claim: 'LAB_SELF_TEST_ONLY', actualNative: false, calls: report.trace.length, assertions: report.assertions }, null, 2)+'\n')
  fs.writeFileSync(path.join(out, 'global-submissions.json'), JSON.stringify(services.submissions.map(r => ({ txid: r.txid, beefHex: Buffer.from(r.bytes).toString('hex'), verdict: r.verdict })),null,2)+'\n')
  console.log(JSON.stringify({out,calls:report.trace.length,counts:result.counts,failures:report.assertions.filter(x=>x.result!=='PASS')}))
} finally { await wallet?.destroy(); await funder?.destroy(); await services.close(); const after=capture(); fs.writeFileSync(path.join(out,'source-after.json'),JSON.stringify(after,null,2)+'\n'); assert.deepEqual(after,before,'Executed source changed during reference run') }
