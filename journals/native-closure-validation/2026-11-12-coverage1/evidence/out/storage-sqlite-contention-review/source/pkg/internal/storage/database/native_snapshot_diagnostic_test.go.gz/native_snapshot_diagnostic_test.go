package database

import (
	"context"
	"errors"
	"fmt"
	"path/filepath"
	"testing"

	"github.com/mattn/go-sqlite3"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"

	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/defs"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/internal/storage/dbretry"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/logging"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/randomizer"
)

// Diagnostic only: the unmodified configured database and outer transaction
// retry owner encounter an explicitly scheduled read-to-write snapshot race.
func TestNativeSnapshotDiagnostic(t *testing.T) {
	cfg := defs.DefaultDBConfig()
	cfg.SQLite.ConnectionString = filepath.Join(t.TempDir(), "wallet.sqlite")
	db, err := NewDatabase(cfg, logging.NewTestLogger(t))
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, db.Close()) })
	require.NoError(t, db.DB.Exec("CREATE TABLE snapshot_diagnostic (id INTEGER PRIMARY KEY, value INTEGER NOT NULL)").Error)
	require.NoError(t, db.DB.Exec("INSERT INTO snapshot_diagnostic VALUES (1, 0)").Error)
	var journal string
	var timeout int
	require.NoError(t, db.DB.Raw("PRAGMA journal_mode").Scan(&journal).Error)
	require.NoError(t, db.DB.Raw("PRAGMA busy_timeout").Scan(&timeout).Error)
	require.Equal(t, "wal", journal)
	require.Equal(t, 5000, timeout)
	attempts := 0
	err = dbretry.Do(context.Background(), logging.NewTestLogger(t), randomizer.New(), func() error {
		attempts++
		return db.DB.Transaction(func(tx *gorm.DB) error {
			var before int
			if err := tx.Raw("SELECT value FROM snapshot_diagnostic WHERE id=1").Scan(&before).Error; err != nil { return err }
			// A separate pooled connection commits while this transaction's
			// earlier snapshot remains held. No sleeps or timing assumptions.
			if attempts == 1 {
				if err := db.DB.Exec("UPDATE snapshot_diagnostic SET value=value+10 WHERE id=1").Error; err != nil { return err }
			}
			return tx.Exec("UPDATE snapshot_diagnostic SET value=value+1 WHERE id=1").Error
		})
	})
	var sqliteErr sqlite3.Error
	require.True(t, errors.As(err, &sqliteErr), "expected raw SQLite error, got %T: %v", err, err)
	require.Equal(t, sqlite3.ErrBusySnapshot, sqliteErr.ExtendedCode)
	require.Equal(t, 1, attempts)
	require.False(t, dbretry.Retryable(fmt.Errorf("cannot save known tx: %w", err)))
	var value int
	require.NoError(t, db.DB.Raw("SELECT value FROM snapshot_diagnostic WHERE id=1").Scan(&value).Error)
	require.Equal(t, 10, value, "failed increment was fully rolled back")
	t.Logf("DIAGNOSTIC journal=%s busy_timeout=%d attempts=%d code=%d extended_code=%d value=%d exact_error=%q retryable=%v", journal, timeout, attempts, sqliteErr.Code, sqliteErr.ExtendedCode, value, err.Error(), dbretry.Retryable(err))
	// Explicitly starting a fresh transaction after rollback succeeds, matching
	// the official SQLite recovery rule. This is not a retry in a wallet API.
	require.NoError(t, db.DB.Transaction(func(tx *gorm.DB) error { return tx.Exec("UPDATE snapshot_diagnostic SET value=value+1 WHERE id=1").Error }))
	require.NoError(t, db.DB.Raw("SELECT value FROM snapshot_diagnostic WHERE id=1").Scan(&value).Error)
	require.Equal(t, 11, value)
}
