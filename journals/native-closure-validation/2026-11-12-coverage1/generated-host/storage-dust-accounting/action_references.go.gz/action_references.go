package main

import (
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"net/http"

	ec "github.com/bsv-blockchain/go-sdk/primitives/ec"
	"gorm.io/gorm"
)

type actionReference struct {
	TxID      string `json:"txid"`
	Reference string `json:"reference"`
}

// The bearer-authorized observer reads immutable action identifiers from the
// controlled storage. This endpoint never reads or changes private wallet state.
func actionReferencesHandler(db *gorm.DB, token string) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if token == "" || subtle.ConstantTimeCompare([]byte(r.Header.Get("Authorization")), []byte("Bearer "+token)) != 1 {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		query := r.URL.Query()
		values := query["identityKey"]
		if len(query) != 1 || len(values) != 1 || len(values[0]) != 66 {
			http.Error(w, "one compressed identityKey is required", http.StatusBadRequest)
			return
		}
		identity := values[0]
		key, err := ec.PublicKeyFromString(identity)
		if err != nil || key.X.Sign() < 0 || key.X.Cmp(key.Params().P) >= 0 || key.Y.Sign() < 0 || key.Y.Cmp(key.Params().P) >= 0 || !key.Validate() || key.ToDERHex() != identity {
			http.Error(w, "invalid identityKey", http.StatusBadRequest)
			return
		}
		rows := []actionReference{}
		txs, users := db.NamingStrategy.TableName("Transaction"), db.NamingStrategy.TableName("User")
		err = db.WithContext(r.Context()).Table(txs+" AS t").
			Select("t.tx_id, t.reference").Joins("JOIN "+users+" AS u ON u.user_id = t.user_id").
			Where("u.identity_key = ? AND t.deleted_at IS NULL AND t.tx_id IS NOT NULL AND t.tx_id <> ''", identity).
			Order("t.tx_id ASC, t.reference ASC").Limit(2049).Scan(&rows).Error
		if err != nil || len(rows) > 2048 {
			http.Error(w, "action reference snapshot failed or exceeded budget", http.StatusInternalServerError)
			return
		}
		seen := map[string]bool{}
		for _, row := range rows {
			txid, txErr := hex.DecodeString(row.TxID)
			ref, refErr := base64.StdEncoding.Strict().DecodeString(row.Reference)
			if txErr != nil || len(txid) != 32 || hex.EncodeToString(txid) != row.TxID || seen[row.TxID] || refErr != nil || len(ref) == 0 || base64.StdEncoding.EncodeToString(ref) != row.Reference {
				http.Error(w, "invalid or ambiguous stored action reference", http.StatusInternalServerError)
				return
			}
			seen[row.TxID] = true
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(rows)
	})
}
