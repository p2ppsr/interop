package main

import (
	"bytes"
	"crypto/subtle"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"unicode/utf8"

	ec "github.com/bsv-blockchain/go-sdk/primitives/ec"
	"github.com/bsv-blockchain/go-sdk/transaction"
	"gorm.io/gorm"
)

const outputSnapshotLimit = 2048

type nativeOutputRow struct {
	OutputID           uint     `json:"outputId"`
	TransactionID      uint     `json:"transactionId"`
	Outpoint           *string  `json:"outpoint"`
	TxID               *string  `json:"txid"`
	RawTx              *string  `json:"rawTx"`
	Vout               uint32   `json:"vout"`
	Satoshis           int64    `json:"satoshis"`
	LockingScript      string   `json:"lockingScript"`
	Spendable          bool     `json:"spendable"`
	BasketName         *string  `json:"basketName"`
	Tags               []string `json:"tags"`
	CustomInstructions *string  `json:"customInstructions"`
}
type nativeOutputSnapshot struct {
	Schema              string            `json:"schema"`
	IdentityKey         string            `json:"identityKey"`
	ProviderIdentityKey string            `json:"providerIdentityKey"`
	Outputs             []nativeOutputRow `json:"outputs"`
}

func snapshotIdentity(value string) bool {
	if len(value) != 66 {
		return false
	}
	key, err := ec.PublicKeyFromString(value)
	return err == nil && key.X.Sign() >= 0 && key.X.Cmp(key.Params().P) < 0 && key.Y.Sign() >= 0 && key.Y.Cmp(key.Params().P) < 0 && key.Validate() && key.ToDERHex() == value
}

// Explicit v2 observation scope: every active output owned by the requested user,
// including pending outputs with no transaction ID. No wallet/RPC mutation occurs.
// The parent must bind IdentityKey and ProviderIdentityKey to its owned registry.
func nativeOutputSnapshotHandler(db *gorm.DB, token string) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if token == "" || subtle.ConstantTimeCompare([]byte(r.Header.Get("Authorization")), []byte("Bearer "+token)) != 1 {
			http.Error(w, "unauthorized", 401)
			return
		}
		if r.Method != http.MethodGet {
			http.Error(w, "GET required", 405)
			return
		}
		query := r.URL.Query()
		values := query["identityKey"]
		if len(query) != 1 || len(values) != 1 || !snapshotIdentity(values[0]) {
			http.Error(w, "one canonical identityKey is required", 400)
			return
		}
		result := nativeOutputSnapshot{Schema: "tpnil-native-output-snapshot@2.0.0", IdentityKey: values[0], Outputs: []nativeOutputRow{}}
		err := db.WithContext(r.Context()).Transaction(func(tx *gorm.DB) error {
			names := func(n string) string { return tx.NamingStrategy.TableName(n) }
			var providers []string
			if err := tx.Table(names("Setting")).Select("storage_identity_key").Limit(2).Scan(&providers).Error; err != nil {
				return err
			}
			if len(providers) != 1 || !snapshotIdentity(providers[0]) {
				return fmt.Errorf("invalid provider identity")
			}
			result.ProviderIdentityKey = providers[0]
			var owners []int
			if err := tx.Table(names("User")).Select("user_id").Where("identity_key = ?", result.IdentityKey).Limit(2).Scan(&owners).Error; err != nil {
				return err
			}
			if len(owners) != 1 {
				return fmt.Errorf("identity must resolve to exactly one owned user")
			}
			type storedOutput struct {
				ID                 uint
				UserID             int
				TransactionID      uint
				TransactionOwner   *int
				TransactionDeleted *string
				Vout               uint32
				Satoshis           int64
				LockingScript      []byte
				Spendable          bool
				BasketName         *string
				CustomInstructions *string
				TxID               *string
				RawTx              []byte
			}
			rows := []storedOutput{}
			err := tx.Table(names("Output")+" AS o").Select("o.id,o.user_id,o.transaction_id,t.user_id AS transaction_owner,t.deleted_at AS transaction_deleted,o.vout,o.satoshis,o.locking_script,o.spendable,o.basket_name,o.custom_instructions,t.tx_id,k.raw_tx").
				Joins("LEFT JOIN "+names("Transaction")+" AS t ON t.id=o.transaction_id").
				Joins("LEFT JOIN "+names("KnownTx")+" AS k ON k.tx_id=t.tx_id").
				Where("o.user_id = ? AND o.deleted_at IS NULL", owners[0]).Order("o.id ASC").Limit(outputSnapshotLimit + 1).Scan(&rows).Error
			if err != nil {
				return err
			}
			if len(rows) > outputSnapshotLimit {
				return fmt.Errorf("output budget exceeded")
			}
			seenID := map[uint]bool{}
			seenOutpoint := map[string]bool{}
			totalBytes := 0
			for _, row := range rows {
				if row.ID == 0 || seenID[row.ID] || row.TransactionOwner == nil || *row.TransactionOwner != owners[0] || row.TransactionDeleted != nil || row.Satoshis < 0 || len(row.LockingScript) > 2*1024*1024 {
					return fmt.Errorf("invalid output owner or metadata")
				}
				seenID[row.ID] = true
				for _, v := range []*string{row.BasketName, row.CustomInstructions} {
					if v != nil && (!utf8.ValidString(*v) || len(*v) > 4*1024*1024) {
						return fmt.Errorf("invalid output text")
					}
				}
				value := nativeOutputRow{OutputID: row.ID, TransactionID: row.TransactionID, Vout: row.Vout, Satoshis: row.Satoshis, LockingScript: hex.EncodeToString(row.LockingScript), Spendable: row.Spendable, BasketName: row.BasketName, CustomInstructions: row.CustomInstructions, Tags: []string{}}
				if row.TxID != nil {
					raw, decodeErr := hex.DecodeString(*row.TxID)
					if decodeErr != nil || len(raw) != 32 || hex.EncodeToString(raw) != *row.TxID || len(row.RawTx) == 0 || len(row.RawTx) > 16*1024*1024 {
						return fmt.Errorf("signed output lacks canonical transaction")
					}
					parsed, parseErr := transaction.NewTransactionFromBytes(row.RawTx)
					if parseErr != nil || !bytes.Equal(parsed.Bytes(), row.RawTx) || parsed.TxID().String() != *row.TxID || int(row.Vout) >= len(parsed.Outputs) {
						return fmt.Errorf("stored output transaction mismatch")
					}
					output := parsed.Outputs[row.Vout]
					if output.Satoshis != uint64(row.Satoshis) || output.LockingScript == nil || !bytes.Equal(*output.LockingScript, row.LockingScript) {
						return fmt.Errorf("stored output differs from transaction")
					}
					point := fmt.Sprintf("%s.%d", *row.TxID, row.Vout)
					if seenOutpoint[point] {
						return fmt.Errorf("duplicate owned outpoint")
					}
					seenOutpoint[point] = true
					rawHex := hex.EncodeToString(row.RawTx)
					value.Outpoint = &point
					value.TxID = row.TxID
					value.RawTx = &rawHex
				}
				type tagRow struct {
					TagName   string
					TagUserID int
					Owner     *int
				}
				tags := []tagRow{}
				if err := tx.Table(names("OutputTag")+" AS ot").Select("ot.tag_name,ot.tag_user_id,g.user_id AS owner").
					Joins("LEFT JOIN "+names("Tag")+" AS g ON g.name=ot.tag_name AND g.user_id=ot.tag_user_id AND g.deleted_at IS NULL").
					Where("ot.output_id = ? AND ot.deleted_at IS NULL", row.ID).Order("ot.tag_name ASC").Limit(257).Scan(&tags).Error; err != nil {
					return err
				}
				if len(tags) > 256 {
					return fmt.Errorf("tag budget exceeded")
				}
				seenTags := map[string]bool{}
				for _, tag := range tags {
					if tag.TagUserID != owners[0] || tag.Owner == nil || *tag.Owner != owners[0] || !utf8.ValidString(tag.TagName) || len(tag.TagName) > 4096 || seenTags[tag.TagName] {
						return fmt.Errorf("invalid output tag ownership")
					}
					seenTags[tag.TagName] = true
					value.Tags = append(value.Tags, tag.TagName)
					totalBytes += len(tag.TagName)
				}
				sort.Strings(value.Tags)
				totalBytes += len(row.RawTx)*2 + len(value.LockingScript)
				for _, v := range []*string{row.BasketName, row.CustomInstructions} {
					if v != nil {
						totalBytes += len(*v)
					}
				}
				if totalBytes > 64*1024*1024 {
					return fmt.Errorf("snapshot byte budget exceeded")
				}
				result.Outputs = append(result.Outputs, value)
			}
			return nil
		}, &sql.TxOptions{ReadOnly: true})
		if err != nil {
			http.Error(w, "native output snapshot failed validation", 500)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(result)
	})
}
