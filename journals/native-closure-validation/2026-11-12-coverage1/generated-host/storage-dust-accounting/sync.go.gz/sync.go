package main

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/bsv-blockchain/go-overlay-services/pkg/core/engine"
)

// The privileged fixture plane admits only bounded loopback GASP peers for the
// laboratory topic. The engine and both GASP implementations remain unchanged.
func controlledOverlaySync(eng *engine.Engine, token string) http.HandlerFunc {
	var mu sync.Mutex
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer "+token {
			http.Error(w, "unauthorized", 401)
			return
		}
		var input struct {
			Peer string `json:"peer"`
		}
		decoder := json.NewDecoder(http.MaxBytesReader(w, r.Body, 2048))
		decoder.DisallowUnknownFields()
		if err := decoder.Decode(&input); err != nil || decoder.Decode(new(any)) != io.EOF || loopbackURL(input.Peer) != nil || strings.HasSuffix(input.Peer, "/") {
			http.Error(w, "invalid loopback GASP peer", 400)
			return
		}
		mu.Lock()
		defer mu.Unlock()
		ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
		defer cancel()
		eng.SyncConfiguration = map[string]engine.SyncConfiguration{"tm_tpnil": {Type: engine.SyncConfigurationPeers, Peers: []string{input.Peer}, Concurrency: 1}}
		defer func() { eng.SyncConfiguration = map[string]engine.SyncConfiguration{} }()
		if err := eng.StartGASPSync(ctx); err != nil {
			http.Error(w, "GASP synchronization failed: "+err.Error(), 502)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	}
}

// Go's generated GASP response writes absent optional maps as JSON null and
// absent proof/metadata as empty strings. TypeScript GASP requires omission.
// Preserve every populated field while omitting semantically absent fields.
func canonicalGASPNode(body []byte) ([]byte, error) {
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(body, &fields); err != nil {
		return nil, err
	}
	changed := false
	for _, name := range []string{"inputs", "proof", "txMetadata", "outputMetadata"} {
		if value, present := fields[name]; present && (strings.TrimSpace(string(value)) == "null" || (name != "inputs" && strings.TrimSpace(string(value)) == `""`)) {
			delete(fields, name)
			changed = true
		}
	}
	if !changed {
		return body, nil
	}
	return json.Marshal(fields)
}
