// ITCVE controlled-service host. All keys and data belong to disposable lab runs.
package main

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"log/slog"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"runtime/debug"
	"strings"
	"syscall"
	"time"

	"github.com/bsv-blockchain/go-chaintracks/chainmanager"
	"github.com/bsv-blockchain/go-chaintracks/chaintracks"
	ctroutes "github.com/bsv-blockchain/go-chaintracks/routes/fiber"
	"github.com/bsv-blockchain/go-overlay-services/pkg/core/engine"
	overlayhttp "github.com/bsv-blockchain/go-overlay-services/pkg/server"
	"github.com/bsv-blockchain/go-overlay-services/pkg/storage/mongodb"
	"github.com/bsv-blockchain/go-sdk/block"
	"github.com/bsv-blockchain/go-sdk/chainhash"
	"github.com/bsv-blockchain/go-sdk/overlay"
	"github.com/bsv-blockchain/go-sdk/overlay/lookup"
	"github.com/bsv-blockchain/go-sdk/spv"
	"github.com/bsv-blockchain/go-sdk/transaction"
	"github.com/bsv-blockchain/go-sdk/transaction/template/pushdrop"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/defs"
	servercommon "github.com/bsv-blockchain/go-wallet-toolbox/pkg/server"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/services"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/storage"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wallet"
	"github.com/bsv-blockchain/go-wallet-toolbox/pkg/wdk"
	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// The library's HTTP(S) origin validator excludes Chromium extension origins.
// Admit well-formed native extension origins at this loopback fixture boundary,
// retaining the library's protocol header list and authenticated RPC handler.
// Ordinary HTTP(S) origins continue through the unmodified library middleware.
func storageBrowserHandler(next http.Handler) http.Handler {
	config := storage.DefaultCORSConfig()
	ordinary := servercommon.NewCORSMiddleware(next, config)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")
		if !strings.HasPrefix(origin, "chrome-extension:") {
			ordinary.ServeHTTP(w, r)
			return
		}
		id := strings.TrimPrefix(origin, "chrome-extension://")
		valid := len(id) == 32 && origin == "chrome-extension://"+id
		for _, c := range id {
			if c < 'a' || c > 'p' {
				valid = false
			}
		}
		if !valid {
			http.Error(w, "CORS origin denied", http.StatusForbidden)
			return
		}
		header := w.Header()
		for _, name := range []string{"Origin", "Access-Control-Request-Method", "Access-Control-Request-Headers"} {
			header.Add("Vary", name)
		}
		header.Set("Access-Control-Allow-Origin", origin)
		header.Set("Access-Control-Allow-Methods", strings.Join(config.AllowedMethods, ", "))
		header.Set("Access-Control-Allow-Headers", strings.Join(config.AllowedHeaders, ", "))
		header.Set("Access-Control-Expose-Headers", strings.Join(config.ExposedHeaders, ", "))
		if strings.EqualFold(r.Header.Get("Access-Control-Request-Private-Network"), "true") {
			header.Set("Access-Control-Allow-Private-Network", "true")
		}
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}

const genesis = "000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f"

// Only loopback HTTP is available to service dependencies. Public providers,
// proxies, redirects and P2P/bootstrap discovery are absent from this host.
func loopbackURL(raw string) error {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "http" || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return errors.New("expected loopback HTTP URL")
	}
	ip := net.ParseIP(u.Hostname())
	if ip == nil || !ip.IsLoopback() {
		return errors.New("expected literal loopback address")
	}
	return nil
}
func restrictedClient() *http.Client {
	transport := &http.Transport{DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
		host, _, err := net.SplitHostPort(address)
		ip := net.ParseIP(host)
		if err != nil || ip == nil || !ip.IsLoopback() {
			return nil, errors.New("ITCVE denied non-loopback egress")
		}
		return (&net.Dialer{Timeout: 5 * time.Second}).DialContext(ctx, network, address)
	}}
	return &http.Client{Transport: transport, Timeout: 15 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return errors.New("ITCVE denied redirect") }}
}

type fixtureServices struct {
	origin                    string
	client                    *http.Client
	terminalRejectionReceipts bool
}

func (s *fixtureServices) call(ctx context.Context, route string, result any) error {
	req, err := http.NewRequestWithContext(ctx, "GET", s.origin+route, nil)
	if err != nil {
		return err
	}
	res, err := s.client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return fmt.Errorf("controlled service HTTP %d", res.StatusCode)
	}
	return json.NewDecoder(io.LimitReader(res.Body, 4<<20)).Decode(result)
}
func (s *fixtureServices) CurrentHeight(ctx context.Context) (uint32, error) {
	var v struct {
		Height uint32 `json:"height"`
	}
	err := s.call(ctx, "/chaintracks/v2/height", &v)
	return v.Height, err
}
func (s *fixtureServices) IsValidRootForHeight(ctx context.Context, root *chainhash.Hash, height uint32) (bool, error) {
	var h struct {
		MerkleRoot string `json:"merkleRoot"`
	}
	err := s.call(ctx, fmt.Sprintf("/chaintracks/v2/header/height/%d", height), &h)
	if err != nil {
		return false, err
	}
	return root != nil && h.MerkleRoot == root.String(), nil
}
func (s *fixtureServices) ChainHeaderByHeight(ctx context.Context, height uint32) (*wdk.ChainBlockHeader, error) {
	var header wdk.ChainBlockHeader
	err := s.call(ctx, fmt.Sprintf("/chaintracks/v2/header/height/%d", height), &header)
	return &header, err
}
func (s *fixtureServices) FindChainTipHeader(ctx context.Context) (*wdk.ChainBlockHeader, error) {
	var header wdk.ChainBlockHeader
	err := s.call(ctx, "/chaintracks/v2/tip", &header)
	return &header, err
}

// Sparse ITCVE fixtures are persisted separately from ChainTracks' contiguous
// native checkpoint format. Recovery replays the exact accepted fixture bytes.
type fixtureHeader struct {
	Hex    string `json:"hex"`
	Height uint32 `json:"height"`
	Hash   string `json:"hash"`
}

func decodeHeaders(inputs []fixtureHeader) ([]*chaintracks.BlockHeader, error) {
	if len(inputs) == 0 || len(inputs) > 10000 {
		return nil, errors.New("invalid fixture count")
	}
	headers := make([]*chaintracks.BlockHeader, 0, len(inputs))
	seen := map[uint32]bool{}
	for i, input := range inputs {
		h, err := block.NewHeaderFromHex(input.Hex)
		if err != nil || input.Height > 10000000 || h.Hash().String() != input.Hash || seen[input.Height] || (i > 0 && inputs[i-1].Height >= input.Height) {
			return nil, errors.New("invalid fixture header identity/order")
		}
		seen[input.Height] = true
		headers = append(headers, &chaintracks.BlockHeader{Header: h, Height: input.Height, Hash: h.Hash(), ChainWork: chainmanager.CalculateWork(h.Bits)})
	}
	return headers, nil
}
func persistHeaders(file string, inputs []fixtureHeader) error {
	bytes, err := json.Marshal(inputs)
	if err != nil {
		return err
	}
	temp, err := os.CreateTemp(filepath.Dir(file), "headers-*.tmp")
	if err != nil {
		return err
	}
	defer os.Remove(temp.Name())
	if _, err = temp.Write(bytes); err != nil {
		temp.Close()
		return err
	}
	if err = temp.Sync(); err != nil {
		temp.Close()
		return err
	}
	if err = temp.Close(); err != nil {
		return err
	}
	return os.Rename(temp.Name(), file)
}

func (s *fixtureServices) PostTX(ctx context.Context, raw []byte) (*wdk.PostedTxID, error) {
	req, err := http.NewRequestWithContext(ctx, "POST", s.origin+"/tpnil/submit", strings.NewReader(hex.EncodeToString(raw)))
	if err != nil {
		return nil, err
	}
	res, err := s.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	// Historical profiles retain their original status-only fixture adapter.
	// Terminal receipt semantics are admitted only by the prospective profile.
	if !s.terminalRejectionReceipts && res.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("controlled submission HTTP %d", res.StatusCode)
	}
	tx, err := transaction.NewTransactionFromBytes(raw)
	if err != nil {
		return nil, err
	}
	if !s.terminalRejectionReceipts {
		return &wdk.PostedTxID{Result: wdk.PostedTxIDResultSuccess, TxID: tx.TxID().String()}, nil
	}
	var receipt struct {
		TxID    string `json:"txid"`
		Verdict string `json:"verdict"`
	}
	decoder := json.NewDecoder(io.LimitReader(res.Body, 4096))
	if err = decoder.Decode(&receipt); err != nil {
		return nil, fmt.Errorf("invalid controlled submission receipt: %w", err)
	}
	if err = decoder.Decode(new(any)); err != io.EOF || receipt.TxID != tx.TxID().String() {
		return nil, errors.New("controlled submission receipt is not bound to the submitted transaction")
	}
	switch {
	case res.StatusCode == http.StatusOK && receipt.Verdict == "ACCEPTED_BY_NETWORK":
		return &wdk.PostedTxID{Result: wdk.PostedTxIDResultSuccess, TxID: receipt.TxID}, nil
	case res.StatusCode == http.StatusBadRequest && receipt.Verdict == "REJECTED":
		// A transaction rejection is a completed service response. Returning a Go
		// error here would turn the terminal verdict into a retryable service error.
		return &wdk.PostedTxID{Result: wdk.PostedTxIDResultError, TxID: receipt.TxID}, nil
	default:
		return nil, fmt.Errorf("unrecognized controlled submission response: HTTP %d verdict %q", res.StatusCode, receipt.Verdict)
	}
}

func main() {
	if err := run(); err != nil {
		log.Print(err)
		os.Exit(1)
	}
}
func run() error {
	state := flag.String("state", "", "isolated state directory")
	fixtureURL := flag.String("fixtures", "", "loopback controlled-service origin")
	mongoURI := flag.String("mongo", "", "disposable loopback Mongo replica-set URI")
	database := flag.String("database", "", "unique overlay database")
	token := flag.String("control-token", "", "per-run control authority")
	rootKey := flag.String("root-key", strings.Repeat("11", 32), "synthetic storage identity")
	useOverlay := flag.Bool("overlay", false, "enable Go Overlay Services")
	useStorage := flag.Bool("storage", false, "enable Go Wallet Storage")
	terminalRejectionReceipts := flag.Bool("terminal-rejection-receipts", false, "ITCVE-1.4 transaction-bound terminal submission receipts")
	flag.Parse()
	if *state == "" || len(*token) < 32 {
		return errors.New("state and random control token are required")
	}
	if err := loopbackURL(*fixtureURL); err != nil {
		return err
	}
	if err := os.MkdirAll(*state, 0700); err != nil {
		return err
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	http.DefaultTransport = restrictedClient().Transport
	http.DefaultClient = restrictedClient()
	logger := slog.New(slog.NewTextHandler(os.Stderr, &slog.HandlerOptions{Level: slog.LevelWarn}))
	runtimeHeaders, err := os.MkdirTemp(*state, "chaintracks-runtime-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(runtimeHeaders)
	cm, err := chainmanager.NewForTesting(ctx, "main", runtimeHeaders)
	if err != nil {
		return err
	}
	snapshotFile := filepath.Join(*state, "fixture-headers.json")
	if bytes, readErr := os.ReadFile(snapshotFile); readErr == nil {
		var inputs []fixtureHeader
		if err = json.Unmarshal(bytes, &inputs); err != nil {
			return err
		}
		headers, err := decodeHeaders(inputs)
		if err != nil {
			return err
		}
		if err = cm.SetChainTip(ctx, headers); err != nil {
			return err
		}
	} else if !errors.Is(readErr, os.ErrNotExist) {
		return readErr
	}
	// NewForTesting disables P2P while retaining the real manager, disk format,
	// routes and subscriptions. Header admission is the privileged fixture plane.
	app := fiber.New(fiber.Config{DisableStartupMessage: true, ErrorHandler: overlayhttp.GetErrorHandler(), BodyLimit: 4 << 20})
	app.Use(func(c *fiber.Ctx) error { c.SetUserContext(ctx); return c.Next() })
	routes := ctroutes.NewRoutes(ctx, cm)
	routes.Register(app.Group("/chaintracks/v2"))
	routes.RegisterLegacy(app)
	fixtures := &fixtureServices{origin: *fixtureURL, client: restrictedClient(), terminalRejectionReceipts: *terminalRejectionReceipts}
	mux := http.NewServeMux()
	var destroyOverlay func(context.Context) error
	if *useStorage {
		svc := services.New(logger, defs.WalletServices{Chain: defs.NetworkMainnet}, services.WithHttpClient(fixtures.client), services.WithCustomImplementation("tpnil-controlled", services.ToImplementation(fixtures)))
		db := defs.DefaultDBConfig()
		db.SQLite.ConnectionString = filepath.Join(*state, "wallet.sqlite")
		provider, err := storage.NewGORMProvider(defs.NetworkMainnet, svc, storage.WithLogger(logger), storage.WithDBConfig(db), storage.WithBackgroundBroadcasterContext(ctx))
		if err != nil {
			return err
		}
		defer provider.Stop(context.Background())
		identity, err := wdk.IdentityKey(*rootKey)
		if err != nil {
			return err
		}
		if _, err = provider.Migrate(ctx, "tpnil-go-storage", identity); err != nil {
			return err
		}
		authWallet, err := wallet.New(defs.NetworkMainnet, *rootKey, provider, wallet.WithServices(svc), wallet.WithLogger(logger))
		if err != nil {
			return err
		}
		mux.HandleFunc("GET /control/transactions", func(w http.ResponseWriter, r *http.Request) {
			if r.Header.Get("Authorization") != "Bearer "+*token {
				http.Error(w, "unauthorized", 401)
				return
			}
			var rows []struct {
				TxID  string
				RawTx []byte
			}
			db := provider.Database.DB
			table := db.NamingStrategy.TableName("KnownTx")
			if err := db.WithContext(r.Context()).Table(table).Select("tx_id, raw_tx").Where("raw_tx IS NOT NULL").Order("tx_id").Limit(2049).Scan(&rows).Error; err != nil {
				http.Error(w, "transaction snapshot failed", 500)
				return
			}
			if len(rows) > 2048 {
				http.Error(w, "transaction snapshot budget exceeded", 500)
				return
			}
			result := []map[string]string{}
			for _, row := range rows {
				if len(row.RawTx) > 0 {
					result = append(result, map[string]string{"txid": row.TxID, "rawTxHex": hex.EncodeToString(row.RawTx)})
				}
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(result)
		})
		mux.Handle("GET /control/action-references", actionReferencesHandler(provider.Database.DB, *token))
		mux.Handle("GET /control/v2/native-output-snapshot", nativeOutputSnapshotHandler(provider.Database.DB, *token))
		rpc := storage.NewServer(logger, provider, authWallet, storage.ServerOptions{Monetize: false, DisableCORS: true})
		mux.Handle("/storage/", http.StripPrefix("/storage", storageBrowserHandler(rpc.Handler())))
	}
	if *useOverlay {
		// The production Mongo adapter enforces replica-set topology and majority
		// journaled writes. Each run owns a separate database and never shares writers.
		u, err := url.Parse(*mongoURI)
		if err != nil || u.Scheme != "mongodb" || u.User != nil {
			return errors.New("disposable loopback Mongo URI required")
		}
		for _, host := range strings.Split(u.Host, ",") {
			h, _, e := net.SplitHostPort(host)
			ip := net.ParseIP(h)
			if e != nil || ip == nil || !ip.IsLoopback() {
				return errors.New("Mongo must use literal loopback addresses")
			}
		}
		if len(*database) != 30 || !strings.HasPrefix(*database, "tpnil_") {
			return errors.New("unique disposable overlay database required")
		}
		client, err := mongo.Connect(options.Client().ApplyURI(*mongoURI))
		if err != nil {
			return err
		}
		defer client.Disconnect(context.Background())
		store, err := mongodb.New(ctx, client, mongodb.Config{Database: *database, Scope: engine.StorageScope{Network: "main", GenesisHash: genesis, NodeID: *database}})
		if err != nil {
			return err
		}
		defer store.Close(context.Background())
		destroyOverlay = client.Database(*database).Drop
		eng := engine.NewEngine(&engine.Config{Storage: store, ChainTracker: fixtures, SHIPTrackers: []string{}, SLAPTrackers: []string{}, SyncConfiguration: map[string]engine.SyncConfiguration{}})
		for _, topic := range []string{"tm_users", "tm_tpnil"} {
			eng.RegisterTopicManager(topic, &topicManager{topic: topic, store: store})
			name := "ls_users"
			if topic == "tm_tpnil" {
				name = "ls_tpnil"
			}
			eng.RegisterLookupService(name, &lookupService{topic: topic, store: store, tracker: fixtures})
		}
		cfg := overlayhttp.DefaultRegisterRoutesConfig
		cfg.Engine = eng
		cfg.BaseURL = "/overlay"
		cfg.AdminBearerToken = *token
		cfg.ARCCallbackToken = *token
		cfg.OctetStreamLimit = 4 << 20
		app.Use("/overlay/submit", func(c *fiber.Ctx) error {
			if c.Method() == http.MethodPost {
				_, tx, _, err := transaction.ParseBeef(c.Body())
				if err != nil || tx == nil {
					return fiber.NewError(http.StatusBadRequest, "invalid BEEF submission")
				}
			}
			return c.Next()
		})
		app.Use("/overlay/requestForeignGASPNode", func(c *fiber.Ctx) error {
			if err := c.Next(); err != nil {
				return err
			}
			if c.Method() == http.MethodPost && c.Response().StatusCode() == http.StatusOK {
				normalized, err := canonicalGASPNode(c.Response().Body())
				if err != nil {
					return err
				}
				c.Response().SetBody(normalized)
			}
			return nil
		})
		overlayhttp.RegisterRoutes(app, &cfg)
		mux.HandleFunc("POST /control/sync", controlledOverlaySync(eng, *token))
	}
	mux.HandleFunc("POST /control/destroy", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer "+*token {
			http.Error(w, "unauthorized", 401)
			return
		}
		if destroyOverlay != nil {
			if err := destroyOverlay(r.Context()); err != nil {
				http.Error(w, "overlay cleanup failed", 500)
				return
			}
		}
		w.WriteHeader(204)
	})
	fiberListener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return err
	}
	defer app.ShutdownWithTimeout(2 * time.Second)
	go func() {
		if err := app.Listener(fiberListener); err != nil {
			log.Print(err)
			cancel()
		}
	}()
	fiberURL, _ := url.Parse("http://" + fiberListener.Addr().String())
	proxy := httputil.NewSingleHostReverseProxy(fiberURL)
	proxy.Transport = restrictedClient().Transport
	proxy.FlushInterval = -1
	mux.Handle("/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/stream") {
			_ = http.NewResponseController(w).SetWriteDeadline(time.Time{})
		}
		proxy.ServeHTTP(w, r)
	}))
	mux.HandleFunc("POST /control/headers", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer "+*token {
			http.Error(w, "unauthorized", 401)
			return
		}
		var inputs []fixtureHeader
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<20)).Decode(&inputs); err != nil {
			http.Error(w, "invalid headers", 400)
			return
		}
		headers, err := decodeHeaders(inputs)
		if err != nil {
			http.Error(w, "invalid headers", 400)
			return
		}

		var ancestor *chaintracks.BlockHeader
		orphaned := []chainhash.Hash{}
		for _, header := range headers {
			old, err := cm.GetHeaderByHeight(r.Context(), header.Height)
			if err != nil {
				continue
			}
			if old.Hash == header.Hash {
				ancestor = old
			} else {
				orphaned = append(orphaned, old.Hash)
			}
		}
		if len(orphaned) > 0 && ancestor != nil {
			err = cm.SetChainTipWithReorg(r.Context(), headers, ancestor, orphaned)
		} else {
			err = cm.SetChainTip(r.Context(), headers)
		}
		if err != nil {
			http.Error(w, "header persistence failed", 500)
			return
		}
		if err = persistHeaders(snapshotFile, inputs); err != nil {
			http.Error(w, "fixture snapshot persistence failed", 500)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		io.WriteString(w, "{\"ok\":true}")
	})
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return err
	}
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 30 * time.Second, IdleTimeout: 30 * time.Second}
	go func() {
		<-ctx.Done()
		shutdown, done := context.WithTimeout(context.Background(), 5*time.Second)
		defer done()
		server.Shutdown(shutdown)
	}()
	info, ok := debug.ReadBuildInfo()
	if !ok {
		return errors.New("Go build information unavailable")
	}
	dependencies := map[string]map[string]string{}
	for _, dep := range info.Deps {
		entry := map[string]string{"version": dep.Version, "sum": dep.Sum}
		if dep.Replace != nil {
			entry["replacementModule"] = dep.Replace.Path
			entry["replacementVersion"] = dep.Replace.Version
			entry["replacementSum"] = dep.Replace.Sum
		}
		dependencies[dep.Path] = entry
	}
	json.NewEncoder(os.Stdout).Encode(map[string]any{"toolchain": info.GoVersion, "dependencies": dependencies, "schema": "tpnil-go-services@1.0.0", "origin": "http://" + listener.Addr().String(), "overlay": *useOverlay, "storage": *useStorage})
	err = server.Serve(listener)
	if errors.Is(err, http.ErrServerClosed) {
		return nil
	}
	return err
}

// tm_tpnil admits nonempty PushDrop payloads for the lab's independent protocol
// probes. tm_users retains the UMP predicates used by the controlled TS fixture.
// The real engine validates scripts/SPV before either application admission rule.
type topicManager struct {
	topic string
	store *mongodb.Store
}

func (t *topicManager) GetDocumentation() string {
	return "ITCVE controlled PushDrop/UMP application profile 1.0.0"
}
func (t *topicManager) GetMetaData() *overlay.MetaData { return &overlay.MetaData{Name: t.topic} }
func (t *topicManager) IdentifyNeededInputs(context.Context, *transaction.Beef, *chainhash.Hash) ([]*transaction.Outpoint, error) {
	return nil, nil
}
func (t *topicManager) IdentifyAdmissibleOutputs(ctx context.Context, b *transaction.Beef, id *chainhash.Hash, previous []uint32) (overlay.AdmittanceInstructions, error) {
	result := overlay.AdmittanceInstructions{OutputsToAdmit: []uint32{}, CoinsToRetain: []uint32{}, CoinsRemoved: previous}
	tx := b.FindAtomicTransactionByHash(id)
	if tx == nil {
		return result, errors.New("transaction absent")
	}
	for i, out := range tx.Outputs {
		pd := pushdrop.Decode(out.LockingScript)
		if pd == nil || len(pd.Fields) == 0 {
			continue
		}
		if t.topic == "tm_users" {
			if !validUMP(pd.Fields) {
				continue
			}
			existing, err := t.store.FindUTXOsForTopic(ctx, t.topic, 0, 1001, true)
			if err != nil {
				return result, err
			}
			if len(existing) >= 1000 {
				return result, errors.New("controlled UMP live-output budget exhausted")
			}
			duplicate := false
			for _, o := range existing {
				other := o.Beef.FindAtomicTransactionByHash(&o.Outpoint.Txid)
				if other == nil {
					continue
				}
				fields := pushdrop.Decode(other.Outputs[o.Outpoint.Index].LockingScript)
				if fields != nil && len(fields.Fields) > 7 && (hex.EncodeToString(fields.Fields[6]) == hex.EncodeToString(pd.Fields[6]) || hex.EncodeToString(fields.Fields[7]) == hex.EncodeToString(pd.Fields[7])) {
					duplicate = true
					break
				}
			}
			if duplicate {
				continue
			}
		}
		result.OutputsToAdmit = append(result.OutputsToAdmit, uint32(i))
	}
	return result, nil
}
func validUMP(f [][]byte) bool {
	if len(f) < 11 || len(f[6]) != 32 || len(f[7]) != 32 {
		return false
	}
	i := -1
	if len(f) >= 12 && len(f[11]) == 1 {
		i = 11
	} else if len(f) >= 13 && len(f[12]) == 1 {
		i = 12
	}
	if i < 0 {
		return true
	}
	if f[i][0] != 3 || len(f) <= i+2 {
		return false
	}
	algorithm := string(f[i+1])
	if algorithm != "argon2id" && algorithm != "pbkdf2-sha512" {
		return false
	}
	var params struct {
		Iterations float64 `json:"iterations"`
	}
	return json.Unmarshal(f[i+2], &params) == nil && params.Iterations > 0
}

type lookupService struct {
	topic   string
	store   *mongodb.Store
	tracker *fixtureServices
}

func (l *lookupService) GetDocumentation() string       { return "ITCVE controlled lookup profile 1.0.0" }
func (l *lookupService) GetMetaData() *overlay.MetaData { return &overlay.MetaData{Name: l.topic} }
func (l *lookupService) OutputAdmittedByTopic(context.Context, *engine.OutputAdmittedByTopic) error {
	return nil
}
func (l *lookupService) OutputSpent(context.Context, *engine.OutputSpent) error { return nil }
func (l *lookupService) OutputNoLongerRetainedInHistory(context.Context, *transaction.Outpoint, string) error {
	return nil
}
func (l *lookupService) OutputEvicted(context.Context, *transaction.Outpoint) error { return nil }
func (l *lookupService) OutputBlockHeightUpdated(context.Context, *chainhash.Hash, uint32, uint64) error {
	return nil
}
func (l *lookupService) Lookup(ctx context.Context, q *lookup.LookupQuestion) (*lookup.LookupAnswer, error) {
	var query struct {
		PresentationHash string `json:"presentationHash"`
		RecoveryHash     string `json:"recoveryHash"`
		Outpoint         string `json:"outpoint"`
	}
	if err := json.Unmarshal(q.Query, &query); err != nil {
		return nil, err
	}
	outputs, err := l.store.FindUTXOsForTopic(ctx, l.topic, 0, 1001, true)
	if err != nil {
		return nil, err
	}
	if len(outputs) > 1000 {
		return nil, errors.New("controlled lookup live-output budget exhausted")
	}
	answer := &lookup.LookupAnswer{Type: lookup.AnswerTypeFormula, Formulas: []lookup.LookupFormula{}}
	for _, o := range outputs {
		tx := o.Beef.FindAtomicTransactionByHash(&o.Outpoint.Txid)
		if tx == nil {
			return nil, errors.New("stored transaction absent")
		}
		valid, err := spv.Verify(ctx, tx, l.tracker, nil)
		if errors.Is(err, spv.ErrInvalidMerklePath) {
			continue
		}
		if err != nil {
			return nil, err
		}
		if !valid {
			continue
		}
		if l.topic == "tm_users" {
			tx := o.Beef.FindAtomicTransactionByHash(&o.Outpoint.Txid)
			if tx == nil {
				continue
			}
			p := pushdrop.Decode(tx.Outputs[o.Outpoint.Index].LockingScript)
			if p == nil || len(p.Fields) < 8 {
				continue
			}
			if !(query.PresentationHash != "" && strings.EqualFold(query.PresentationHash, hex.EncodeToString(p.Fields[6]))) && !(query.RecoveryHash != "" && strings.EqualFold(query.RecoveryHash, hex.EncodeToString(p.Fields[7]))) && query.Outpoint != fmt.Sprintf("%s.%d", o.Outpoint.Txid.String(), o.Outpoint.Index) {
				continue
			}
		}
		point := o.Outpoint
		answer.Formulas = append(answer.Formulas, lookup.LookupFormula{Outpoint: &point})
	}
	return answer, nil
}
