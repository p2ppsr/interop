import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {nativeRustBinding, nativeCandidateCoverage3CompatibilityPath, nativeCompletionCompatibilitySources} from '../scripts/native-rust-compatibility.mjs'
import {nativeCandidateCoverage3PlanPath, nativeCandidateCoverage3OriginalPlanPath, selectNativeWalletProfile} from '../scripts/native-wallet-profiles.mjs'

const root=path.resolve(import.meta.dirname,'..'),read=name=>fs.readFileSync(path.join(root,name)),sha=bytes=>createHash('sha256').update(bytes).digest('hex')
const source='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7'
const plan=JSON.parse(read(nativeCandidateCoverage3PlanPath))
const original=JSON.parse(read(nativeCandidateCoverage3OriginalPlanPath))
const graphManifest='components/rust/graph-oracle-3.0.0.json',graph=JSON.parse(read(graphManifest))
const graphPolicy=()=>({corpus:'tpnil-rust-corpus@3',graphOracle:{id:graph.schema,manifest:graphManifest,manifestSha256:sha(read(graphManifest)),operation:graph.operation,cargoFeature:graph.cargoFeature}})

test('source2 preserves the exact executed plan, Rust manifest, profile, catalog and source7 evaluator',()=>{
  for(const name of [nativeCandidateCoverage3OriginalPlanPath,'infra/native/conformance/rust-graph-pr368-coverage-3.json','infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-7.json','itcves/ITCVE-1/4.5.0/profile.json','programs/ISI-4/5.5.0/catalog.json']) assert.deepEqual(read(name),execFileSync('git',['show',`${source}:${name}`],{cwd:root,maxBuffer:16*1024*1024}))
  const reevaluation=JSON.parse(read('infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-7.json'))
  for(const [name,digest] of Object.entries(reevaluation.evaluatorSources)) assert.equal(sha(read(name)),digest)
  assert.equal(plan.itcve,'ITCVE-1@4.5.0');assert.equal(plan.expectedObservations,698)
  assert.equal(plan.sourceBindingRevision,2)
  assert.deepEqual(plan.sourcePredecessor,{path:nativeCandidateCoverage3OriginalPlanPath,sha256:sha(read(nativeCandidateCoverage3OriginalPlanPath))})
  assert.equal(Object.keys(plan.conformanceInputs).length,Object.keys(original.conformanceInputs).length+3)
  for(const [name,digest] of Object.entries(plan.conformanceInputs)) assert.equal(sha(read(name)),digest,name)
})

test('host, worker, parent and Docker all select the explicit same-criteria successor closure',()=>{
  assert.equal(selectNativeWalletProfile('--conformance-pr368-coverage-3').planPath,nativeCandidateCoverage3PlanPath)
  assert.ok(nativeCandidateCoverage3PlanPath.endsWith('coverage-3-source-2.json'))
  for(const name of ['synthesis/src/wallet-lab/native/worker.ts','synthesis/src/wallet-lab/native/verify.ts','scripts/verify-native-integrated.mjs']) assert.ok(read(name).toString().includes(nativeCandidateCoverage3PlanPath),name)
  assert.ok(read('infra/native/conformance/Dockerfile').toString().includes('scripts/read-committed-blob.mjs /work/scripts/'))
  const rust=JSON.parse(read(nativeCandidateCoverage3CompatibilityPath))
  assert.equal(rust.sourceBindingRevision,7)
  assert.deepEqual(Object.keys(rust.sources).sort(),[...nativeCompletionCompatibilitySources].sort())
  assert.deepEqual(rust.predecessor,{manifest:'infra/native/conformance/rust-graph-pr368-coverage-3.json',sha256:sha(read('infra/native/conformance/rust-graph-pr368-coverage-3.json'))})
})

// Synthetic readCommitted is explicit here: these tests exercise admission
// predicates, and do not claim that uncommitted source is admitted for execution.
test('Rust source-only successor predicates admit the complete fixture and reject criterion changes',async()=>{
  const options={read,readCommitted:(_revision,name)=>read(name),graphPolicy}
  const result=await nativeRustBinding(plan,sha(read(nativeCandidateCoverage3PlanPath)),source,options)
  assert.equal(result.manifest,nativeCandidateCoverage3CompatibilityPath)
  for(const mutate of [p=>p.wallet.version='unbound',p=>p.expectedObservations--,p=>p.maxSecondsPerRepetition++,p=>p.completionModules.baskets.assertions--,p=>delete p.permissionFixture]) {
    const changed=structuredClone(plan);mutate(changed)
    await assert.rejects(nativeRustBinding(changed,sha(read(nativeCandidateCoverage3PlanPath)),source,options),/preserve every native criterion|Expected values to be strictly equal/)
  }
})

test('source successor cannot drop a historical input, helper, or predecessor binding',async()=>{
  for(const mutate of [p=>delete p.conformanceInputs['synthesis/test/fixtures/native-pagination/report.json.gz'],p=>delete p.conformanceInputs['scripts/read-committed-blob.mjs'],p=>p.sourcePredecessor.sha256='0'.repeat(64),p=>p.sourceBindingRevision=1]) {
    const changed=structuredClone(plan);mutate(changed)
    await assert.rejects(nativeRustBinding(changed,sha(read(nativeCandidateCoverage3PlanPath)),source,{read,readCommitted:(_revision,name)=>read(name),graphPolicy}))
  }
})
