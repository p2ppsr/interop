from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();source='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7';H=lambda b:hashlib.sha256(b).hexdigest()
old='infra/native/conformance/plan-pr368-coverage-3.json';rustold='infra/native/conformance/rust-graph-pr368-coverage-3.json';new='infra/native/conformance/plan-pr368-coverage-3-source-2.json';rustnew='infra/native/conformance/rust-graph-pr368-coverage-3-source-2.json'
for p in [old,rustold,'infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-7.json','itcves/ITCVE-1/4.5.0/profile.json','programs/ISI-4/5.5.0/catalog.json']:
 assert (r/p).read_bytes()==subprocess.check_output(['git','show',source+':'+p])
p=json.loads((r/old).read_text()); original=json.loads((r/old).read_text()); p['id']+='-SOURCE-2';p['sourceBindingRevision']=2;p['sourcePredecessor']={'path':old,'sha256':H((r/old).read_bytes())}
added=['scripts/read-committed-blob.mjs','test/committed-blob.test.mjs','test/native-selector-source2.test.mjs'];p['conformanceInputs']={n:H((r/n).read_bytes()) for n in sorted(set(original['conformanceInputs'])|set(added))}
(r/new).write_text(json.dumps(p,indent=2)+'\n')
m=json.loads((r/rustold).read_text());m['sourceBindingRevision']=7;m['predecessor']={'manifest':rustold,'sha256':H((r/rustold).read_bytes())};m['nativePlan']['path']=new;m['nativePlan']['sha256']=H((r/new).read_bytes());m['sources']={n:H((r/n).read_bytes()) for n in sorted(set(m['sources'])|{'scripts/read-committed-blob.mjs'})}
(r/rustnew).write_text(json.dumps(m,indent=2)+'\n')
changed=[n for n,s in original['conformanceInputs'].items() if p['conformanceInputs'][n]!=s]
receipt={'schema':'tpnil-native-source-only-successor-freeze@1','originalSource':source,'originalPlan':{'path':old,'sha256':H((r/old).read_bytes())},'plan':{'path':new,'sha256':H((r/new).read_bytes())},'rust':{'path':rustnew,'sha256':H((r/rustnew).read_bytes())},'unchangedCriteria':True,'profile':'ITCVE-1@4.5.0','program':'ISI-4@5.5.0','observations':698,'inputCount':len(p['conformanceInputs']),'addedInputs':added,'changedExistingInputs':changed,'sourceInputs':p['conformanceInputs'],'newNativeSessions':0,'committedSourceAdmission':'PENDING_POSTCOMMIT_ACTUAL_CLI'}
out=r/'out/native-review-43253674251/selector-recovery/source2-freeze.json';out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='sourceInputs'},indent=2))
