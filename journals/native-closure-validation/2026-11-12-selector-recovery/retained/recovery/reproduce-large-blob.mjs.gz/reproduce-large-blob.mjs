import assert from 'node:assert/strict'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
const root=path.resolve(import.meta.dirname,'../../..'),source='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7',file='synthesis/test/fixtures/native-pagination/report.json.gz'
const bytes=execFileSync('git',['show',`${source}:${file}`],{cwd:root,maxBuffer:4*1024*1024})
let caught
try {execFileSync('git',['show',`${source}:${file}`],{cwd:root,stdio:['ignore','pipe','pipe']})}catch(error){caught=error}
assert.equal(caught?.code,'ENOBUFS')
console.log(JSON.stringify({schema:'tpnil-committed-blob-buffer-counterexample@1',source,file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),command:['git','show',`${source}:${file}`],node:process.version,defaultStdoutLimit:1024*1024,observedError:caught.code,underlyingStatus:caught.status,underlyingSignal:caught.signal,retainedOutputBytes:caught.stdout?.length??null,assertion:'Old default-buffer reader rejects exact valid committed blob before native execution',nativeSessions:0}))
