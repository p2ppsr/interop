import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { checkNativeWalletSelector } from '../../../scripts/check-native-wallet-selector.mjs'
import { readCommittedBlob } from '../../../scripts/read-committed-blob.mjs'
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..')
const source='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7'
const reader=(revision,file)=>readCommittedBlob(root,revision,file)
const result=await checkNativeWalletSelector('integrated-native-conformance-pr368-coverage-3',{source,read:file=>reader(source,file),readCommitted:reader})
console.log(JSON.stringify({schema:'tpnil-selector-bounded-reader-engineering-replay@1',...result,scope:'New reader replaying exact committed693 inputs; not admission of uncommitted successor source or native qualification.',readerSha256:createHash('sha256').update(fs.readFileSync(path.join(root,'scripts/read-committed-blob.mjs'))).digest('hex')}))
