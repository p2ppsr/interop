from pathlib import Path
import gzip,hashlib,json,re,subprocess,sys
base=Path(__file__).resolve().parent;repo=base.parents[2];recovery=base.parent/'selector-recovery';gates=Path(sys.argv[1]).resolve();dest=repo/'journals/native-closure-validation/2026-11-12-selector-recovery';assert not dest.exists();sha=lambda b:hashlib.sha256(b).hexdigest()
freeze=json.loads((recovery/'source2-freeze.json').read_bytes());assert freeze['inputCount']==394
results=json.loads((gates/'results.json').read_bytes());assert len(results)==8 and all(r['exitCode']==0 for r in results)
before=json.loads((gates/'before.json').read_bytes());after=json.loads((gates/'after.json').read_bytes());assert before['files']==after['files'];inventory={x['path']:x['sha256']for x in before['files']}
for p,h in freeze['sourceInputs'].items():assert sha((repo/p).read_bytes())==h==inventory[p],p
raw={}
def add(label,p):
 assert label not in raw;raw[label]=p.read_bytes()
for p in sorted(recovery.rglob('*')):
 if p.is_file():add('recovery/'+p.relative_to(recovery).as_posix(),p)
impact=repo/'out/native-closure-20261111/selector-buffer-impact-review'
for p in sorted(impact.rglob('*')):
 if p.is_file():add('independent/'+p.relative_to(impact).as_posix(),p)
for p in sorted((base/'failed-seal-reproduction').rglob('*')):
 if p.is_file():add('failed-seal-v1/'+p.relative_to(base/'failed-seal-reproduction').as_posix(),p)
for p in sorted((base/'source').rglob('*')):
 if p.is_file():add('pre-docker-source/'+p.relative_to(base/'source').as_posix(),p)
for name in ['source-snapshot.json','source-final-snapshot.json','source-final-freeze.json','snapshot.py','build.py','verify-template.py']:
 add('preparation/'+name,base/name)
add('final/source2-freeze.json',recovery/'source2-freeze.json')
changed=freeze['addedInputs']+freeze['changedExistingInputs']
for p in changed+[freeze['plan']['path'],freeze['rust']['path']]:
 assert (base/'source-final'/p).read_bytes()==(repo/p).read_bytes(),p
 add('final/source/'+p,base/'source-final'/p)
additional={}
for p in subprocess.check_output(['git','diff','--name-only','69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7'],cwd=repo,text=True).splitlines():
 if p in freeze['sourceInputs']or p.startswith(('docs/','journals/')):continue
 if not p.endswith(('.mjs','.ts','.py','.json')):continue
 add('final/additional-source/'+p,repo/p);additional[p]=sha((repo/p).read_bytes());assert inventory[p]==additional[p]
 old=subprocess.check_output(['git','show','69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7:'+p],cwd=repo);raw['initial/additional-source/'+p]=old
links=['journals/native-closure-validation/2026-11-12-coverage-completion/validation.json','journals/native-closure-validation/2026-11-12-coverage-completion-review/manifest.json','journals/native-closure-ci/2026-11-12/69386ef/manifest.json','journals/native-closure-ci/2026-11-12/69386ef-review/manifest.json','journals/integrated-native-attempts/2026-11-12/43253674251/attempt.json',freeze['originalPlan']['path'],'infra/native/conformance/rust-graph-pr368-coverage-3.json','infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-7.json','fixtures/artifacts/yours-wallet-pr368-3e8a97f/provenance.json']
linked=[{'path':p,'bytes':(repo/p).stat().st_size,'sha256':sha((repo/p).read_bytes())}for p in links]
proposal=json.loads((base.parent/'selector-recovery-work-order-proposal.json').read_bytes());add('planning/selector-recovery-work-order-proposal.json',base.parent/'selector-recovery-work-order-proposal.json')
finalGates=[]
for r in results:
 label='recovery/'+(gates/r['log']).relative_to(recovery).as_posix();finalGates.append({**r,'log':label,'logSha256':sha(raw[label])})
core=raw[next(x['log']for x in finalGates if x['gate']=='core')].decode();synth=re.sub(r'\x1b\[[0-9;]*m','',raw[next(x['log']for x in finalGates if x['gate']=='synthesis')].decode());cp=int(re.search(r'ℹ pass (\d+)',core).group(1));sp=int(re.search(r'Tests\s+(\d+) passed',synth).group(1));ss=int(re.search(r'Tests\s+\d+ passed\s*\|\s*(\d+) skipped',synth).group(1))
assert 'ℹ fail 0'in core
rows=[];dest.mkdir(parents=True)
for name,b in sorted(raw.items()):
 path='retained/'+name+'.gz';p=dest/path;p.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(b,mtime=0);p.write_bytes(stored);rows.append({'path':path,'originalPath':name,'encoding':'gzip','bytes':len(stored),'sha256':sha(stored),'originalBytes':len(b),'originalSha256':sha(b)})
m={'schema':'tpnil-selector-recovery-validation@1','claim':'LOCAL_ENGINEERING_VALIDATION_ONLY','originalSource':'69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7','nativeQualification':False,'committedSourceAdmission':'PENDING_POSTCOMMIT_ACTUAL_CLI','nativePlan':freeze['plan'],'rust':freeze['rust'],'originalPlan':freeze['originalPlan'],'nativeInputs':freeze['sourceInputs'],'additionalSource':additional,'linkedEvidence':linked,'source7Carry':{'run':43249807970,'source':'69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7','alreadyCountedJobSeconds':135,'newRuns':0,'closure':proposal['source7Closure']},'finalGates':finalGates,'gateInventory':{'before':'recovery/'+(gates/'before.json').relative_to(recovery).as_posix(),'after':'recovery/'+(gates/'after.json').relative_to(recovery).as_posix()},'results':{'corePass':cp,'coreFail':0,'synthesisPass':sp,'synthesisSkip':ss,'pythonPass':5,'focusedPass':27,'observationsPlanned':698,'newNativeSessions':0},'initialFailuresRetained':['Native7 committed selector ENOBUFS withzero artifacts','Initial reader test fixture chmod startup failure','Pre-Docker84missingimageinputs','Initial fullcore error-message regex failure and recordedinventory drift','Initial e10ee archive verifier accepted omission of its generated verifier role under external checking; exact original and counterexample retained'],'limits':['This precommit archive does not claim the successor committedHEAD/default-reader selector has executed; that mandatory receipt is recorded later in the ops order.','Unchanged large source/fixtures are linked to immutable693/d385 evidence instead of copied.','First reader test harness version is retained only where exact source exists; execution logs are preserved and no later-source replay is inferred.','The executed verifier requires an external trusted Git/hash identity. External --archive checking requires the archived verifier bytes to equal the trusted executing verifier; no program can authenticate a malicious replacement of its own executed code.'],'files':rows}
readme='''# Selector recovery engineering validation

Native7 failed before builds because a committed3.18MB Gitblob exceeded the selector child-process output buffer. Its22-second failed workflow, zeroartifact API and absent native sessions remain immutable. This prospective correction uses a bounded file-backed committed-blob reader, exact object identity checks, and a separately source-bound plan/Rust manifest. All698 acceptance predicates and the3e8a97f candidate remain unchanged.

The archive retains initial reader-test and full-core failures, the independent missing-container-COPY counterexample, provisional source versions, and the final source-bound local gates. Final394-input metadata and changedsource bytes are retained; unchanged large inputs resolve through the linked original693/d385 evidence. Source7 is carried from its prior exact successful execution only under its unchanged evaluator/Rust/dependency closure.

This archive precedes the final source commit. It explicitly leaves the actual committedHEAD/default-reader selector gate pending. That complete source-preflight receipt must be recorded in the separately bounded ops order before a push. Local checks do not establish native qualification or convert the failed native7 sample.

Run python3 verify.py --current-source to validate the exact archive, links, final source inventory and local gate evidence. It performs no native execution or CI dispatch. Without --current-source it verifies retained evidence rather than requiring future mutable source files to match this historical revision.
'''
(dest/'README.md').write_text(readme);m['readmeSha256']=sha((dest/'README.md').read_bytes());projection=sha(json.dumps(m,sort_keys=True,separators=(',',':')).encode());code=(base/'verify-template.py').read_text().replace('__MANIFEST_PROJECTION__',projection);(dest/'verify.py').write_text(code);m['generatedFiles']=[{'path':name,'bytes':(dest/name).stat().st_size,'sha256':sha((dest/name).read_bytes())}for name in ['README.md','verify.py']];p=dest/'validation.json';p.write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'archive':str(dest),'manifestSha256':sha(p.read_bytes()),'files':len(rows),'storedBytes':sum(r['bytes']for r in rows),'results':m['results']}))
