from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parent;repo=base.parents[2];rec=base.parent/'selector-recovery';freeze=json.loads((rec/'source2-freeze.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();target=base/'source';assert not target.exists();target.mkdir()
assert freeze['inputCount']==394 and len(freeze['sourceInputs'])==394
for p,h in freeze['sourceInputs'].items():assert sha((repo/p).read_bytes())==h,p
paths=freeze['addedInputs']+freeze['changedExistingInputs']+[freeze['plan']['path'],freeze['rust']['path']];rows=[]
for p in paths:
 b=(repo/p).read_bytes();d=target/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);rows.append({'path':p,'bytes':len(b),'sha256':sha(b)})
(base/'source-snapshot.json').write_text(json.dumps({'schema':'tpnil-selector-recovery-source-snapshot@1','freezeSha256':sha((rec/'source2-freeze.json').read_bytes()),'files':rows,'nativeInputs':394,'unchangedInputsLinkedToOriginal693':384,'newNativeSessions':0,'committedHeadSelector':'PENDING_POSTCOMMIT_ACTUAL_CLI'},indent=2)+'\n');print(json.dumps({'files':len(rows),'bytes':sum(r['bytes']for r in rows)}))
