from pathlib import Path
import json,hashlib,subprocess,shlex,glob,posixpath,zipfile,re
R=Path.cwd();P=R/'out/native-closure-20261111/selector-buffer-impact-review/final';S='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7';sha=lambda b:hashlib.sha256(b).hexdigest();old=lambda n:subprocess.check_output(['git','show',S+':'+n]);read=lambda n:(R/n).read_bytes()
originalPath='infra/native/conformance/plan-pr368-coverage-3.json';planPath='infra/native/conformance/plan-pr368-coverage-3-source-2.json';rustPath='infra/native/conformance/rust-graph-pr368-coverage-3-source-2.json'
original=json.loads(old(originalPath));plan=json.loads(read(planPath));rust=json.loads(read(rustPath))
assert sha(read(planPath))=='fa480bf08b902175ae1e7ce988601a91a2c7fb9aa55c8a1d3433769ea3c22acd';assert sha(read(rustPath))=='b1a14fc12b7867338296a476ae84a9adf268b5da63890fa21e483bfef0a10b22'
unchanged=[originalPath,'infra/native/conformance/rust-graph-pr368-coverage-3.json','infra/native/conformance/reevaluation-42711700295-rust-3.0.0-source-7.json','itcves/ITCVE-1/4.5.0/profile.json','programs/ISI-4/5.5.0/catalog.json']
for n in unchanged:assert read(n)==old(n),n
strip=lambda p:{k:v for k,v in p.items()if k not in['id','conformanceInputs','sourceBindingRevision','sourcePredecessor']}
assert strip(plan)==strip(original);assert plan['sourceBindingRevision']==2;assert plan['id']==original['id']+'-SOURCE-2';assert plan['sourcePredecessor']=={'path':originalPath,'sha256':sha(old(originalPath))}
added=sorted(set(plan['conformanceInputs'])-set(original['conformanceInputs']));assert added==['scripts/read-committed-blob.mjs','test/committed-blob.test.mjs','test/native-selector-source2.test.mjs']
assert len(plan['conformanceInputs'])==394
for n,h in plan['conformanceInputs'].items():assert sha(read(n))==h,n
changed=sorted(n for n,h in original['conformanceInputs'].items()if plan['conformanceInputs'][n]!=h)
assert changed==['infra/native/conformance/Dockerfile','infra/native/yours-go/Dockerfile.dockerignore','scripts/check-native-wallet-selector.mjs','scripts/native-rust-compatibility.mjs','scripts/native-wallet-profiles.mjs','scripts/verify-native-integrated.mjs','synthesis/src/wallet-lab/native/verify.ts','synthesis/src/wallet-lab/native/worker.ts']
assert rust['sourceBindingRevision']==7 and rust['nativePlan']['sha256']==sha(read(planPath)) and rust['nativePlan']['path']==planPath
assert rust['predecessor']=={'manifest':'infra/native/conformance/rust-graph-pr368-coverage-3.json','sha256':sha(old('infra/native/conformance/rust-graph-pr368-coverage-3.json'))}
for n,h in rust['sources'].items():assert sha(read(n))==h
# Independent expansion uses actual filesystem contents, including exact source-to-destination projection.
names=['infra/native/yours-go/Dockerfile','infra/native/integrated/Dockerfile','infra/native/conformance/Dockerfile'];mapped={};assert not(R/'.dockerignore').exists()
def allowed(n,text):
 result=True
 for line in text.splitlines():
  line=line.strip()
  if not line or line.startswith('#'):continue
  yes=line.startswith('!');p=line[1:]if yes else line
  assert p=='**'or re.fullmatch(r'[A-Za-z0-9_./-]+(?:/\*\*)?',p)
  if p=='**'or p==n or(p.endswith('/**')and n.startswith(p[:-2])):result=yes
 return result
for name in names:
 ignore=R/(name+'.dockerignore');ig=ignore.read_text()if ignore.exists()else''
 if name!=names[0]:assert not ignore.exists()
 for line in read(name).decode().splitlines():
  if not line.startswith('COPY '):continue
  args=shlex.split(line[5:])
  if args[0].startswith('--from='):continue
  dest=args[-1];sources=args[:-1]
  if not dest.startswith('/work/'):continue
  for source in sources:
   if '$'in source:continue
   for item in glob.glob(source):
    item=Path(item)
    if item.is_dir():
     for f in item.rglob('*'):
      if f.is_file()and allowed(f.as_posix(),ig):mapped[posixpath.join(dest[6:],f.relative_to(item).as_posix())]=f.as_posix()
    elif item.is_file()and allowed(item.as_posix(),ig):mapped[posixpath.join(dest[6:],item.name)if dest.endswith('/')or len(sources)>1 else dest[6:]]=item.as_posix()
assert all(mapped.get(n)==n for n in plan['conformanceInputs'])
ig=read(names[0]+'.dockerignore').decode();candidatePrefix='out/sut-artifacts/yours-wallet-pr368-3e8a97f/unpacked/'
with zipfile.ZipFile(R/'fixtures/artifacts/yours-wallet-pr368-3e8a97f/pw-v5.1.1.zip')as z:
 candidateFiles=[x.filename for x in z.infolist()if not x.is_dir()];assert len(candidateFiles)==45;assert all(allowed(candidatePrefix+n,ig)for n in candidateFiles)
# Carry forward actual final focused receipts, without relabeling them as a new independent test execution.
base=R/'out/native-review-43253674251/selector-recovery';focused=(base/'focused-tests-final-image-ignore.log').read_bytes();assert b'pass 27'in focused and b'fail 0'in focused and b'skipped 0'in focused
mechanical=json.loads((base/'replay-693-final-reader.stdout').read_bytes());assert mechanical['verifiedSource']is True and mechanical['source']==S and mechanical['planSha256']==sha(old(originalPath));assert mechanical['readerSha256']==sha(read('scripts/read-committed-blob.mjs'))
for f in (base/'frozen-693/scripts').iterdir():
 if f.is_file():assert f.read_bytes()==old('scripts/'+f.name)
reevaluation=json.loads(read(unchanged[2]));graphPath=reevaluation['rust']['manifest'];graph=json.loads(read(graphPath))
for n,h in {**reevaluation['evaluatorSources'],**graph['sources']}.items():assert sha(read(n))==h and sha(old(n))==h
record={'schema':'tpnil-source-selector-recovery-independent-review@1','verified':True,'nativeQualification':False,'originalSource':S,'plan':{'path':planPath,'sha256':sha(read(planPath))},'rust':{'path':rustPath,'sha256':sha(read(rustPath))},'criteriaIdenticalToOriginal':True,'observations':698,'profile':'ITCVE-1@4.5.0','program':'ISI-4@5.5.0','inputCount':394,'unchangedOriginalInputs':383,'changedExistingInputs':changed,'addedInputs':added,'preservedOriginalFiles':[{'path':n,'sha256':sha(read(n))}for n in unchanged],'dockerInputsMappedExactly':394,'candidateArchiveMembersAllowed':45,'readerReview':{'maxBlobBytes':67108864,'metadataAndStderrBytes':65536,'perGitTimeoutMs':30000,'requiresExactCommitObject':True,'pinsResolvedBlobObjectId':True,'replacementRefsDisabled':True,'rawFileDescriptorOutput':True,'checksExactSizeAndGitObjectHash':True,'cleanupInNestedFinally':True},'focusedTests':{'path':str((base/'focused-tests-final-image-ignore.log').relative_to(R)),'sha256':sha(focused),'passed':27,'failed':0,'skipped':0,'independentlyRerun':False},'original693MechanicalReplay':{'path':str((base/'replay-693-final-reader.stdout').relative_to(R)),'sha256':sha((base/'replay-693-final-reader.stdout').read_bytes()),'newReaderOnOriginalSourceOnly':True,'successorAdmission':False},'source7AndRustGraphCarryUnchanged':True,'mappingDecision':'Same CLI/profile variant is source-bound to the explicit SOURCE-2 plan/Rust on the new committed source. Historical693 replay materializes its original selector and exact plan. No old JSON or predicate is overwritten.','limits':['Actual default CLI admission against the new committed successor remains a mandatory distinct post-commit/pre-push gate.','Static Docker projection and ignore checks are not an executed Linux image build.','No new native wallet session, full semantic suite replay, or native qualification is claimed by this review.'],'reviewedFiles':[{'path':n,'bytes':len(read(n)),'sha256':sha(read(n))}for n in changed+added+[planPath,rustPath]]}
(P/'review.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'verified':True,'sha256':sha((P/'review.json').read_bytes()),'planSha256':record['plan']['sha256'],'inputs':394,'dockerMissing':0,'candidateMembers':45}))
