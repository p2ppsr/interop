from pathlib import Path
import json,shlex,glob,posixpath,hashlib,subprocess,collections
R=Path.cwd();P=R/'out/native-closure-20261111/selector-buffer-impact-review/docker-before';sha=lambda b:hashlib.sha256(b).hexdigest();source='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7'
names=['infra/native/yours-go/Dockerfile','infra/native/integrated/Dockerfile','infra/native/conformance/Dockerfile'];covered=set();inputs=[]
for name in names:
 b=(R/name).read_bytes();q=P/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);inputs.append({'path':name,'sha256':sha(b)})
 for line in b.decode().splitlines():
  if not line.startswith('COPY '):continue
  parts=shlex.split(line[5:]);
  if parts[0].startswith('--from='):continue
  dst=parts[-1];srcs=parts[:-1]
  if not dst.startswith('/work/'):continue
  for src in srcs:
   if '$'in src:continue
   for match in glob.glob(src):
    p=Path(match)
    if p.is_dir():
     for f in p.rglob('*'):
      if f.is_file():covered.add(posixpath.join(dst.removeprefix('/work/'),f.relative_to(p).as_posix()))
    elif p.is_file():covered.add(posixpath.join(dst.removeprefix('/work/'),p.name)if dst.endswith('/')or len(srcs)>1 else dst.removeprefix('/work/'))
planpath='infra/native/conformance/plan-pr368-coverage-3-source-2.json';b=(R/planpath).read_bytes();plan=json.loads(b);(P/'plan-source2.json').write_bytes(b);missing=sorted(set(plan['conformanceInputs'])-covered)
original=json.loads(subprocess.check_output(['git','show',source+':infra/native/conformance/plan-pr368-coverage-3.json']));priorMissing=sorted(set(original['conformanceInputs'])-covered)
assert len(missing)==84 and len(priorMissing)==82
category=lambda n:'synthesis/test/fixtures'if n.startswith('synthesis/test/fixtures/')else 'synthesis/test'if n.startswith('synthesis/test/')else n.split('/')[0]
r={'schema':'tpnil-independent-container-copy-gap@1','finding':'BLOCKING_MISSING_PINNED_INPUTS','nativeQualification':False,'source2PlanSha256':sha(b),'dockerInputs':inputs,'inputCount':394,'missingCount':84,'original693MissingUnderSameCopyLayout':82,'missingByCategory':dict(collections.Counter(category(n)for n in missing)),'missing':missing,'dockerIgnorePresent':(R/'.dockerignore').exists(),'workerGate':'worker.ts reads and hashes every conformanceInputs file before services; run-native-go-wallet mounts only/evidence','scope':'Static expansion of source-owned local COPY paths in all three image layers. No Docker execution or native observation claimed. Dynamic out artifact COPYs cannot provide these missing static source paths.'};(P/'review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'sha256':sha((P/'review.json').read_bytes()),'missingByCategory':r['missingByCategory']}))
