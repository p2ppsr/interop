from pathlib import Path
import copy,gzip,hashlib,json,os,re,shutil,subprocess,tempfile,time
ROOT=Path.cwd(); ARCHIVE=ROOT/'journals/native-closure-validation/2026-11-12-coverage1'; OUT=ROOT/'out/native-closure-20261111'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
m=read(ARCHIVE/'validation.json'); freeze=read(ARCHIVE/'source-freeze-index.json'); expected='63cfe1dd618c91351810cb7e238fa56e39d276d09c3b433feda2d66a22cbbc78'
assert sha((ARCHIVE/'validation.json').read_bytes())==expected
assert m['schema']=='tpnil-native-coverage1-source-validation@1'
assert m['claim']=='LOCAL_ENGINEERING_PREFLIGHT_ONLY' and m['nativeSessions']==0 and not m['completeBRC100Conformance']
assert len(m['files'])==747 and len(freeze['runtimeInputs'])==157
files={}
for r in m['files']:
 p=Path(r['path']); assert not p.is_absolute() and '..' not in p.parts and str(p)==r['path']
 assert r['path'] not in files
 target=ARCHIVE/p; assert target.is_file() and not target.is_symlink()
 data=target.read_bytes();assert sha(data)==r['sha256'] and len(data)==r['bytes'];files[r['path']]=data
assert set(files)|{'validation.json'}=={str(p.relative_to(ARCHIVE)) for p in ARCHIVE.rglob('*') if p.is_file()}
indices={n:read(ARCHIVE/n) for n in ['preflight-index.json','source-freeze-index.json','final-log-index.json','final-check-index.json']}
raws={}; decoded=0
for name,index in indices.items():
 for row in index['files']:
  data=files[row['path']]; assert len(data)==row['bytes'] and sha(data)==row['sha256']
  raw=gzip.decompress(data) if row.get('encoding')=='gzip' else data
  assert len(raw)==row['rawBytes'] and sha(raw)==row['rawSha256']
  if row.get('encoding')=='gzip':assert data[4:8]==b'\0\0\0\0'
  if row['path'] in raws:assert raws[row['path']]==raw
  raws[row['path']]=raw;decoded+=1
assert m['sourceInputs']==freeze['runtimeInputs']
assert m['nativePlan']==dict(freeze['plan'],inputs=len(freeze['runtimeInputs']))
assert freeze['sourceHeadAtSnapshot']==m['sourceRuntimeCommit']=='b9bc8fb0eed238594ca7fe89aed9296f26a2760e'
for name,digest in freeze['runtimeInputs'].items():
 committed=subprocess.check_output(['git','show',m['sourceRuntimeCommit']+':'+name],cwd=ROOT)
 assert sha(committed)==digest and committed==raws['source/'+name+'.gz']
planbytes=subprocess.check_output(['git','show',m['sourceRuntimeCommit']+':'+freeze['plan']['path']],cwd=ROOT)
assert sha(planbytes)==freeze['plan']['sha256'];plan=json.loads(planbytes)
assert plan['conformanceInputs']==freeze['runtimeInputs']
summary=json.loads(raws['evidence/out/native-closure-20261111/coverage1-final-summary.json.gz'])
assert summary['results']==m['results'] and summary['sourceRuntimeCommit']==m['sourceRuntimeCommit']
logs={};selected=[]
for name,row in summary['logs'].items():
 matches=[(p,b) for p,b in raws.items() if p.endswith('/'+row['path']+'.gz') and sha(b)==row['sha256']]
 assert matches,(name,row)
 assert len({b for _,b in matches})==1
 logs[name]=matches[0][1].decode(); selected.append({'name':name,'paths':[p for p,_ in matches],'sha256':row['sha256'],'bytes':len(matches[0][1])})
assert re.search(r'ℹ pass 173\nℹ fail 0\nℹ cancelled 0\nℹ skipped 0',logs['core'])
assert '1079 passed | 23 skipped (1102)' in logs['synthesis'] and '64 passed | 2 skipped (66)' in logs['synthesis']
assert 'Ran 5 tests' in logs['python'] and logs['python'].rstrip().endswith('OK')
assert '31 passed (31)' in logs['prelude'] and 'ℹ pass 57' in logs['frozenCore']
assert 'tsc --noEmit' in logs['typecheck'] and not re.search(r'error TS\d+',logs['typecheck'])
assert 'ITCVE-1 1.1.0: three pinned Go implementations' in logs['catalog']
assert '"outcome": "PASS"' in logs['standards']
publication=json.loads(logs['publishedSemantic']); print('publication',list(publication))
# Retained semantic receipt distinguishes successful replay from failed-attempt byte validation.
assert len(publication['bundles'])==31
assert sum(r['kind']=='attempt' for r in publication['bundles'])==17
assert sum(r.get('semantic') is True for r in publication['bundles'])==14
external=0
for name,row in indices['preflight-index.json']['externalReferences'].items():
 p=Path(name); p=p if p.is_absolute() else ROOT/p
 assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'];external+=1
for name,row in read(ARCHIVE/'linked-evidence.json')['files'].items():
 p=ROOT/name;assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256']
prefix=str(ARCHIVE.relative_to(ROOT))+'/'
staged=set(subprocess.check_output(['git','ls-files','--cached','-z','--',str(ARCHIVE.relative_to(ROOT))],cwd=ROOT).decode().split('\0'))-{''}
assert staged=={prefix+n for n in set(files)|{'validation.json'}}
positive=subprocess.run(['python3',str(ARCHIVE/'verify.py'),'--with-local-artifacts','--staged'],cwd=ROOT,text=True,capture_output=True)
(OUT/'coverage1-archive-independent-positive.log').write_text(positive.stdout+positive.stderr);assert positive.returncode==0
# Run the actual retained verifier in an isolated path with the same repository depth.
TMP=ROOT/'out/coverage1-archive-adversarial';TMP.mkdir(exist_ok=True)
FIX=TMP/'fixture';shutil.rmtree(FIX,ignore_errors=True);shutil.copytree(ARCHIVE,FIX)
original={str(p.relative_to(FIX)):p.read_bytes() for p in FIX.rglob('*') if p.is_file()};tests=[]
def restore():
 for p in sorted(FIX.rglob('*'),reverse=True):
  if p.is_file() or p.is_symlink():p.unlink()
 for name,data in original.items():
  p=FIX/name;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(data)
def put_json(name,obj):
 (FIX/name).write_text(json.dumps(obj,indent=2)+'\n')
def modify_manifest(fn):
 doc=read(FIX/'validation.json');fn(doc);put_json('validation.json',doc)
def rehash(name):
 data=(FIX/name).read_bytes()
 modify_manifest(lambda doc:[r.update(sha256=sha(data),bytes=len(data)) for r in doc['files'] if r['path']==name])
def index_mutation(name,fn):
 doc=read(FIX/name);fn(doc);put_json(name,doc);rehash(name)
def run(name,fn):
 restore();fn(); t=time.monotonic();r=subprocess.run(['python3',str(FIX/'verify.py')],cwd=ROOT,text=True,capture_output=True)
 tests.append({'name':name,'rejected':r.returncode!=0,'exitCode':r.returncode,'seconds':round(time.monotonic()-t,3),'stdout':r.stdout,'stderr':r.stderr})
 (OUT/'coverage1-archive-independent-adversarial.json').write_text(json.dumps(tests,indent=2)+'\n')
run('changed_member',lambda:(FIX/'README.md').write_bytes(original['README.md']+b'tamper'))
run('missing_member',lambda:(FIX/'README.md').unlink())
run('extra_member',lambda:(FIX/'unindexed.txt').write_text('extra'))
run('duplicate_manifest_member',lambda:modify_manifest(lambda d:d['files'].append(copy.deepcopy(d['files'][0]))))
run('unsafe_member_path',lambda:modify_manifest(lambda d:d['files'][0].update(path='../escape')))
run('false_native_claim',lambda:modify_manifest(lambda d:d.update(claim='NATIVE_QUALIFIED')))
run('false_native_session',lambda:modify_manifest(lambda d:d.update(nativeSessions=1)))
run('decoded_digest_mismatch',lambda:index_mutation('preflight-index.json',lambda d:d['files'][0].update(rawSha256='0'*64)))
run('committed_source_mismatch',lambda:index_mutation('source-freeze-index.json',lambda d:d['runtimeInputs'].update({next(iter(d['runtimeInputs'])):'0'*64})))
run('frozen_plan_digest_mismatch',lambda:index_mutation('source-freeze-index.json',lambda d:d['plan'].update(sha256='0'*64)))
run('false_test_count',lambda:modify_manifest(lambda d:d['results'].update(corePassed=999)))
run('manifest_source_binding_mismatch',lambda:modify_manifest(lambda d:d['sourceInputs'].update({next(iter(d['sourceInputs'])):'0'*64})))
run('manifest_native_plan_mismatch',lambda:modify_manifest(lambda d:d['nativePlan'].update(sha256='0'*64,inputs=999)))
restore();shutil.rmtree(FIX)
assert sha((ARCHIVE/'validation.json').read_bytes())==expected
assert all((ARCHIVE/name).read_bytes()==data for name,data in files.items())
report={'schema':'tpnil-coverage1-independent-archive-review@1','claim':'LOCAL_ENGINEERING_ARCHIVE_REVIEW_ONLY','nativeSessions':0,'completeBRC100Conformance':False,'manifest':{'path':str(ARCHIVE.relative_to(ROOT))+'/validation.json','sha256':expected},'script':{'path':str(Path(__file__).relative_to(ROOT)),'sha256':sha(Path(__file__).read_bytes())},'sourceRuntimeCommit':m['sourceRuntimeCommit'],'checks':{'storedMembers':len(files),'decodedIndexEntries':decoded,'uniqueDecodedFiles':len(raws),'committedRuntimeInputs':len(freeze['runtimeInputs']),'externalReferencesIncludingLocalExecutables':external,'stagedInventoryComplete':True,'summaryLogBindings':selected,'counts':m['results'],'sourceArchiveUnchanged':True},'retainedVerifier':json.loads(positive.stdout),'adversarialTests':tests,'observations':['Initial root staged-inventory check rejected 454 ignored descendants; this independent run verifies the subsequently complete exact staged inventory.','Empty historical published-semantic-3 capture remains unchanged; final nonempty 11591-byte log is selected by exact summary digest from final-validation.','Earlier preflight pending metadata remains an immutable stage; appended final source validation binds final results.'],'findings':[{'name':t['name'],'issue':'Retained archive verifier accepted mutated manifest metadata while independently bound source/index remained unchanged.'} for t in tests if not t['rejected']]}
report['result']='PASS' if not report['findings'] else 'CORRECTION_REQUIRED'
(OUT/'coverage1-archive-independent-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':report['result'],'files':len(files),'decoded':decoded,'negativeTests':len(tests),'rejected':sum(t['rejected'] for t in tests),'findings':report['findings']},indent=2))
