import fs from 'node:fs';
import path from 'node:path';
import { ControlledWalletServices } from '../synthesis/src/wallet-lab/services.ts';
import { createFixtureWallet } from '../synthesis/src/storage-sync/fixture-wallet.ts';
import { startMessagingMongo } from '../components/messaging/mongo.mjs';
import { runNativeMessaging } from '../components/messaging/native.mjs';
const out=path.resolve('out/native-messaging-engineering-1');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'CALLER.txt'),'Engineering invocation with real Toolbox wallet, not an unchanged native application.\n');
const webroot=path.join(out,'webroot');fs.mkdirSync(webroot,{recursive:true});fs.writeFileSync(path.join(webroot,'index.html'),'<title>Engineering invocation</title>');
const services=new ControlledWalletServices({webroot});let mongo,payer;
try{await services.start();await services.fundRemoteWalletFromTeranode('77'.repeat(32),JSON.parse(fs.readFileSync('fixtures/teranode/wab-funding-v1.json')));payer=await createFixtureWallet(services,'77'.repeat(32));mongo=await startMessagingMongo();process.env.TPNIL_GO_MONGO_URI=mongo.uri;const result=await runNativeMessaging(payer,services,out);console.log(JSON.stringify(result));}
finally{await payer?.destroy();await services.close();console.log(await mongo?.close());}
