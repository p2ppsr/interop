import fs from 'node:fs';
import path from 'node:path';
import { ControlledWalletServices } from '../synthesis/src/wallet-lab/services.ts';
import { createFixtureWallet } from '../synthesis/src/storage-sync/fixture-wallet.ts';
import { startMessagingMongo } from '../components/messaging/mongo.mjs';
import { runNativeMessaging } from '../components/messaging/native.mjs';
const out=path.resolve('out/native-messaging-go-engineering-2');
fs.mkdirSync(out,{recursive:false});
fs.writeFileSync(path.join(out,'CALLER.txt'),'Engineering invocation with real Toolbox payer and patched Go Wallet Storage, Go Overlay Services and Go ChainTracks. This is not an unchanged native application.\n');
const webroot=path.join(out,'webroot');fs.mkdirSync(webroot);fs.writeFileSync(path.join(webroot,'index.html'),'<title>Go storage engineering invocation</title>');
let services,mongo,payer;
const cleanup=[];
try{
 mongo=await startMessagingMongo();process.env.TPNIL_GO_MONGO_URI=mongo.uri;
 services=new ControlledWalletServices({webroot,components:{storage:'go',overlay:'go',chaintracks:'go'},go:{binary:path.resolve('out/itcve-go-storage-sync'),storageSyncPatch:true,mongoUri:mongo.uri}});
 await services.start();
 fs.writeFileSync(path.join(out,'component-identity.json'),JSON.stringify(services.componentIdentity,null,2)+'\n');
 const funding=await services.fundRemoteWalletFromTeranode('77'.repeat(32),JSON.parse(fs.readFileSync('fixtures/teranode/wab-funding-v1.json')));
 fs.writeFileSync(path.join(out,'funding.json'),JSON.stringify(funding,null,2)+'\n');
 payer=await createFixtureWallet(services,'77'.repeat(32));
 const result=await runNativeMessaging(payer,services,out);console.log(JSON.stringify({assertions:result.assertions,result:result.result}));
 if(result.result!=='PASS')process.exitCode=1;
}catch(error){fs.writeFileSync(path.join(out,'engineering-failure.json'),JSON.stringify({message:String(error?.stack??error)},null,2)+'\n');throw error;}
finally{
 try{await payer?.destroy();cleanup.push({payerClosed:true});}catch(error){cleanup.push({payerError:String(error)});}
 if(services){fs.writeFileSync(path.join(out,'submissions.json'),JSON.stringify(services.submissions.map(s=>({...s,bytes:Buffer.from(s.bytes).toString('hex')})),null,2)+'\n');fs.writeFileSync(path.join(out,'go-services.log'),services.componentDiagnostics);await services.close().then(()=>cleanup.push({servicesClosed:true}),error=>cleanup.push({servicesError:String(error)}));}
 if(mongo)await mongo.close().then(receipt=>cleanup.push(receipt),error=>cleanup.push({mongoError:String(error)}));
 fs.writeFileSync(path.join(out,'engineering-cleanup.json'),JSON.stringify(cleanup,null,2)+'\n');console.log(JSON.stringify({cleanup}));
 if(cleanup.some(r=>r.payerError||r.servicesError||r.mongoError))process.exitCode=1;
}
