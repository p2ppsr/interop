from pathlib import Path
import subprocess,json,hashlib,datetime,fnmatch,re
R=Path('/Users/tyeverett/tmp/network-ops/worktrees/p2ppsr/interop/codex/lab-integration-20261106')
OPS=Path('/Users/tyeverett/projects/network-ops');D=OPS/'artifacts/ops/itcve-native-closure-20261111/attempt-7-completion-order'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args,cwd=R:subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
expectedSource='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7';base='1f9fe0f9b979e9bbca66e90335f02ba2b80c7d41'
assert sha(D/'work-order.json')=='74845f47f71a435e0b21facc02cb5aa44024ae7a8963104009461145d2a18335'
o=json.loads((D/'work-order.json').read_text());assert o['source']==expectedSource==git('rev-parse','HEAD');assert not git('status','--porcelain')
assert git('branch','--show-current')=='codex/native-wallet-closure-20261111'
remote=git('ls-remote','origin','refs/heads/'+o['sourceBranch']).split()[0];assert remote==base,'Unexpected remote ref before order publication'
assert git('branch','--show-current',cwd=OPS)=='master';assert git('rev-parse','master',cwd=OPS)==git('rev-parse','origin/master',cwd=OPS)
plan=json.loads((R/o['plan']).read_text());assert o['frozenNativeInputCount']==len(o['frozenNativeInputs'])==391 and o['frozenNativeInputs']==plan['conformanceInputs']
index={}
for line in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R).split(b'\0'):
 if line:
  header,name=line.split(b'\t',1);mode,oid,stage=header.decode().split();assert stage=='0';index[name.decode()]=oid
def committed(name,h):
 p=R/name;b=p.read_bytes();assert sha(p)==h,name
 assert index.get(name)==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),name
for name,h in o['frozenNativeInputs'].items():committed(name,h)
for k,h in [('plan','planSha256'),('rustCompatibility','rustCompatibilitySha256'),('source7Plan','source7PlanSha256')]:
 committed(o[k],o[h]);assert (D/Path(o[k]).name).read_bytes()==(R/o[k]).read_bytes()
assert o['plannedObservationsPerRepetition']==698==535+163
assert (o['profile'],o['program'],o['claim'])==('ITCVE-1@4.5.0','ISI-4@5.5.0','ENGINEERING_OBSERVATION_ONLY')and o['officialRelease']is False
assert o['artifact']=={'version':'5.1.1-pr368.3e8a97f','source':'3e8a97f3dd7953a10e3034381814f3f8aa8b01c0','sha256':'9da87d79ac7ac70e3c5dee50451b2f0456b51f5e480b1be0925cd24a7707e184','bytes':13245082,'intake':'fixtures/artifacts/yours-wallet-pr368-3e8a97f/provenance.json','intakeSha256':'38b9bb8932819f6f40e0a788fc7e579e67eca657fbf8945c5242bc91cb0a2844'}
committed(o['artifact']['intake'],o['artifact']['intakeSha256'])
a=o['automaticValidationEnvelope'];n=o['nativeEnvelope'];assert [x['maximumJobSeconds']for x in a['foundation']['jobs']]==[600,1200,2400]
assert a['foundation']['maximumRuns']==a['retainedReevaluation']['maximumRuns']==n['maximumRuns']==1
assert a['foundation']['maximumJobSeconds']==4200 and a['retainedReevaluation']['maximumJobSeconds']==1200 and n['maximumJobSeconds']==4200
assert a['maximumCombinedNewJobSeconds']==4200+1200+4200==9600
assert n['repetitions']==2 and n['timeoutSecondsPerRepetition']==1500 and n['containerGraceSecondsPerRepetition']==60 and n['automaticRetries']==0
assert 2*(1500+60)+n['setupAllowanceSeconds']+n['verificationAndUploadAllowanceSeconds']==n['sumPlannedJobSeconds']==4200
created=datetime.datetime.fromisoformat(o['createdAt']);deadline=datetime.datetime.fromisoformat(o['deadline']);latest=datetime.datetime.fromisoformat(o['latestNativeDispatchAt'])
assert (deadline-created).total_seconds()==9000 and (deadline-latest).total_seconds()==4200
assert latest>datetime.datetime.now(datetime.timezone.utc)
c=o['cost'];assert (c['completedCohortJobSecondsBeforeNewOrder'],c['maximumAdditionalJobSeconds'],c['maximumCompletedCohortJobSecondsAfterThisOrder'])==(25120,9600,34720)
for k in ['actualMoneyUsd','estimatedMoneyUsd','operatorCostUsd','developmentAgentCostUsd','allocatedOwnedCapacityCostUsd','storageAndEgressUsd','fullCostPerAcceptedPack','costImprovementFactor']:assert c[k]is None
assert c['externalDeviceReservations']==0 and c['reservationIsNotActualCharge']is True
assert o['observerCapacity']['ledgerBytesPerProvider']==134217728 and o['observerCapacity']['entriesPerProvider']==2048 and o['observerCapacity']['full698CapacityQualified']is False
assert o['publicMainnetBroadcast']is False and o['completeBRC100Conformance']is False and not o['pending']
trigger=json.loads((D/o['triggerInventory']).read_text());assert sha(D/o['triggerInventory'])==o['triggerInventorySha256'];assert trigger['actualFutureCommit']==expectedSource
changed=git('diff','--name-only',base,expectedSource).splitlines();assert trigger['changedPaths']==changed
for w in trigger['workflows']:
 committed(w['path'],w['sha256']);matches=[p for p in changed if any(fnmatch.fnmatchcase(p,q)for q in w['pushPaths'])]
 assert w['matchingChangedPaths']==matches
 assert w['pushWouldSchedule']==('push'in w['events']and(not w['pushPaths']or bool(matches)))
assert {w['path']for w in trigger['workflows']if w['pushWouldSchedule']}=={'.github/workflows/ci.yml','.github/workflows/native-evidence-reevaluation.yml'}
assert len(trigger['workflows'])==8
for x in o['workflowSnapshotsBeforeFreeze']:committed(x['path'],x['sha256'])
v=o['validation'];assert v['manifestSha256']=='d385fc517b93c3db44a63edaa32689726cde0683b0635035a9a5e733e7017a80'
committed(v['archive']+'/validation.json',v['manifestSha256']);committed(v['independentReview'],v['independentReviewSha256'])
review=json.loads((R/v['independentReview']).read_text());assert review['verified']and review['archiveSha256']==v['manifestSha256']and review['nativeQualification']is False
assert len(review['results'])==16 and all(r['passed']for r in review['results'])and review['positiveControls']==1 and review['negativeControls']==15
assert (D/'validation-manifest.json').read_bytes()==(R/v['archive']/'validation.json').read_bytes()
assert (D/'validation-independent-review.json').read_bytes()==(R/v['independentReview']).read_bytes()
assert sha(D/o['generator']['path'])==o['generator']['sha256'];assert sha(D/o['priorProposal']['path'])==o['priorProposal']['sha256']
assert 'PR'in ' '.join(o['notIncluded'])and o['policyImplementation']['runtimeEnforced']is False
print(json.dumps({'schema':'tpnil-exact-attempt7-order-independent-review@1','verified':True,'source':expectedSource,'orderSha256':sha(D/'work-order.json'),'remoteBeforePush':remote,'committedNativeInputs':391,'actualChangedPaths':len(changed),'workflowsReviewed':8,'expectedAutomaticWorkflows':2,'foundationMaximumJobSeconds':4200,'source7MaximumJobSeconds':1200,'nativeMaximumJobSeconds':4200,'totalMaximumNewJobSeconds':9600,'knownCohortBeforeJobSeconds':25120,'maximumCohortAfterJobSeconds':34720,'deadline':o['deadline'],'latestNativeDispatchAt':o['latestNativeDispatchAt'],'archiveSha256':v['manifestSha256'],'archiveIndependentReviewSha256':v['independentReviewSha256'],'independentArchiveControls':16,'full698NativeCapacityQualified':False,'monetaryCostsKnown':False,'nativeDispatchPerformed':False,'CIStartedByReview':False,'reviewerScriptSha256':sha(Path(__file__))},indent=2))
