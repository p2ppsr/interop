import datetime, fnmatch, hashlib, json, shutil, subprocess, sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
ops = Path('/Users/tyeverett/projects/network-ops')
target = ops / 'artifacts/ops/itcve-native-closure-20261111/attempt-7-completion-order'
base = '1f9fe0f9b979e9bbca66e90335f02ba2b80c7d41'

def run(*args, cwd=root):
    return subprocess.check_output(args, cwd=cwd, text=True).strip()

def digest(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    (target / name).write_text(json.dumps(value, indent=2) + '\n')

assert not run('git', 'status', '--porcelain'), 'Source must be committed and clean'
assert run('git', 'branch', '--show-current') == 'codex/native-wallet-closure-20261111'
source = run('git', 'rev-parse', 'HEAD')
assert source != base
assert run('git', 'rev-parse', 'origin/codex/native-wallet-closure-20261111') == base
assert run('git', 'branch', '--show-current', cwd=ops) == 'master'
assert not run('git', 'status', '--porcelain', cwd=ops)
assert run('git', 'rev-parse', 'master', cwd=ops) == run('git', 'rev-parse', 'origin/master', cwd=ops)

proposal_path = root / 'out/native-closure-20261111/attempt7-work-order-proposal.json'
order = json.loads(proposal_path.read_text())
for file_key, hash_key in [('plan', 'planSha256'), ('rustCompatibility', 'rustCompatibilitySha256'), ('source7Plan', 'source7PlanSha256')]:
    assert digest(root / order[file_key]) == order[hash_key]
plan = json.loads((root / order['plan']).read_text())
assert len(plan['conformanceInputs']) == 391
for name, sha in plan['conformanceInputs'].items():
    assert digest(root / name) == sha, name

trigger_path = root / 'out/native-closure-20261111/coverage3-scaffolding/push-trigger-inventory.json'
triggers = json.loads(trigger_path.read_text())
changed = run('git', 'diff', '--name-only', base, source).splitlines()
assert changed
for workflow in triggers['workflows']:
    assert digest(root / workflow['path']) == workflow['sha256']
    matches = [name for name in changed if any(fnmatch.fnmatchcase(name, pattern) for pattern in workflow['pushPaths'])]
    expected = 'push' in workflow['events'] and (not workflow['pushPaths'] or bool(matches))
    assert expected == workflow['pushWouldSchedule'], workflow['path']
    workflow['matchingChangedPaths'] = matches
triggers.update(sourceState='COMMITTED_CLEAN_SOURCE', actualFutureCommit=source, localHead=source, changedPaths=changed)

manifest_path = root / 'journals/native-closure-validation/2026-11-12-coverage-completion/validation.json'
assert digest(manifest_path) == sys.argv[1], 'Final validation manifest differs'
review_path = root / sys.argv[2]
assert review_path.is_file()
review = json.loads(review_path.read_text())
assert review['schema'] == 'tpnil-validation-archive-independent-review@1'
assert review['manifestSha256'] == digest(manifest_path)
assert review['verified'] is True and review['archiveSha256'] == digest(manifest_path)
assert review['positiveControls'] == 1 and review['negativeControls'] == 15
assert len(review['results']) == 16 and all(row['passed'] is True for row in review['results'])
assert review['nativeQualification'] is False and review['runtimeInputs'] == 391
assert review['allRuntimeInputBytesRetained'] is True and review['originalArchiveUnchanged'] is True

now = datetime.datetime.now(datetime.timezone.utc)
deadline = now + datetime.timedelta(minutes=150)
order.update(schema='network-ops-native-closure-execution-order@1', attempt=7,
             status='COMMITTED_LOCAL_SOURCE_VALIDATED_BEFORE_PUSH', source=source,
             dispatchAuthorizedByThisOrder=True, createdAt=now.isoformat(), deadline=deadline.isoformat(),
             latestNativeDispatchAt=(deadline-datetime.timedelta(seconds=4200)).isoformat(),
             sourceBranch='codex/native-wallet-closure-20261111', pending=[],
             customerTask='Native installation/onboarding, trusted public permission decisions, ToDo create/cold reload/redeem, public CWI conformance, complete owned-service shutdown and independent replay.',
             fidelity='Linux/amd64 native Chromium extension with sandbox/network-none; two fresh containers, profiles and identities; exact candidate and actual Go services with controlled mined proof. No physical-device or official-release claim.',
             publicMainnetBroadcast=False, completeBRC100Conformance=False,
             originalFailureComparisonDenominator=99,
             nativeDispatchPrerequisites=['Exact remote source matches this order', 'One exact-source Foundation workflow and one exact-source source7 workflow both succeed', 'No native run at this source already exists', 'Full 4200-second allowance fits the absolute deadline'],
             validation={'archive':str(manifest_path.parent.relative_to(root)), 'manifestSha256':digest(manifest_path), 'independentReview':str(review_path.relative_to(root)), 'independentReviewSha256':digest(review_path), 'nativeInputs':391, 'corePass':204, 'synthesisPass':1705, 'synthesisSkip':90, 'pythonPass':5, 'acceptedArchivesReplayed':14, 'retainedAttemptsReplayed':19, 'newNativeSessions':0},
             triggerInventory='committed-trigger-inventory.json',
             priorProposal={'path':'proposal.json','sha256':digest(proposal_path)},
             policyImplementation={'runtimeEnforced':False,'unknownCostsAreZero':False,'newPaidCapacity':False,'costImprovementFactor':None})
target.mkdir()
shutil.copyfile(proposal_path, target / 'proposal.json')
shutil.copyfile(manifest_path, target / 'validation-manifest.json')
shutil.copyfile(review_path, target / 'validation-independent-review.json')
for file_key in ['plan', 'rustCompatibility', 'source7Plan']:
    shutil.copyfile(root / order[file_key], target / Path(order[file_key]).name)
write('committed-trigger-inventory.json', triggers)
order['triggerInventorySha256'] = digest(target / 'committed-trigger-inventory.json')
shutil.copyfile(Path(__file__), target / 'prepare-attempt7-order.py')
order['generator'] = {'path':'prepare-attempt7-order.py','sha256':digest(target / 'prepare-attempt7-order.py')}
write('work-order.json', order)
print(json.dumps({'directory':str(target),'source':source,'deadline':order['deadline'],'latestNativeDispatchAt':order['latestNativeDispatchAt'],'workOrderSha256':digest(target/'work-order.json'),'changedPaths':len(changed)}))
