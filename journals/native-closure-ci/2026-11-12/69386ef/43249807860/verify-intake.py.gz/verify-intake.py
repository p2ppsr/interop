#!/usr/bin/env python3
"""Independently derive CI counts and prerequisite receipts from retained originals.
No network, workload execution, or replacement of original assertions occurs.
"""
from pathlib import Path
from collections import Counter
import json, re, hashlib, zipfile, subprocess, sys
root = Path.cwd()
base = Path(__file__).resolve().parent
H = lambda b: hashlib.sha256(b).hexdigest()
source = '69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7'
a = json.loads((base / 'acquisition.json').read_text())
assert a['source'] == source and a['run'] == 43249807860 and a['conclusion'] == 'success'
artifact_members = {}
for f in a['files'] + a['apis']:
    b = (base / f['path']).read_bytes()
    assert len(b) == f['bytes'] and H(b) == f['sha256']
    if 'artifactId' in f:
        z = zipfile.ZipFile(base / f['path'])
        assert len(z.infolist()) == len(f['members']) and len(set(z.namelist())) == len(z.namelist())
        for m in f['members']:
            assert not m['path'].startswith('/') and '..' not in Path(m['path']).parts
            b = z.read(m['path'])
            assert len(b) == m['bytes'] and H(b) == m['sha256']
            assert b == (base / f"original/{f['artifactId']}" / m['path']).read_bytes()
        artifact_members[str(f['artifactId'])] = len(f['members'])
assert artifact_members == {'13959477803': 193, '13961110660': 51, '13958824004': 18}
run = json.loads((base / 'run-api.json').read_text())
assert run['head_sha'] == source and run['conclusion'] == 'success' and run['status'] == 'completed'
jobs = json.loads((base / 'jobs-api.json').read_text())['jobs']
assert {j['name'] for j in jobs} == {'offline-core', 'go-components', 'integrated-components'}
assert all(j['conclusion'] == 'success' and j['status'] == 'completed' for j in jobs)
assert all(s['conclusion'] in ('success', 'skipped') for j in jobs for s in j['steps'])
def log(job):
    return re.sub(r'\x1b\[[0-9;]*m', '', (base / f'job-{job}.log').read_text())
def values(t, label):
    return [int(x) for x in re.findall(r'ℹ ' + label + r' (\d+)', t)]
offline = log(131292196465)
go = log(131292195874)
integrated = log(131292196581)
assert values(offline, 'tests') == [204] and values(offline, 'pass') == [203]
assert values(offline, 'fail') == [0] and values(offline, 'skipped') == [1]
assert re.search(r'Tests\s+1675 passed\s*\|\s*120 skipped\s*\(1795\)', offline)
assert re.search(r'Test Files\s+88 passed\s*\|\s*5 skipped\s*\(93\)', offline)
assert 'Ran 5 tests' in offline and re.search(r'\bOK\b', offline)
assert re.search(r'Tests\s+13 passed\s*\(13\)', go)
assert re.search(r'Tests\s+42 passed\s*\(42\)', integrated)
assert re.search(r'Tests\s+14 passed\s*\(14\)', integrated)
assert values(integrated, 'tests') == [8, 15] and values(integrated, 'pass') == [8, 15]
assert values(integrated, 'fail') == [0, 0] and values(integrated, 'skipped') == [0, 0]
assert re.findall(r'test result: ok\. (\d+) passed; 0 failed;', integrated) == ['1', '14']
lines = [re.sub(r'^\S+Z ', '', l) for l in integrated.splitlines()]
receipts = []
for i, line in enumerate(lines):
    if not line.startswith('{'):
        continue
    try:
        obj, _ = json.JSONDecoder().raw_decode('\n'.join(lines[i:]))
        receipts.append((i + 1, obj))
    except json.JSONDecodeError:
        pass

def one(predicate):
    hits = [(i, x) for i, x in receipts if predicate(x)]
    assert len(hits) == 1, len(hits)
    return hits[0]
pack_line, pack = one(lambda x: x.get('schema') == 'tpnil-integrated-verification@2' and x.get('childOraclesVerified') is True)
assert pack['verified'] is True and pack['source'] == source and pack['lanes'] == 9
publication_line, publication = one(lambda x: x.get('semantic') is True and 'verifiedPublishedIntegrationArchives' in x)
assert publication['verifiedPublishedIntegrationArchives'] == 14 and publication['verifiedPublishedIntegrationAttempts'] == 19 and len(publication['bundles']) == 33
desc_line, desc = one(lambda x: x.get('directions') == 4 and x.get('freshExecutions') == 8)
assert desc['verified'] is True and desc['result'] == 'PASS' and desc['assertions'] == 80 and desc['independentIdentities'] == 8 and desc['sourceCommit'] == source
mutation_line, mutation = one(lambda x: x.get('mutationsRejected') == 5 and x.get('validFailurePreserved') is True)
assert mutation['verified'] is True
r = base / 'original/13959477803'
lock = json.loads((r / 'run-lock.json').read_text())
assert lock['source'] == source and lock['dirty'] is False
for p, s in lock['files'].items():
    assert H(subprocess.check_output(['git', 'show', source + ':' + p], cwd=root)) == s
result = json.loads((r / 'result.json').read_text())
assert result['schema'] == 'tpnil-integrated-result@2' and result['claim'] == 'INFRASTRUCTURE_QUALIFICATION_ONLY'
assert len(result['lanes']) == 9 and [l['id'] for l in result['lanes']] == lock['profile']['lanes']
rows, findings, lane_counts = [], [], []
for lane in result['lanes']:
    lane_rows = []
    for index, rr in enumerate(lane['runs']):
        assert rr['exitCode'] == 0 and rr['timedOut'] is False and (r / rr['result']).is_file()
        assert rr['assertions']
        lane_rows += rr['assertions']
        for x in rr['assertions']:
            if x['result'] != 'PASS':
                findings.append({'lane': lane['id'], 'resultFile': rr['result'], **x})
    rows += lane_rows
    lane_counts.append({'lane': lane['id'], 'counts': dict(Counter(x['result'] for x in lane_rows))})
assert len(rows) == 590 and Counter(x['result'] for x in rows) == {'PASS': 584, 'FAIL': 6}
assert findings == pack['findings']
assert all(x['lane'] == 'messaging' and x['implementation'] == 'go' for x in findings)
assert {x['id'] for x in findings} == {'paid-internalization', 'payment-replay-after-acknowledgment', 'payment-replay-rejected'}
for p in (base / 'original/13961110660').rglob('*'):
    if p.is_file():
        assert p.read_bytes() == (r / 'descendant-storage-sync' / p.relative_to(base / 'original/13961110660')).read_bytes()
summary = {
    'schema': 'tpnil-foundation-independent-intake-review@1', 'result': 'PASS', 'source': source, 'run': a['run'],
    'scope': 'Independent raw artifact/source/count and complete recorded semantic-prerequisite review. No additional local semantic replay or native session.',
    'acquisitionSha256': H((base / 'acquisition.json').read_bytes()), 'artifactMembers': artifact_members,
    'core': {'PASS': 203, 'SKIP': 1, 'total': 204}, 'synthesis': {'PASS': 1675, 'SKIP': 120, 'total': 1795},
    'synthesisFiles': {'PASS': 88, 'SKIP': 5, 'total': 93}, 'python': {'PASS': 5}, 'goMatrixTests': {'PASS': 13},
    'integratedFocusedTests': {'certificateReference': 42, 'shutdownAndListener': 14, 'transport': 8, 'services': 15, 'rustDefault': 1, 'rustGraph': 14},
    'componentMatrix': {'lanes': 9, 'assertions': 590, 'counts': {'PASS': 584, 'FAIL': 6}, 'laneCounts': lane_counts, 'findings': findings, 'childOraclesVerified': True},
    'publishedSemantic': {'archives': 14, 'attempts': 19, 'bundles': 33},
    'descendantStorage': {'directions': 4, 'freshExecutions': 8, 'independentIdentities': 8, 'assertions': 80, 'result': 'PASS'},
    'recordedReceiptLines': {'integratedParent': pack_line, 'publishedSemantic': publication_line, 'messagingMutations': mutation_line, 'descendant': desc_line},
    'limitations': ['Existing six unchanged-upstream Go messaging findings remain FAIL; CI success means evidence verification, not all components passing.', 'The 24 new Go-host admission mutation cases are explicitly skipped in offline CI; source-bound local tests and future actual native host admission remain distinct.', 'Compared with local synthesis1705PASS90SKIP, offline CI has28 additional browser-gated and2 Go-host-presence skips. Dedicated integrated Go shutdown/listener tests run after preparation.', 'This component/retained-source CI does not qualify the new698-predicate native profile.'],
    'newNativeSessions': 0, 'completeBRC100Conformance': False,
    'logs': [{'path': p.name, 'sha256': H(p.read_bytes()), 'bytes': p.stat().st_size} for p in sorted(base.glob('job-*.log'))]
}
out = base / 'independent-intake-review.json'
if '--write' in sys.argv:
    assert not out.exists()
    out.write_text(json.dumps(summary, indent=2) + '\n')
else:
    assert json.loads(out.read_text()) == summary
print(json.dumps({'verified': True, 'result': 'PASS', 'source': source, 'reviewSha256': H(out.read_bytes()), 'artifactMembers': sum(artifact_members.values()), 'componentAssertions': len(rows), 'semanticBundles': len(publication['bundles'])}))
