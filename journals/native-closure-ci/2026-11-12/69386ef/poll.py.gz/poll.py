from pathlib import Path
import json,subprocess,datetime,hashlib
B=Path(__file__).resolve().parent;SOURCE='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7';now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%S%fZ');D=B/stamp;D.mkdir()
def api(endpoint,name):
 p=subprocess.run(['gh','api',endpoint],capture_output=True);(D/(name+'.json')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(endpoint,p.stderr.decode());return json.loads(p.stdout)
runs=api('repos/p2ppsr/interop/actions/runs?head_sha='+SOURCE+'&per_page=100','runs');assert runs['total_count']<=100
expected={'Foundation checks','Retained native evidence reevaluation'};summary={'capturedAt':now.isoformat(),'source':SOURCE,'totalRuns':runs['total_count'],'runs':[],'alerts':[],'knownCohortBeforeJobSeconds':25120,'absoluteDeadline':'2026-11-12T18:02:37.530402+00:00','latestNativeDispatch':'2026-11-12T16:52:37.530402+00:00','costUsd':None}
seen=set()
for run in runs['workflow_runs']:
 assert run['head_sha']==SOURCE
 if run['name']not in expected:summary['alerts'].append('Unexpected workflow '+run['name'])
 if run['name']in seen:summary['alerts'].append('Duplicate workflow '+run['name'])
 seen.add(run['name'])
 if run['run_attempt']!=1 or run['event']!='push':summary['alerts'].append('Unexpected attempt/event '+str(run['id']))
 jobs=api(f"repos/p2ppsr/interop/actions/runs/{run['id']}/jobs?per_page=100",f"run-{run['id']}-jobs");assert jobs['total_count']<=100
 row={'id':run['id'],'name':run['name'],'status':run['status'],'conclusion':run['conclusion'],'createdAt':run['created_at'],'jobs':[],'completedJobSeconds':0,'inProgressElapsedSeconds':0}
 for job in jobs['jobs']:
  js={'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'startedAt':job['started_at'],'completedAt':job['completed_at'],'failedSteps':[s['name']for s in job['steps']if s['conclusion']=='failure'],'activeSteps':[s['name']for s in job['steps']if s['status']=='in_progress']}
  if job['started_at']:
   start=datetime.datetime.fromisoformat(job['started_at'].replace('Z','+00:00'))
   if job['completed_at']:
    end=datetime.datetime.fromisoformat(job['completed_at'].replace('Z','+00:00'));js['jobSeconds']=(end-start).total_seconds();row['completedJobSeconds']+=js['jobSeconds']
   else:js['elapsedSeconds']=(now-start).total_seconds();row['inProgressElapsedSeconds']+=js['elapsedSeconds']
   bound={'offline-core':600,'go-components':1200,'integrated-components':2400,'retained-native-evidence':1200}.get(job['name'])
   js['boundSeconds']=bound
   if bound is None:summary['alerts'].append('Unexpected job '+job['name'])
   elif js.get('jobSeconds',js.get('elapsedSeconds',0))>bound+5:summary['alerts'].append('Job bound exceeded '+str(job['id']))
  row['jobs'].append(js)
  if job['conclusion']=='failure':summary['alerts'].append('Failed job '+str(job['id']))
 summary['runs'].append(row)
summary['completedActualJobSeconds']=sum(x['completedJobSeconds']for x in summary['runs']);summary['knownCohortIncludingCompleted']=25120+summary['completedActualJobSeconds']
summary['apiFiles']=[{'path':str(p.relative_to(B)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in sorted(D.iterdir())]
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(B/'latest.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
