from pathlib import Path
import datetime,hashlib,json
base=Path(__file__).resolve().parent
source='69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7';runs={43249807860:'Foundation checks',43249807970:'Retained native evidence reevaluation'}
bounds={'offline-core':600,'go-components':1200,'integrated-components':2400,'retained-native-evidence':1200}
sha=lambda b:hashlib.sha256(b).hexdigest()
enum=json.loads((base/'source-runs-terminal.json').read_bytes());assert enum['total_count']==2 and {r['id'] for r in enum['workflow_runs']}==set(runs)
workflows=[];total=0;seen=set();inputs=[]
for run,name in runs.items():
 d=base/str(run);meta=json.loads((d/'run-api.json').read_bytes());jobs=json.loads((d/'jobs-api.json').read_bytes());assert meta['head_sha']==source and meta['run_attempt']==1 and meta['status']=='completed' and meta['event']=='push' and meta['name']==name
 assert jobs['total_count']==len(jobs['jobs']);rows=[]
 for j in jobs['jobs']:
  assert j['name'] in bounds and j['name'] not in seen and j['status']=='completed';seen.add(j['name'])
  t=lambda v:datetime.datetime.fromisoformat(v.replace('Z','+00:00'))
  secs=(t(j['completed_at'])-t(j['started_at'])).total_seconds();assert secs>=0 and secs<=bounds[j['name']]+5
  total+=secs;rows.append({'id':j['id'],'name':j['name'],'conclusion':j['conclusion'],'startedAt':j['started_at'],'completedAt':j['completed_at'],'jobSeconds':secs,'boundJobSeconds':bounds[j['name']],'failedSteps':[s['name']for s in j['steps']if s['conclusion']not in[None,'success','skipped']]})
 workflows.append({'id':run,'name':name,'source':source,'event':'push','attempt':1,'conclusion':meta['conclusion'],'jobSeconds':sum(x['jobSeconds']for x in rows),'jobs':rows})
 for n in ['run-api.json','jobs-api.json','artifacts-api.json','acquisition.json']:
  p=d/n;inputs.append({'path':p.relative_to(base).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
assert seen==set(bounds)
r={'schema':'tpnil-ci-cost-closeout@1','source':source,'workflows':workflows,'knownJobWallSeconds':total,'completedCohortJobSecondsBeforeIncrement':25120,'completedCohortJobSecondsAfterIncrement':25120+total,'monetaryCosts':{'actualCIChargeUSD':None,'storageAndEgressUSD':None,'operatorEffortUSD':None,'developmentAgentUsageUSD':None,'allocatedOwnedCapacityUSD':None,'totalFullCostUSD':None},'newPaidCapacityReservations':0,'unknownCostsAreZero':False,'fullCostReconciled':False,'nativeQualification':False,'currentCandidateNativeSessionsInTheseWorkflows':0,'nativeDispatchIsSeparatelyRecorded':True,'workOrder':{'repository':'network-ops','commit':'3eafaf64c09da6b9d3adea42ba05bd84019abfcd','path':'artifacts/ops/itcve-native-closure-20261111/attempt-7-completion-order/work-order.json','sha256':'74845f47f71a435e0b21facc02cb5aa44024ae7a8963104009461145d2a18335','totalJobSecondEnvelope':9600,'ciEnvelope':5400,'nativeEnvelope':4200,'deadline':'2026-11-12T18:02:37.530402+00:00','latestNativeDispatch':'2026-11-12T16:52:37.530402+00:00'},'inputs':inputs}
p=base/'cost-summary.json';data=(json.dumps(r,indent=2)+'\n').encode()
if p.exists():assert p.read_bytes()==data,'Existing cost summary differs'
else:p.write_bytes(data)
print(json.dumps({'verified':True,'ciJobSeconds':total,'completedCohortJobSeconds':25120+total,'costSummarySha256':sha(data)}))
