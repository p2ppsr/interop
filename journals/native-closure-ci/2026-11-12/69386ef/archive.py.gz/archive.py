from pathlib import Path
import gzip,hashlib,json,shutil
src=Path(__file__).resolve().parent;root=src.parents[2];dest=root/'journals/native-closure-ci/2026-11-12/69386ef'
assert not dest.exists();assert (src/'cost-summary.json').exists();assert (src/'43249807860/independent-intake-review.json').exists()
rows=[];dest.mkdir(parents=True)
excluded={'archive-verification.json','archive-mutation-review.json'}
for f in sorted(src.rglob('*')):
 if not f.is_file()or f.is_symlink()or '__pycache__'in f.parts or 'original'in f.relative_to(src).parts or f.name in excluded or f.suffix=='.pyc':continue
 rel=f.relative_to(src).as_posix();raw=f.read_bytes();encoding='identity'if f.suffix=='.zip'else'gzip';stored=raw if encoding=='identity'else gzip.compress(raw,mtime=0);target=rel+(''if encoding=='identity'else'.gz');p=dest/target;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(stored)
 rows.append({'path':target,'originalPath':rel,'encoding':encoding,'bytes':len(stored),'sha256':hashlib.sha256(stored).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest()})
canonical=json.dumps(rows,sort_keys=True,separators=(',',':')).encode();verifier=(src/'verify-template.py').read_text().replace('__INVENTORY__',hashlib.sha256(canonical).hexdigest()).replace('__COST__',hashlib.sha256((src/'cost-summary.json').read_bytes()).hexdigest());(dest/'verify.py').write_text(verifier)
cost=json.loads((src/'cost-summary.json').read_bytes());(dest/'README.md').write_text(f'''# Exact-source completion CI evidence

Source `{cost['source']}` triggered one Foundation run43249807860 and one retained source7 replay43249807970. Original terminal APIs, all complete job/workflow logs, original artifact ZIPs, exact member inventories and independent intake reviews are retained. Extraction copies are omitted because their exact bytes are in the original ZIPs. Read-only monitoring snapshots and the prior bounded order are retained separately from completed execution receipts.

Actual completed CI cost is {cost['knownJobWallSeconds']:g} job-seconds, advancing this work cohort from25,120 to{cost['completedCohortJobSecondsAfterIncrement']:g}. Monetary charges, allocated capacity, storage/egress, operator effort and development-agent usage remain unknown. Zero external capacity reservations are not zero full cost. Native7 execution, if separately admitted, is outside this CI archive.

Core CI reports203 passes and1 explicit skip; synthesis reports1,675 passes and120 explicit skips. These are the CI selections, not the broader local1705-pass/90-skip engineering result. Independent Foundation review records required separate job tests, complete semantic receipts and known component findings without converting failed assertions to passes.

Source7 is replay of historical native evidence: each original native vector remains180PASS/99FAIL/1BLOCKED, integrated77PASS and revised Rust48PASS. Original Rust remains42PASS/6FAIL; its second repetition was not executed. All16 child logs retain complete structured receipts. There are zero new native wallet sessions and no complete BRC100 conformance claim in these workflows.

Run `python3 verify.py` to check the exact pinned inventory, all retained bytes, GitHub artifact digests/member hashes, terminal cost arithmetic, and nonempty source7 child receipts. This verifier does not rerun frozen semantic oracles or confer native qualification. Executable independent intake checkers are also retained with their original scope; some require the repository's committed source/archive objects.
''')
(dest/'verify.py').write_text((dest/'verify.py').read_text().replace('__README__',hashlib.sha256((dest/'README.md').read_bytes()).hexdigest()))
for name in ['README.md','verify.py']:
 b=(dest/name).read_bytes();rows.append({'path':name,'originalPath':name,'encoding':'identity','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'originalBytes':len(b),'originalSha256':hashlib.sha256(b).hexdigest(),'generated':True})
m={'schema':'tpnil-native-ci-archive-manifest@3','source':cost['source'],'claim':'CI_EXECUTION_AND_RETAINED_EVIDENCE_REVIEW_ONLY','files':rows};p=dest/'manifest.json';p.write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'archive':str(dest),'manifestSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(rows),'storedBytes':sum(x['bytes']for x in rows)}))
