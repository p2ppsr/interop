#!/usr/bin/env python3
"""Offline reproduction of the independent intake checks; no network or semantic rerun."""
from pathlib import Path
import json, hashlib, zipfile, subprocess

root = Path.cwd()
base = Path(__file__).resolve().parent
r = base / 'original/13958338775'
H = lambda b: hashlib.sha256(b).hexdigest()
a = json.loads((base / 'acquisition.json').read_text())
assert a['source'] == '69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7'
assert a['conclusion'] == 'success'
for f in a['files'] + a['apis']:
    b = (base / f['path']).read_bytes()
    assert len(b) == f['bytes'] and H(b) == f['sha256']
    if 'artifactId' in f:
        z = zipfile.ZipFile(base / f['path'])
        assert len(z.infolist()) == len(f['members'])
        assert len(set(z.namelist())) == len(z.namelist())
        for m in f['members']:
            b = z.read(m['path'])
            assert len(b) == m['bytes'] and H(b) == m['sha256']
            assert b == (base / f"original/{f['artifactId']}" / m['path']).read_bytes()
m = json.loads((r / 'manifest.json').read_text())
paths = []
for f in m['files']:
    p = f['path']
    assert p not in paths and not p.startswith('/') and '..' not in Path(p).parts
    paths.append(p)
    b = (r / p).read_bytes()
    assert len(b) == f['size'] and H(b) == f['sha256']
assert set(paths) == {p.relative_to(r).as_posix() for p in r.rglob('*') if p.is_file()} - {'manifest.json'}
rv = json.loads((r / 'reevaluation.json').read_text())
lock = json.loads((r / 'run-lock.json').read_text())
assert rv['evaluatorSource'] == a['source'] == lock['evaluatorSource']
assert lock['sourceDirty'] is False
plan_bytes = subprocess.check_output(['git', 'show', a['source'] + ':' + lock['planPath']], cwd=root)
assert json.loads(plan_bytes) == lock['plan']
assert H(plan_bytes) == lock['planSha256'] == rv['planSha256']
for p, s in lock['plan']['evaluatorSources'].items():
    assert H(subprocess.check_output(['git', 'show', a['source'] + ':' + p], cwd=root)) == s
zbytes = (r / 'original-native.zip').read_bytes()
assert H(zbytes) == rv['original']['sha256'] and len(zbytes) == rv['original']['size']
assert zbytes == (root / lock['plan']['original']['archive']).read_bytes()
z = zipfile.ZipFile(r / 'original-native.zip')
assert len(z.infolist()) == 186
for f in z.infolist():
    assert z.read(f.filename) == (r / 'original' / f.filename).read_bytes()
assert rv['newNativeSessions'] == 0 and rv['originalMembersUnchanged']
assert rv['qualifiedRetainedEvidence'] and rv['completeBRC100Conformance'] is False
assert [rv[k] for k in ['nativeOutcome', 'integrationOutcome', 'rustOutcome', 'outcome']] == ['FAIL', 'PASS', 'PASS', 'FAIL']
assert len(rv['repetitions']) == 2 and [q['index'] for q in rv['repetitions']] == [1, 2]
for rep in rv['repetitions']:
    assert rep['native']['assertions'] == 280 and rep['native']['counts'] == {'PASS': 180, 'FAIL': 99, 'BLOCKED': 1}
    assert len(rep['assertions']) == 77 and len({x['id'] for x in rep['assertions']}) == 77
    assert all(x['result'] == 'PASS' for x in rep['assertions'])
    assert rep['rust']['assertions'] == 48 and rep['rust']['counts'] == {'PASS': 48, 'FAIL': 0, 'BLOCKED': 0}
assert rv['original']['rust'][0]['counts'] == {'PASS': 42, 'FAIL': 6, 'BLOCKED': 0}
assert rv['original']['rust'][1]['status'] == 'NOT_EXECUTED'
children = []
for p in sorted((r / 'logs').glob('*')):
    t = p.read_text()
    found = []
    for i, c in enumerate(t):
        if c != '{':
            continue
        try:
            obj, n = json.JSONDecoder().raw_decode(t[i:])
            if not t[i + n:].strip():
                found.append(obj)
        except json.JSONDecodeError:
            pass
    assert len(found) == 1
    x = found[0]
    if '-run.log' in p.name:
        assert x['schema'] == 'tpnil-component-result@1' and len(x['assertions']) == 48
        assert all(q['result'] == 'PASS' for q in x['assertions'])
    else:
        assert x['verified'] is True
    children.append({'path': p.relative_to(r).as_posix(), 'sha256': H(p.read_bytes()), 'bytes': p.stat().st_size, 'nonemptyStructuredReceipt': True})
assert len(children) == 16
review = json.loads((base / 'independent-intake-review.json').read_text())
assert review['children'] == children
assert review['manifestEntries'] == len(paths) == 219
assert review['source7PlanSha256'] == rv['planSha256']
assert review['acquisitionSha256'] == H((base / 'acquisition.json').read_bytes())
assert review['repetitions'] == [{'index': q['index'], 'native': q['native']['counts'], 'integration': q['counts'], 'rust': q['rust']['counts']} for q in rv['repetitions']]
print(json.dumps({'verified': True, 'claim': 'INDEPENDENT_INTAKE_ONLY', 'source': a['source'], 'manifestEntries': len(paths), 'childReceipts': len(children), 'originalMembers': 186, 'newNativeSessions': 0, 'completeBRC100Conformance': False}))
