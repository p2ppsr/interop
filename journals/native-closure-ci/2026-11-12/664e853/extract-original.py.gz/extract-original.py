from pathlib import Path
import json,hashlib,zipfile
B=Path(__file__).resolve().parent/'acquisition/43260409136';A=json.loads((B/'acquisition.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for a in A['files']:
 if not a.get('artifactId'):continue
 p=B/a['path'];assert sha(p.read_bytes())==a['sha256'];d=B/'original'/str(a['artifactId']);assert not d.exists();d.mkdir(parents=True)
 with zipfile.ZipFile(p)as z:
  for m in a['members']:
   q=Path(m['path']);assert not q.is_absolute()and'..'not in q.parts;raw=z.read(m['path']);assert len(raw)==m['bytes']and sha(raw)==m['sha256'];f=d/q;f.parent.mkdir(parents=True,exist_ok=True);assert not f.exists();f.write_bytes(raw)
  assert {f.relative_to(d).as_posix()for f in d.rglob('*')if f.is_file()}=={m['path']for m in a['members']}
 rows.append({'artifactId':a['artifactId'],'artifactName':a['artifactName'],'directory':str(d),'members':len(a['members'])})
r={'schema':'tpnil-ci-original-extraction@1','source':A['source'],'run':A['run'],'acquisitionSha256':sha((B/'acquisition.json').read_bytes()),'artifacts':rows};p=B/'extraction.json';assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
