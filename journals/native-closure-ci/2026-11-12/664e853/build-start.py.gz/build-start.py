from pathlib import Path
import json,hashlib,subprocess,shutil,datetime
B=Path(__file__).resolve().parent;R=B.parents[2];O=Path('/Users/tyeverett/projects/network-ops');D=O/'artifacts/ops/itcve-native-closure-20261111/attempt-8-ci-start';order=O/'artifacts/ops/itcve-native-closure-20261111/attempt-8-selector-recovery-order/work-order.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected='10efe6d10442a4278eccf4912f50b01b583db9d9ceaa4118bd36e864e7475614';assert sha(order.read_bytes())==expected
o=json.loads(order.read_bytes());s=json.loads((B/'latest.json').read_bytes());assert s['source']==o['source'] and s['totalRuns']==1 and not s['alerts'];run=s['runs'][0];assert run['id']==43260409136 and run['name']=='Foundation checks'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==o['source']
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()==''
opsHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=O,text=True).strip();assert opsHead=='ebf2dc2e7b8867c568d9c760f33b92c55b8c2098'
assert subprocess.check_output(['git','rev-parse','origin/master'],cwd=O,text=True).strip()==opsHead
assert subprocess.check_output(['git','status','--porcelain'],cwd=O,text=True).strip()==''
for p,h in o['committedInputs'].items():assert sha((R/p).read_bytes())==h,p
D.mkdir();raw=D/'raw';raw.mkdir()
for row in s['apiFiles']:
 p=B/row['path'];assert sha(p.read_bytes())==row['sha256'];shutil.copyfile(p,raw/p.name)
shutil.copyfile(B/'latest.json',D/'capture-summary.json');shutil.copyfile(__file__,D/'build-start.py');shutil.copyfile(B/'poll.py',D/'monitor.py')
receipt={'schema':'network-ops-native-closure-ci-start@1','capturedAt':s['capturedAt'],'source':o['source'],'sourceRepository':'p2ppsr/interop','opsAdmissionCommit':opsHead,'order':str(order.relative_to(O)),'orderSha256':expected,'workflow':run,'automaticRunsObserved':1,'newSource7RunsObserved':0,'nativeDispatchObserved':False,'runtimeAndCarryInputHashesVerified':len(o['committedInputs']),'nativeSourceInputs':o['nativeInputs'],'foundationMaximumJobSeconds':4200,'nativeMaximumJobSecondsReserved':4200,'completedCohortJobSecondsBefore':26968,'completedNewJobSecondsAtCapture':0,'activeElapsedJobSecondsAtCapture':run['inProgressElapsedSeconds'],'activeElapsedIsNotTerminalActual':True,'carriedSource7':{'run':43249807970,'alreadyCountedJobSeconds':135,'newChargeAttributed':False},'absoluteDeadline':o['deadline'],'latestNativeDispatchAt':o['latestNativeDispatchAt'],'nativePrerequisite':'Exact-source Foundation SUCCESS and all independent admission checks before root performs one dispatch; full4200 seconds must fit.','cancellationOwner':o['cancellationOwner'],'actualCIChargeUSD':None,'totalFullCostUSD':None,'unknownCostsAreZero':False,'nativeQualification':False,'automaticRetries':0,'alerts':[]}
(D/'start.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(D.rglob('*'))if p.is_file()]
manifest={'schema':'network-ops-ci-start-file-inventory@1','files':files,'source':o['source'],'orderSha256':expected};(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'path':str(D),'startSha256':sha((D/'start.json').read_bytes()),'manifestSha256':sha((D/'manifest.json').read_bytes()),'files':len(files)}))
