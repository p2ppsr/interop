from pathlib import Path
import sys,json,subprocess,hashlib
B=Path(__file__).resolve().parent/'acquisition'/'43260409136';B.mkdir(parents=True,exist_ok=True)
for job in map(int,sys.argv[1:]):
 def get(s):
  p=subprocess.run(['gh','api',s],capture_output=True,timeout=55)
  assert p.returncode==0,p.stderr.decode();return p.stdout
 raw=get(f'repos/p2ppsr/interop/actions/jobs/{job}');m=json.loads(raw)
 assert m['run_id']==43260409136 and m['head_sha']=='664e8539031109174e7233390262d76ca6c81240' and m['status']=='completed'
 j=B/f'job-{job}-api.json';p=B/f'job-{job}.log'
 assert not j.exists(),j;j.write_bytes(raw)
 if not p.exists():p.write_bytes(get(f'repos/p2ppsr/interop/actions/jobs/{job}/logs'))
 print(json.dumps({'job':job,'conclusion':m['conclusion'],'log':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
