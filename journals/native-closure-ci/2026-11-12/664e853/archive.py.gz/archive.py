from pathlib import Path
import gzip,hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[2];D=R/'journals/native-closure-ci/2026-11-12/664e853';sha=lambda b:hashlib.sha256(b).hexdigest()
assert not D.exists();assert(S/'cost-summary.json').exists()and(S/'acquisition/43260409136/independent-intake-review.json').exists();D.mkdir(parents=True)
rows=[]
for f in sorted(S.rglob('*')):
 if not f.is_file()or f.is_symlink()or '__pycache__'in f.parts or 'original'in f.relative_to(S).parts or f.suffix=='.pyc' or f.name.startswith('archive-verification')or f.name.startswith('archive-mutation'):continue
 rel=f.relative_to(S).as_posix();raw=f.read_bytes();enc='identity'if f.suffix=='.zip'else'gzip';stored=raw if enc=='identity'else gzip.compress(raw,mtime=0);target=rel+(''if enc=='identity'else'.gz');p=D/target;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(stored);rows.append({'path':target,'originalPath':rel,'encoding':enc,'bytes':len(stored),'sha256':sha(stored),'originalBytes':len(raw),'originalSha256':sha(raw)})
cost=json.loads((S/'cost-summary.json').read_bytes())
readme=f'''# Selector recovery Foundation CI

Exact source `{cost['source']}` completed Foundation run43260409136 successfully. The immutable archive retains raw terminal APIs, all full job/workflow logs, all3 original artifact ZIPs and262 exact member hashes, safe extraction receipts, complete monitoring snapshots and independent technical intake review. Extraction duplicates are omitted; original bytes remain in the ZIPs.

Actual cost is1410 job-seconds (offline388, Go253, integrated769), advancing the known cohort from26968 to28378. Monetary charges, storage/egress, allocated owned capacity, operator effort and development-agent usage remain unknown. No new source7 run occurred: prior43249807970/135seconds is already counted and carried only under the separately reviewed unchanged closure. One later native attempt requires its own recorded dispatch; this Foundation archive contains zero native wallet sessions and no native qualification.

Offline CI selected213 passing core tests and1 skip (214 total),1675 passing synthesis tests and120 skips (1795 total), and5 Python tests. Go selected13 passing tests. These selections differ from the broader local214/1705/90-skip engineering gates. Complete integration receipts retain584 passing and6 failing assertions; those known component findings remain failures. Independent technical review records the other required job-specific test and semantic replay counts.

Run `python3 verify.py` for exact inventory and physical file verification, all original ZIP/member digest checks, independently rederived terminal job-seconds, exact raw count controls and nonempty source-bound semantic receipts. This is archive verification, not a new semantic/native execution. When checking a copied archive with a trusted external verifier, pass its path as the positional argument. The archived generated verifier must match that trusted executing verifier; Git or an external manifest/code hash remains the root of trust.
''';(D/'README.md').write_text(readme)
verifier=(S/'verify-template.py').read_text().replace('__INVENTORY__',sha(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())).replace('__COST__',sha((S/'cost-summary.json').read_bytes())).replace('__README__',sha((D/'README.md').read_bytes()));(D/'verify.py').write_text(verifier)
for name in ['README.md','verify.py']:
 b=(D/name).read_bytes();rows.append({'path':name,'originalPath':name,'encoding':'identity','bytes':len(b),'sha256':sha(b),'originalBytes':len(b),'originalSha256':sha(b),'generated':True})
m={'schema':'tpnil-native-ci-archive-manifest@4','source':cost['source'],'claim':'CI_EXECUTION_AND_RETAINED_EVIDENCE_REVIEW_ONLY','files':rows};(D/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'archive':str(D),'manifestSha256':sha((D/'manifest.json').read_bytes()),'files':len(rows),'storedBytes':sum(r['bytes']for r in rows)}))
