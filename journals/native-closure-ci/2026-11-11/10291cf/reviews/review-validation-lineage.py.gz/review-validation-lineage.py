from pathlib import Path
import json,gzip,hashlib
r=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest()
names=['2026-11-11','2026-11-11-container-closure','2026-11-11-candidate-label'];digests=['541c0ed81515a5712183c49e2401e40eee575a0007f2f4ac0881eceb5dc4adf7','c78c40b851036aaab79a36e28f9c72204600f6795e7373169703bb8d78579011','d1eb1b0dbdfb7ad473df6e8a5c42e07e4ce14437bfc9fc6a5258c1aff68496fd'];bases=[r/'journals/native-closure-validation'/name for name in names];values=[];logs={};archives=[]
for index,(base,digest) in enumerate(zip(bases,digests)):
 manifest=base/'validation.json';assert sha(manifest.read_bytes())==digest;v=json.loads(manifest.read_text());values.append(v);assert v['claim']=='LOCAL_ENGINEERING_PREFLIGHT_ONLY' and v['nativeSessions']==0
 if index:assert v['predecessor']=={'path':str((bases[index-1]/'validation.json').relative_to(r)),'sha256':digests[index-1]}
 files={}
 for item in v['files']:
  file=base/item['path'];assert file.resolve().is_relative_to(base.resolve()) and not file.is_symlink();data=file.read_bytes();assert sha(data)==item['sha256'] and len(data)==item['bytes'];files[item['path']]={'sha256':sha(data),'bytes':len(data)}
  if item['path'].endswith('.gz'):
   assert data[4:8]==b'\x00'*4;raw=gzip.decompress(data);assert sha(raw)==item['rawSha256'] and len(raw)==item['rawBytes'];files[item['path']].update(rawSha256=sha(raw),rawBytes=len(raw));logs[(index,item['path'])]=raw.decode()
 assert {str(p.relative_to(base))for p in base.rglob('*')if p.is_file()}==set(files)|{'validation.json','README.md'}
 archives.append({'path':str(base.relative_to(r)),'manifestSha256':digest,'files':files,'metadata':{name:sha((base/name).read_bytes())for name in ['validation.json','README.md']}})
old,container,label=values
assert len(old['sourceInputs'])==99 and len(container['sourceInputs'])==100 and len(label['sourceInputs'])==101
assert set(container['sourceInputs'])==set(old['sourceInputs'])|{'test/native-container-source-closure.test.mjs'}
assert set(label['sourceInputs'])==set(container['sourceInputs'])|{'test/native-candidate-artifact.test.mjs'}
for name,digest in label['sourceInputs'].items():assert sha((r/name).read_bytes())==digest,name
changedContainer={name for name,digest in old['sourceInputs'].items()if container['sourceInputs'][name]!=digest}
changedLabel={name for name,digest in container['sourceInputs'].items()if label['sourceInputs'][name]!=digest}
assert changedContainer=={'infra/native/conformance/'+x for x in ['Dockerfile','plan-5.1.1-observer-2.json','plan-pr368-7e39006.json','rust-graph-5.1.1-selector-2.json','rust-graph-pr368-7e39006.json']}
assert changedLabel=={'infra/native/conformance/plan-pr368-7e39006.json','infra/native/conformance/rust-graph-pr368-7e39006.json'}
for index,changed in [(1,changedContainer),(2,changedLabel)]:
 for name in changed:assert sha((bases[index]/'before'/Path(name).name).read_bytes())==values[index-1]['sourceInputs'][name]
# Reconstruct the container-stage logical files from its successor's retained copies.
def containerBytes(name):return (bases[2]/'before'/Path(name).name).read_bytes() if name in changedLabel else (r/name).read_bytes()
for name,digest in container['sourceInputs'].items():assert sha(containerBytes(name))==digest,name
for name in ['plan-5.1.1-observer-2.json','plan-pr368-7e39006.json']:
 a=json.loads((bases[1]/'before'/name).read_text());b=json.loads(containerBytes('infra/native/conformance/'+name));a['conformanceInputs']['infra/native/conformance/Dockerfile']=container['sourceInputs']['infra/native/conformance/Dockerfile'];assert a==b
for rust,plan in [('rust-graph-5.1.1-selector-2.json','plan-5.1.1-observer-2.json'),('rust-graph-pr368-7e39006.json','plan-pr368-7e39006.json')]:
 a=json.loads((bases[1]/'before'/rust).read_text());b=json.loads(containerBytes('infra/native/conformance/'+rust));a['nativePlan']['sha256']=sha(containerBytes('infra/native/conformance/'+plan));assert a==b
added=['COPY infra/native/yours-go /work/infra/native/yours-go','COPY .github/workflows/isi4-yours-wallet.yml /work/.github/workflows/isi4-yours-wallet.yml','COPY synthesis/go/cmd /work/synthesis/go/cmd','COPY scripts/native-wallet-profiles.mjs scripts/native-rust-compatibility.mjs scripts/run-native-go-wallet.mjs scripts/verify-native-integrated.mjs scripts/prepare-yours-wallet-run.sh /work/scripts/'];docker=(r/'infra/native/conformance/Dockerfile').read_text()
for line in added:assert docker.count(line+'\n')==1;docker=docker.replace(line+'\n','')
assert docker==(bases[1]/'before/Dockerfile').read_text()
a=json.loads((bases[2]/'before/plan-pr368-7e39006.json').read_text());b=json.loads((r/'infra/native/conformance/plan-pr368-7e39006.json').read_text());assert a['id']=='YOURS-PR368-F9FAA-GO-ITCVE-1-V4.1.0-ENGINEERING';a['id']='YOURS-PR368-7E39006-GO-ITCVE-1-V4.1.0-ENGINEERING';assert a==b
a=json.loads((bases[2]/'before/rust-graph-pr368-7e39006.json').read_text());b=json.loads((r/'infra/native/conformance/rust-graph-pr368-7e39006.json').read_text());a['nativePlan']['sha256']=sha((r/'infra/native/conformance/plan-pr368-7e39006.json').read_bytes());assert a==b
for i,name,count in [(1,'container-source-closure-final.log.gz',5),(1,'container-closure-core-final.log.gz',147),(2,'focused.log.gz',5)]:
 text=logs[(i,name)];assert f'ℹ tests {count}\n' in text and f'ℹ pass {count}\n' in text and 'ℹ fail 0\n' in text and 'ℹ skipped 0\n' in text
assert container['results']['negativeContainerMutations']==6
assert '629 passed | 8 skipped (637)' in logs[(0,'expanded-synthesis-final.log.gz')]
receipt={'schema':'tpnil-native-closure-validation-lineage-review@1','claim':'READ_ONLY_ENGINEERING_SOURCE_AND_ARCHIVE_REVIEW','result':'PASS','reviewerScriptSha256':sha(Path(__file__).read_bytes()),'archives':archives,'currentSourceInputsVerified':101,'historicalSourceCopiesVerified':7,'exactRuntimeSourceChangesAfterInitialValidation':0,'containerChange':'Four explicit COPY lines only; both source-bound plan Docker digests and paired Rust plan digests updated.','candidateLabelChange':'Only obsolete display ID corrected F9FAA→7E39006 and paired Rust plan digest; artifact tuple unchanged.','currentPlanHashes':{name:sha((r/'infra/native/conformance'/name).read_bytes())for name in ['plan-5.1.1-observer-2.json','plan-pr368-7e39006.json']},'results':{'corePassed':147,'containerFocusedPassed':5,'candidateLabelFocusedPassed':5,'missingCopyMutationsRejected':6,'retainedSynthesisPassed':629,'retainedSynthesisGatedSkip':8},'dockerReview':['All declared frozen inputs resolve to exact /work paths through base/integrated/conformance COPY layers.','Base-specific Docker ignore permits base sources; later layers have no ignore removing new paths.','Go runtime host-source inventory includes command sources and preparer/RPC test inputs.'],'limitations':['Static packaging verification is not an actual Linux image build.','No native qualification, new native session or economic improvement is claimed.']}
p=r/'out/native-closure-20261111/review-validation-lineage.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'result':'PASS','receiptSha256':sha(p.read_bytes()),'archives':3,'sourceInputs':101,'beforeFiles':7},indent=2))
