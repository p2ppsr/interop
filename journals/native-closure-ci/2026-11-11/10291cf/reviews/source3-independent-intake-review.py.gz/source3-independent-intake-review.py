from pathlib import Path
import json,hashlib,zipfile,re,collections
root=Path.cwd();b=root/'out/native-closure-20261111/ci-final/43157083517';d=b/'native-integrated-reevaluation-extracted'
sha=lambda x:hashlib.sha256(x).hexdigest();read=lambda p:json.loads(p.read_text())
run=read(b/'run.json');assert run['id']==43157083517 and run['head_sha']=='e7a4b536d851c08a8b1fc3c6537141dac79615c4' and run['conclusion']=='success'
artifacts=read(b/'artifacts.json')['artifacts'];inventory=read(b/'zip-inventory.json');zips=[]
for entry in inventory:
 p=b/entry['zip'];raw=p.read_bytes();assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  members=[{'path':n.filename,'bytes':len(z.read(n)),'sha256':sha(z.read(n))}for n in z.infolist()if not n.is_dir()]
  assert members==entry['members']
  if entry['zip']!='logs.zip':
   artifact=next(a for a in artifacts if a['name']+'.zip'==entry['zip']);assert artifact['digest']=='sha256:'+sha(raw) and not artifact['expired']
   extracted=b/(entry['zip'][:-4]+'-extracted')
   for m in members:assert sha((extracted/m['path']).read_bytes())==m['sha256']
 zips.append({'path':entry['zip'],'sha256':sha(raw),'members':len(members)})
manifest=read(d/'manifest.json');assert manifest['schema']=='tpnil-native-reevaluation-inventory@1'
for row in manifest['files']:
 data=(d/row['path']).read_bytes();assert len(data)==row['size'] and sha(data)==row['sha256']
lock=read(d/'run-lock.json');result=read(d/'reevaluation.json');assert result['evaluatorSource']==run['head_sha']==lock['evaluatorSource'];assert result['newNativeSessions']==0 and result['originalMembersUnchanged'] is True and result['completeBRC100Conformance'] is False
original=root/'journals/integrated-native-attempts/2026-11-09/42711700295/native-integrated.zip';raw=(d/'original-native.zip').read_bytes();assert raw==original.read_bytes();assert sha(raw)==result['original']['sha256']
with zipfile.ZipFile(original) as z:
 files=[n for n in z.infolist()if not n.is_dir()];assert len(files)==186
 for n in files:assert z.read(n)==(d/'original'/n.filename).read_bytes()
 assert {str(p.relative_to(d/'original'))for p in (d/'original').rglob('*')if p.is_file()}=={n.filename for n in files}
def counts(a):return {k:sum(x.get('result',x.get('outcome'))==k for x in a)for k in ['PASS','FAIL','BLOCKED']}
for rep in result['repetitions']:
 assert len(rep['assertions'])==77 and counts(rep['assertions'])=={'PASS':77,'FAIL':0,'BLOCKED':0}
 record=read(d/f"original/repetition-{rep['index']}/record.json");assert sha((d/f"original/repetition-{rep['index']}/record.json").read_bytes())==rep['recordSha256']
 assertions=[a for v in record['vectors']for a in v['assertions']];assert len(assertions)==280 and counts(assertions)==rep['native']['counts']=={'PASS':180,'FAIL':99,'BLOCKED':1}
 rust=read(d/f"rust-repetition-{rep['index']}/result.json");assert len(rust['assertions'])==48 and counts(rust['assertions'])==rep['rust']['counts']=={'PASS':48,'FAIL':0,'BLOCKED':0}
 assert sha((d/f"rust-repetition-{rep['index']}/result.json").read_bytes())==rep['rust']['resultSha256']
receipts=[]
for p in sorted((d/'logs').glob('*.log')):
 text=p.read_text();value=None
 for match in reversed(list(re.finditer(r'^\{',text,re.M))):
  try:value=json.loads(text[match.start():].strip());break
  except ValueError:pass
 assert value is not None,p.name
 if '-run.' in p.name:assert value['schema']=='tpnil-component-result@1' and value['corpus']=='tpnil-rust-corpus@3' and value['outcome']=='PASS'
 else:assert value['verified'] is True,p.name
 receipts.append({'name':p.name,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'receiptPresent':True})
assert len(receipts)==16 and result['original']['rust'][0]['counts']=={'PASS':42,'FAIL':6,'BLOCKED':0} and result['original']['rust'][1]['status']=='NOT_EXECUTED'
out={'schema':'tpnil-independent-retained-native-intake-review@1','result':'PASS','claim':'READ_ONLY_INTAKE_AND_RECEIPT_REVIEW_NOT_A_SEPARATE_SEMANTIC_REPLAY','run':run['id'],'source':run['head_sha'],'zips':zips,'manifestFiles':len(manifest['files']),'originalMembersUnchanged':186,'childReceipts':receipts,'perRepetition':{'native':{'PASS':180,'FAIL':99,'BLOCKED':1},'integration':{'PASS':77,'FAIL':0,'BLOCKED':0},'rust3':{'PASS':48,'FAIL':0,'BLOCKED':0}},'oldRustPreserved':result['original']['rust'],'newNativeSessions':0,'scriptSha256':sha(Path(__file__).read_bytes())}
p=root/'out/native-closure-20261111/source3-independent-intake-review.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'result':'PASS','receiptSha256':sha(p.read_bytes()),'originalMembers':186,'nonemptyChildReceipts':16}))
