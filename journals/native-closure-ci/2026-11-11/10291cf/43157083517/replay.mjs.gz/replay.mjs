import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { prepareFrozenComponentReplay, requireVerifierReceipt } from '../../../../scripts/frozen-component-replay.mjs'
const directory=fs.realpathSync(path.dirname(fileURLToPath(import.meta.url)))
const root=fs.realpathSync(path.resolve(directory,'../../../..'))
const output=path.join(directory,'native-integrated-reevaluation-extracted')
const lock=JSON.parse(fs.readFileSync(path.join(output,'run-lock.json'),'utf8'))
const source=prepareFrozenComponentReplay(root,lock.evaluatorSource,path.join(directory,'frozen-source'))
const hash=v=>createHash('sha256').update(v).digest('hex')
const inventory=()=>JSON.parse(fs.readFileSync(path.join(output,'manifest.json'),'utf8')).files.map(row=>({path:row.path,sha256:hash(fs.readFileSync(path.join(output,row.path)))}))
const before=inventory()
const args=[path.join(source.root,'scripts/verify-native-reevaluation.mjs'),output]
const env={...process.env,TPNIL_REPLAY_GIT_ROOT:root,TPNIL_MESSAGING_PATHS:path.join(root,'out/messaging-native-verifier/paths.json'),RUSTUP_TOOLCHAIN:'1.88.0',CARGO_NET_OFFLINE:'true'}
fs.writeFileSync(path.join(directory,'replay-source.json'),JSON.stringify({source,args,node:process.version,environment:Object.fromEntries(['TPNIL_REPLAY_GIT_ROOT','TPNIL_MESSAGING_PATHS','RUSTUP_TOOLCHAIN','CARGO_NET_OFFLINE'].map(key=>[key,env[key]]))},null,2)+'\n',{flag:'wx'})
const start=Date.now(),run=spawnSync(process.execPath,args,{cwd:source.root,env,encoding:'utf8',maxBuffer:64*1024*1024})
fs.writeFileSync(path.join(directory,'replay-stdout.json'),run.stdout,{flag:'wx'})
fs.writeFileSync(path.join(directory,'replay-stderr.log'),run.stderr,{flag:'wx'})
const after=inventory();assert.deepEqual(after,before)
assert.equal(run.status,0,run.stderr+'\n'+run.stdout)
const receipt=requireVerifierReceipt(run.stdout,{verified:true,evaluatorSource:lock.evaluatorSource,newNativeSessions:0,repetitions:2,nativeOutcome:'FAIL',integrationOutcome:'PASS',rustOutcome:'PASS'})
const result={verified:true,...receipt,allArtifactMembersUnchanged:true,elapsedMs:Date.now()-start,receiptSha256:hash(run.stdout),source}
fs.writeFileSync(path.join(directory,'independent-replay.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
