import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { pathToFileURL,fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { prepareFrozenComponentReplay,requireVerifierReceipt } from '../../../../scripts/frozen-component-replay.mjs'
const directory=fs.realpathSync(path.dirname(fileURLToPath(import.meta.url))),root=fs.realpathSync(path.resolve(directory,'../../../..'))
const output=path.join(directory,'integrated-lab-extracted'),lock=JSON.parse(fs.readFileSync(path.join(output,'run-lock.json'),'utf8'))
const source=prepareFrozenComponentReplay(root,lock.source,path.join(directory,'frozen-source'))
const {verifyIntegrated}=await import(pathToFileURL(path.join(source.root,'scripts/integrated-evidence.mjs')).href)
const verification=verifyIntegrated(output),result=JSON.parse(fs.readFileSync(path.join(output,'result.json'),'utf8'))
const hash=bytes=>createHash('sha256').update(bytes).digest('hex')
const walk=(dir,prefix='')=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?walk(path.join(dir,entry.name),prefix+entry.name+'/'):[{path:prefix+entry.name,sha256:hash(fs.readFileSync(path.join(dir,entry.name)))}]).sort((a,b)=>a.path.localeCompare(b.path))
const before=walk(output),receipts=[],env={...process.env,RUSTUP_TOOLCHAIN:'1.88.0',CARGO_NET_OFFLINE:'true',TPNIL_REPLAY_GIT_ROOT:root,TPNIL_MESSAGING_PATHS:path.join(root,'out/messaging-native-verifier/paths.json')}
for(const lane of result.lanes)for(const [index,run] of lane.runs.entries()){
 const target=path.dirname(path.join(output,run.result)),script=lane.id==='messaging'?'verify-messaging.mjs':lane.id==='overlay-identity'?'verify-overlay-identity.mjs':lane.id==='storage-sync'?'verify-storage-sync.mjs':lane.id==='descendant-storage-sync'?'verify-descendant-storage-matrix.mjs':lane.id==='rust'?'verify-rust.mjs':lane.id.startsWith('boundary-')?'verify-wallet-boundary.mjs':lane.id.startsWith('transport-')?'verify-transport.mjs':null
 assert.ok(script,'Unrecognized required lane')
 const inputs=lane.id==='rust'?[`transport-typescript-${index+1}/paid-http.json`,`transport-go-${index+1}/paid-http.json`,`overlay-identity-${index+1}/rust-certificate-vectors.json`].map(name=>path.join(output,name)):lane.id==='descendant-storage-sync'?['--exact-history']:[]
 const args=[path.join(source.root,'scripts',script),target,...inputs],child=spawnSync(process.execPath,args,{cwd:source.root,env,encoding:'utf8',timeout:300000,maxBuffer:16*1024*1024}),name=`${lane.id}-${index+1}`
 fs.writeFileSync(path.join(directory,`${name}-replay.stdout.log`),child.stdout,{flag:'wx'});fs.writeFileSync(path.join(directory,`${name}-replay.stderr.log`),child.stderr,{flag:'wx'})
 assert.equal(child.status,0,`${name}: ${child.stderr}\n${child.stdout}`)
 receipts.push({lane:lane.id,index:index+1,args,receipt:requireVerifierReceipt(child.stdout,lane.id==='storage-sync'?{result:'PASS',runs:8,assertions:88}:{verified:true}),stdoutSha256:hash(child.stdout),stderrSha256:hash(child.stderr)})
}
assert.equal(receipts.length,16);assert.deepEqual(walk(output),before)
const flat=result.lanes.flatMap(lane=>lane.runs.flatMap(run=>run.assertions)),counts=Object.fromEntries(['PASS','FAIL','BLOCKED'].map(v=>[v,flat.filter(a=>a.result===v).length]))
assert.deepEqual(counts,{PASS:584,FAIL:6,BLOCKED:0})
const receipt={schema:'tpnil-independent-ci-component-replay@1',verified:true,source,verification,childReceipts:receipts,counts,artifactMembersUnchanged:before.length,newNativeSessions:0,nativeQualification:false}
fs.writeFileSync(path.join(directory,'independent-component-replay.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({verified:true,counts,childReceipts:receipts.length,members:before.length}))
