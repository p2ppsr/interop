from pathlib import Path
import json,hashlib,gzip,zipfile,shutil
r=Path.cwd();b=r/'out/native-review-43285086155';a=r/'out/source4-ci/acquisition/43285086155';d=r/'journals/integrated-native-attempts/2026-11-12/43285086155';assert not d.exists();d.mkdir(parents=True);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
api=json.loads((a/'artifacts-api.json').read_bytes());assert len(api['artifacts'])==1;v=api['artifacts'][0];z=a/f"artifact-{v['id']}.zip";assert 'sha256:'+h(z)==v['digest']and z.stat().st_size==v['size_in_bytes']
keep=[a/'run-api.json',a/'jobs-api.json',a/'artifacts-api.json',z,b/'complete-workflow-logs.zip',b/'replay-audit-fix.py',b/'audit-fix-replay.json',b/'linux-storage-manifest.json',b/'image-differences.json',b/'archive.py',r/'out/source5-validation/linux-replay.log']
for p in keep:
 name=p.name;data=p.read_bytes();q=d/(name if p.suffix=='.zip'else name+'.gz');q.write_bytes(data if p.suffix=='.zip'else gzip.compress(data,mtime=0))
partial=a/'failed-api-5773f181ee6af529.stdout';full=b/'complete-workflow-logs.zip'
if partial.exists():
 raw=partial.read_bytes();complete=full.read_bytes();match=complete[:len(raw)]==raw
 (d/'read-only-download-failure.json').write_text(json.dumps({'partialBytes':len(raw),'partialSha256':h(partial),'fullZipSha256':h(full),'partialIsExactFullZipPrefix':match,'stderr':(a/'failed-api-5773f181ee6af529.stderr').read_text(),'workflowRetry':False},indent=2)+'\n')
 if not match:shutil.copyfile(partial,d/'initial-partial-download.bin')
(d/'README.md').write_text('''# Native attempt10: image audit scope failure

Run43285086155 at source dad2a6e completed all image builds. Final conformance export took5.9seconds, and the configuration/two-layer guards passed before filesystem collection. The audit compared70985base/71431final entries and failed because its expected overlay included `/opt` outside the collector's two declared roots. Wallet execution was skipped. The sole original artifact is the image audit with both complete inventories; no native artifact, new native predicates or qualification exists.

All original workflow logs are retained in the original ZIP, including the73MB assertion diagnostic. The initial read-only transfer failed; prefix/hash evidence preserves that failure against the subsequently downloaded complete ZIP. Future error output is bounded. The original sample remains FAIL.

A separately labelled packaging replay binds the Linux binary to its original host build manifest and passes only after the exact scope correction. Local-only untracked Python caches and Darwin binaries are explicitly distinguished; no platform substitution qualifies this attempt. The prospective source5 must pass its actual Linux image audit and native runs independently.

The job used877seconds; with prerequisite CI1677seconds, order11 consumed2554 and completed cohort use is35978. Full monetary and effort costs remain unknown. This closes the allocation without retry credit.
''')
(d/'verify.py').write_text('''from pathlib import Path
import json,hashlib,gzip,zipfile
r=Path(__file__).resolve().parent;m=json.loads((r/'attempt.json').read_bytes());h=lambda b:hashlib.sha256(b).hexdigest()
assert {p.name for p in r.iterdir()if p.is_file()}=={x['name']for x in m['files']}|{'attempt.json'}
for x in m['files']:assert h((r/x['name']).read_bytes())==x['sha256']and(r/x['name']).stat().st_size==x['size']
j=json.loads(gzip.decompress((r/'jobs-api.json.gz').read_bytes()));a=next(x for x in j['jobs']if x['id']==131416248320);assert a['conclusion']=='failure'
for name in ['Execute two clean isolated native repetitions and verify results','Execute and independently verify the integrated native wallet graph']:assert next(s for s in a['steps']if s['name']==name)['conclusion']=='skipped'
with zipfile.ZipFile(r/'complete-workflow-logs.zip')as z:assert z.testzip()is None;assert any(b'exporting layers 5.9s done'in z.read(n)for n in z.namelist()if 'prospective'in n)
assert m['nativeQualification']is False and m['walletExecuted']is False
print(json.dumps({'verified':True,'jobSeconds':877,'nativeSessions':0,'nativeQualification':False}))
''')
m={'schema':'tpnil-integration-attempt@1','source':'dad2a6e21c5dddc6f582db2b7ff1e3a33c5c2c7b','workflowRun':43285086155,'artifactId':None,'imageAuditArtifactId':13976075912,'claim':'OBSERVER_STARTUP_ERROR','failureClassification':'IMAGE_AUDIT_SCOPE_PARENT_ENTRY','walletExecuted':False,'newNativeSessions':0,'nativeQualification':False,'completeBRC100Conformance':False,'jobSeconds':877,'cohortJobSeconds':35978,'files':[{'name':p.name,'size':p.stat().st_size,'sha256':h(p)}for p in sorted(d.iterdir())if p.is_file()]};(d/'attempt.json').write_text(json.dumps(m,indent=2)+'\n');print('Attempt10 archive',h(d/'attempt.json'))
