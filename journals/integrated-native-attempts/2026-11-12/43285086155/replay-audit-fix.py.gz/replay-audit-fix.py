from pathlib import Path
import json,re,hashlib,zipfile,subprocess
root=Path.cwd();b=root/'out/native-review-43285086155';log=(b/'conformance-build.log').read_text();plain='\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ?','',line)for line in log.splitlines());decoder=json.JSONDecoder();candidates=[]
with zipfile.ZipFile(root/'out/source4-ci/acquisition/43285086155/artifact-13976075912.zip')as z:base=json.loads(z.read('base-filesystem.json'));actual=json.loads(z.read('final-filesystem.json'))
metadata=actual['/opt/tpnil/itcve-go-storage-caller-known-inputs.json'];binary=actual['/opt/tpnil/itcve-go-storage-caller-known-inputs']
for m in re.finditer(r'(?m)^\{',plain):
 try:d,n=decoder.raw_decode(plain[m.start():])
 except json.JSONDecodeError:continue
 if not isinstance(d,dict)or d.get('binarySha256')!=binary['sha256']:continue
 raw=(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode()
 if hashlib.sha256(raw).hexdigest()==metadata['sha256']:candidates.append((d,raw))
assert candidates,'No independent Linux build manifest matches uploaded filesystem metadata'
manifest,raw=candidates[-1];(b/'linux-storage-manifest.json').write_bytes(raw)
assert manifest['binarySha256']==binary['sha256']
overlay=json.loads((b/'host-overlay.json').read_bytes());outside=[];hostOnly=[]
for n in list(overlay):
 if n=='/opt':outside.append(n);del overlay[n]
 elif '/__pycache__'in n and n not in actual:hostOnly.append(n);del overlay[n]
# These are independently bound by the original Linux host build manifest above.
for n in ['/opt/tpnil/itcve-go-storage-caller-known-inputs','/opt/tpnil/itcve-go-storage-caller-known-inputs.json']:overlay[n]=actual[n]
expected={**base,**overlay};assert expected==actual
(b/'linux-fixed-expected.json').write_text(json.dumps(expected)+'\n')
result={'verified':True,'originalSource':'dad2a6e21c5dddc6f582db2b7ff1e3a33c5c2c7b','baseEntries':len(base),'finalEntries':len(actual),'scopeCorrection':outside,'hostOnlyExcludedUntrackedPythonCache':hostOnly,'linuxManifestSha256':hashlib.sha256(raw).hexdigest(),'binarySha256BoundToIndependentBuildManifest':binary['sha256'],'fullScopeComparison':'PASS_AFTER_EXACT_SCOPE_CORRECTION','originalAuditOutcome':'FAIL_PRESERVED','newNativeSessions':0};(b/'audit-fix-replay.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
