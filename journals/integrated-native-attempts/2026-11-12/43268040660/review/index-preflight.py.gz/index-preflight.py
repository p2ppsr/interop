from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();excluded={'preflight-files.json','index-preflight.stdout.log','index-preflight.stderr.log'};files=[]
for p in sorted(base.iterdir()):
 if p.is_symlink()or not p.is_file()or p.name in excluded:continue
 b=p.read_bytes();files.append({'path':p.name,'bytes':len(b),'sha256':H(b)})
required={'dependencies.json','verify-dependencies.mjs','guarded-replay.mjs','byte-closure-preflight.json','package-byte-audit.json','messaging-sdk-byte-closure.json','rust-dependency-byte-closure.json','dependency-byte-closure-v3.json','dependency-guard-tests-v3.json','cache-isolation.json','cache-isolation-tests.json'};assert required <= {f['path']for f in files}
out={'schema':'tpnil-native9-replay-preflight-file-index@1','source':'664e8539031109174e7233390262d76ca6c81240','nativeRun':43268040660,'phase':'PRE_ARTIFACT_REPLAY_PREPARATION_ONLY','semanticReplayExecuted':False,'predecessorPreflightSha256':H((base/'byte-closure-preflight.json').read_bytes()),'scope':'All current regular top-level review files. Prior scope and failed preflight receipts remain immutable. Frozen source/dependency directories are linked and independently indexed; future actual replay outputs are separate.','files':files};p=base/'preflight-files.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':sum(f['bytes']for f in files),'sha256':H(p.read_bytes())}))
