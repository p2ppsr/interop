from pathlib import Path
import hashlib,json,subprocess,os,tempfile
root=Path.cwd();base=root/'out/native-review-43268040660/review';profile=base/'replay-dependency-guard-v3.sb';closure=json.loads((base/'dependency-byte-closure-v3.json').read_text());H=lambda b:hashlib.sha256(b).hexdigest();records=[]
def run(label,args,expected):
 r=subprocess.run(args,capture_output=True);assert r.returncode==expected,(label,r.returncode,r.stderr.decode());records.append({'id':label,'command':args,'exitCode':r.returncode,'stdoutSha256':H(r.stdout),'stdoutBytes':len(r.stdout),'stderr':r.stderr.decode()});return r
allowed=root/'synthesis/node_modules/@bsv/sdk/package.json';a=run('allowed-verified-package',['/usr/bin/sandbox-exec','-f',str(profile),'/bin/cat',str(allowed)],0);assert a.stdout==allowed.read_bytes()
for i,p in enumerate(closure['excludedGeneratedBuildMetadata']):
 r=run(f'deny-generated-{i}',['/usr/bin/sandbox-exec','-f',str(profile),'/bin/cat',p],1);assert b'Operation not permitted' in r.stderr and not r.stdout
p=closure['excludedGeneratedBuildMetadata'][0]
run('same-file-readable-without-guard',['/bin/cat',p],0)
node='/Users/tyeverett/.local/lib/nodejs/node-v24.22.1-darwin-arm64/bin/node';r=run('descendant-process-inherits-denial',['/usr/bin/sandbox-exec','-f',str(profile),node,'-e',"require('node:child_process').execFileSync('/bin/cat',[process.argv[1]])",p],1);assert b'Operation not permitted' in r.stderr
with tempfile.TemporaryDirectory(prefix='tpnil-dependency-guard-')as tmp:
 alias=Path(tmp)/'metadata-alias';alias.symlink_to(p);r=run('symlink-alias-denied',['/usr/bin/sandbox-exec','-f',str(profile),'/bin/cat',str(alias)],1);assert b'Operation not permitted' in r.stderr
cache=Path(closure['excludedGeneratedCacheDirectories'][0]);sample=next(p for p in cache.rglob('*') if p.is_file());r=run('generated-vite-cache-denied',['/usr/bin/sandbox-exec','-f',str(profile),'/bin/cat',str(sample)],1);assert b'Operation not permitted' in r.stderr
w=closure['excludedNotMaterializedRustDependency'];r=run('unmaterialized-wasi-archive-denied',['/usr/bin/sandbox-exec','-f',str(profile),'/bin/cat',w['archive']],1);assert b'Operation not permitted' in r.stderr
assert H(profile.read_bytes())==closure['guard']['sha256']
audit=json.loads((base/'package-byte-audit.json').read_text());total=0;unique=0
for pkg in audit['results']:
 seen=set()
 for f in pkg['files']:
  if f['path'] in seen:continue
  seen.add(f['path']);p=root/pkg['dependency']/pkg['package']/f['path'];b=p.read_bytes();assert len(b)==f['bytes'] and H(b)==f['sha256'];total+=len(b);unique+=1
assert unique==19350
out={'schema':'tpnil-native-replay-dependency-guard-tests@1','result':'PASS','tests':len(records),'npmPackageFileBytes':total,'uniquePackageFiles':unique,'verifiedPackageTarballs':525,'guardSha256':H(profile.read_bytes()),'closureSha256':H((base/'dependency-byte-closure-v3.json').read_bytes()),'sandboxExecSha256':H(Path('/usr/bin/sandbox-exec').read_bytes()),'nodeSha256':H(Path(node).read_bytes()),'allPackageBytesStillMatchAudit':True,'semanticReplayExecuted':False,'interpretation':'All ten unverified generated build-metadata files are unreadable to the replay and inherited child processes; actual replay under this guard remains required.','controls':records}
p=base/'dependency-guard-tests-v3.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'result':'PASS','tests':len(records),'packageBytes':total,'sha256':H(p.read_bytes())}))
