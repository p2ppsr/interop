import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {execFileSync} from 'node:child_process';
const root=fs.realpathSync(process.cwd()),home=fs.realpathSync(import.meta.dirname),frozen=path.join(home,'source'),sha=b=>createHash('sha256').update(b).digest('hex');assert.equal(process.versions.node,'24.22.1');
const dependencies=[];
for(const dependency of ['synthesis','integrations/services','components/transport']){
 for(const f of ['package.json','package-lock.json'])assert.equal(sha(fs.readFileSync(path.join(root,dependency,f))),sha(fs.readFileSync(path.join(frozen,dependency,f))));
 const modules=fs.realpathSync(path.join(root,dependency,'node_modules')),expected=JSON.parse(fs.readFileSync(path.join(frozen,dependency,'package-lock.json'))),bytes=fs.readFileSync(path.join(modules,'.package-lock.json')),installed=JSON.parse(bytes);assert.equal(expected.lockfileVersion,3);assert.equal(installed.lockfileVersion,3);assert.ok(Object.keys(installed.packages).length>0);
 for(const[name,actual]of Object.entries(installed.packages)){
  assert.ok(name.startsWith('node_modules/')&&!name.split('/').some(p=>!p||p==='.'||p==='..'));const locked=expected.packages[name];assert.ok(locked&&!locked.link);
  for(const field of ['version','resolved','integrity','dependencies','optionalDependencies','peerDependencies','peerDependenciesMeta'])assert.deepEqual(actual[field],locked[field],`${dependency}/${name}:${field}`);
  const dir=path.join(modules,name.slice('node_modules/'.length));assert.ok(fs.lstatSync(dir).isDirectory()&&!fs.lstatSync(dir).isSymbolicLink());assert.equal(JSON.parse(fs.readFileSync(path.join(dir,'package.json'))).version,locked.version);
 }
 for(const[name,locked]of Object.entries(expected.packages))if(name&&!locked.optional)assert.ok(installed.packages[name],`Required installed package absent: ${dependency}/${name}`);
 dependencies.push({dependency,modules,installedLockSha256:sha(bytes),installedPackages:Object.keys(installed.packages).length});
}
const rust=execFileSync('rustc',['--version'],{env:{...process.env,RUSTUP_TOOLCHAIN:'1.88.0'},encoding:'utf8'}).trim();assert.match(rust,/^rustc 1\.88\.0 /);
const receipt={schema:'tpnil-native-replay-installed-dependencies@1',source:'664e8539031109174e7233390262d76ca6c81240',node:process.version,rust,dependencies,scope:'Exact tracked locks, installed hidden-lock metadata, required package presence and installed versions; no package content integrity substitution or native execution.'};fs.writeFileSync(path.join(home,'dependencies.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({verified:true,packages:dependencies.map(x=>x.installedPackages),rust}));
