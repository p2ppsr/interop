from pathlib import Path
import hashlib,json,tarfile,tomllib,subprocess,os
root=Path.cwd().resolve();home=root/'out/native-review-43268040660/review';frozen=(home/'source').resolve();cargo=Path.home()/'.cargo';sha=lambda b:hashlib.sha256(b).hexdigest();lockbytes=(frozen/'components/rust/Cargo.lock').read_bytes();lock=tomllib.loads(lockbytes.decode());results=[]
for p in lock['package']:
 source=p.get('source','')
 if source.startswith('registry+'):
  key=f"{p['name']}-{p['version']}";archives=list((cargo/'registry/cache').glob(f'*/{key}.crate'));assert len(archives)==1,key;archive=archives[0];assert sha(archive.read_bytes())==p['checksum'];directory=cargo/'registry/src'/archive.parent.name/key;assert directory.resolve()==directory;expected={}
  if not directory.exists():
   assert key=='wasi-0.11.1+wasi-snapshot-preview1';results.append({'name':p['name'],'version':p['version'],'source':source,'root':str(directory),'archive':str(archive),'archiveSha256':p['checksum'],'files':[],'notMaterialized':True,'requiresSandboxDenial':True});continue
  with tarfile.open(archive) as t:
   for m in t.getmembers():
    parts=Path(m.name).parts;assert parts[0]==key and '..'not in parts
    if m.isdir():continue
    assert m.isfile(),(key,m.name,m.type);rel='/'.join(parts[1:]);data=t.extractfile(m).read();assert rel not in expected;expected[rel]={'path':rel,'bytes':len(data),'sha256':sha(data)};target=directory/rel;assert target.is_file()and not target.is_symlink()and target.read_bytes()==data,(key,rel)
  checksum=directory/'.cargo-checksum.json'
  if checksum.exists():
   v=json.loads(checksum.read_text());assert v=={'files':{k:v['sha256']for k,v in expected.items()},'package':p['checksum']},key
  actual=[]
  for d,dirs,files in os.walk(directory):
   for n in dirs:assert not(Path(d)/n).is_symlink()
   for n in files:
    f=Path(d)/n;assert not f.is_symlink();actual.append(str(f.relative_to(directory)))
  extras=set(actual)-set(expected);assert extras <= {'.cargo-checksum.json','.cargo-ok'},(key,extras)
  for rel in extras:
   data=(directory/rel).read_bytes()
   if rel=='.cargo-ok':assert data in [b'{"v":1}',b'{"v":1}\n'],(key,data)
   expected[rel]={'path':rel,'bytes':len(data),'sha256':sha(data),'derivedCargoMetadata':True}
  assert set(actual)==set(expected)
  results.append({'name':p['name'],'version':p['version'],'source':source,'root':str(directory),'archive':str(archive),'archiveSha256':p['checksum'],'files':list(expected.values())})
 elif source.startswith('git+'):
  commit=source.split('#')[1];matches=list((cargo/'git/checkouts').glob(f'*/{commit[:7]}'));assert len(matches)==1;directory=matches[0];env={**os.environ,'GIT_NO_REPLACE_OBJECTS':'1'};run=lambda args:subprocess.check_output(['git','-C',str(directory),*args],env=env)
  assert run(['rev-parse','HEAD']).decode().strip()==commit;entries=run(['ls-tree','-rz','--full-tree',commit]).split(b'\0');expected={}
  for e in entries:
   if not e:continue
   meta,name=e.split(b'\t',1);mode,kind,oid=meta.split();assert kind==b'blob'and mode in[b'100644',b'100755',b'120000'];rel=name.decode();data=run(['cat-file','blob',oid.decode()]);f=directory/rel
   if mode==b'120000':
    assert f.is_symlink()and os.readlink(f)==data.decode();assert not f.exists();expected[rel]={'path':rel,'symlink':data.decode(),'gitObject':oid.decode(),'targetExists':False}
   else:
    assert f.is_file()and not f.is_symlink()and f.read_bytes()==data;expected[rel]={'path':rel,'bytes':len(data),'sha256':sha(data),'gitObject':oid.decode()}
  actual=[]
  for d,dirs,files in os.walk(directory):
   dirs[:]=[n for n in dirs if n!='.git']
   for n in dirs:assert not(Path(d)/n).is_symlink()
   for n in files:
    f=Path(d)/n;actual.append(str(f.relative_to(directory)))
  extras=set(actual)-set(expected);assert extras <= {'.cargo-ok'},extras
  for rel in extras:
   data=(directory/rel).read_bytes();assert data in[b'',b'{"v":1}',b'{"v":1}\n'];expected[rel]={'path':rel,'bytes':len(data),'sha256':sha(data),'derivedCargoMetadata':True}
  assert set(actual)==set(expected)
  results.append({'name':p['name'],'version':p['version'],'source':source,'root':str(directory),'gitCommit':commit,'files':list(expected.values())})
 else:assert p['name']=='tpnil-rust-participant'
out={'schema':'tpnil-replay-rust-dependency-byte-closure@1','source':'664e8539031109174e7233390262d76ca6c81240','mode':'READ_ONLY_EXISTING_CACHE_NO_BUILD_OR_INSTALL','cargoLockSha256':sha(lockbytes),'packages':len(results),'files':sum(len(p['files'])for p in results),'bytes':sum(f.get('bytes',0)for p in results for f in p['files']),'results':results,'result':'PASS'}
(home/'rust-dependency-byte-closure.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='results'}))
