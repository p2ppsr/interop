import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import vm from 'node:vm'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
const home=fs.realpathSync(import.meta.dirname),source=fs.readFileSync(path.join(home,'guarded-replay.mjs'),'utf8'),sha=b=>createHash('sha256').update(b).digest('hex')
const start=source.indexOf('function walk('),end=source.indexOf('function verifyBytes()');assert.ok(start>0&&end>start)
const exactFunctions=source.slice(start,end),scratch=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'native-byte-inventory-'))),records=[]
function run(name,fn){fn();records.push({name,result:'PASS'})}
function fixture(fn){const root=path.join(scratch,String(records.length));fs.mkdirSync(root);const dep='synthesis',base=path.join(root,dep),modules=path.join(base,'node_modules'),pkg=path.join(modules,'a');fs.mkdirSync(pkg,{recursive:true});fs.writeFileSync(path.join(pkg,'index.js'),'trusted');fs.writeFileSync(path.join(pkg,'package.json'),JSON.stringify({name:'a',bin:{a:'index.js'}}));fs.mkdirSync(path.join(modules,'.bin'));fs.symlinkSync('../a/index.js',path.join(modules,'.bin/a'));const closure={excludedGeneratedCacheDirectories:[]},ctx=vm.createContext({fs,path,assert,root,closure});vm.runInContext(exactFunctions+';globalThis.api={walk,packageRoots,verifyBins}',ctx);const api=ctx.api,pkgs=[{package:'node_modules/a'}],expected=new Map([['node_modules/a/index.js',{}],['node_modules/a/package.json',{}]]);fn({root,base,modules,pkg,api,pkgs,expected,dep})}
try{
run('Exact real-filesystem fixture and declared executable',()=>fixture(x=>{assert.equal(JSON.stringify(x.api.packageRoots(x.modules)),JSON.stringify(['node_modules/a']));assert.equal(JSON.stringify(x.api.walk(x.pkg)),JSON.stringify(['index.js','package.json']));x.api.verifyBins(x.modules,x.pkgs,x.dep,x.expected)}))
run('Additional importable package changes complete package inventory',()=>fixture(x=>{fs.mkdirSync(path.join(x.modules,'foreign'));assert.notEqual(JSON.stringify(x.api.packageRoots(x.modules)),JSON.stringify(['node_modules/a']))}))
run('Additional importable file changes complete file inventory',()=>fixture(x=>{fs.writeFileSync(path.join(x.pkg,'foreign.js'),'x');assert.notEqual(JSON.stringify(x.api.walk(x.pkg)),JSON.stringify(['index.js','package.json']))}))
run('Nested node_modules files remain in full inventory',()=>fixture(x=>{fs.mkdirSync(path.join(x.pkg,'test/node_modules'),{recursive:true});fs.writeFileSync(path.join(x.pkg,'test/node_modules/extra.js'),'x');assert.ok(x.api.walk(x.pkg).includes('test/node_modules/extra.js'))}))
run('Retargeted package symlink rejected',()=>fixture(x=>{fs.renameSync(x.pkg,x.pkg+'-real');fs.symlinkSync('a-real',x.pkg);assert.throws(()=>x.api.packageRoots(x.modules),/Unexpected node_modules/)}))
run('Retargeted module-tree symlink rejected',()=>fixture(x=>{fs.renameSync(x.modules,x.modules+'-real');fs.symlinkSync('node_modules-real',x.modules);assert.throws(()=>x.api.packageRoots(x.modules),/Retargeted module tree/)}))
run('Retargeted scoped package directory rejected',()=>fixture(x=>{fs.symlinkSync('a',path.join(x.modules,'@scope'));assert.throws(()=>x.api.packageRoots(x.modules),/Unexpected node_modules/)}))
run('Internal file symlink rejected even with equal bytes',()=>fixture(x=>{fs.renameSync(path.join(x.pkg,'index.js'),path.join(x.pkg,'same.js'));fs.symlinkSync('same.js',path.join(x.pkg,'index.js'));assert.throws(()=>x.api.walk(x.pkg),/Unexpected package symlink/)}))
run('Undeclared executable target rejected despite verified bytes',()=>fixture(x=>{fs.unlinkSync(path.join(x.modules,'.bin/a'));fs.symlinkSync('../a/package.json',path.join(x.modules,'.bin/a'));assert.throws(()=>x.api.verifyBins(x.modules,x.pkgs,x.dep,x.expected),/not declared/)}))
run('Executable link outside verified inventory rejected',()=>fixture(x=>{fs.writeFileSync(path.join(x.base,'foreign'),'x');fs.unlinkSync(path.join(x.modules,'.bin/a'));fs.symlinkSync('../../foreign',path.join(x.modules,'.bin/a'));assert.throws(()=>x.api.verifyBins(x.modules,x.pkgs,x.dep,x.expected),/outside verified bytes/)}))
run('Regular executable replacement rejected',()=>fixture(x=>{fs.unlinkSync(path.join(x.modules,'.bin/a'));fs.writeFileSync(path.join(x.modules,'.bin/a'),'x');assert.throws(()=>x.api.verifyBins(x.modules,x.pkgs,x.dep,x.expected),/Unexpected executable/)}))
const receipt={schema:'tpnil-replay-dependency-inventory-selftest@1',mode:'ISOLATED_FILESYSTEM_SELFTEST_NO_PACKAGE_MUTATION',node:process.version,guardedReplaySha256:sha(source),exactInventoryFunctionSha256:sha(exactFunctions),tests:records.length,records,result:'PASS'};fs.writeFileSync(path.join(home,'dependency-inventory-tests.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt))
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
