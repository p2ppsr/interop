"""Offline npm tarball-integrity and installed-file comparison; never installs."""
from pathlib import Path
import os,json,hashlib,base64,tarfile
root=Path.cwd();home=root/'out/native-review-43268040660/review';cache=Path.home()/'.npm/_cacache/content-v2';H=lambda b:hashlib.sha256(b).hexdigest();results=[];problems=[]
for dep in ['synthesis','integrations/services','components/transport']:
 lock=json.loads((root/dep/'package-lock.json').read_text());installed=json.loads((root/dep/'node_modules/.package-lock.json').read_text())
 for name,meta in installed['packages'].items():
  pkg=root/dep/name;entry=lock['packages'][name];integrity=entry['integrity'];algorithm,encoded=integrity.split('-',1);digest=base64.b64decode(encoded).hex();archive=cache/algorithm/digest[:2]/digest[2:4]/digest[4:];record={'dependency':dep,'package':name,'version':entry['version'],'integrity':integrity,'tarball':str(archive),'files':[],'extraFiles':[],'problems':[]}
  if not archive.is_file():record['problems'].append({'kind':'CACHE_MISSING'});results.append(record);continue
  data=archive.read_bytes();assert hashlib.new(algorithm,data).hexdigest()==digest;record['tarballSha256']=H(data);expected={}
  with tarfile.open(archive,'r:*') as tar:
   for m in tar.getmembers():
    parts=Path(m.name).parts;assert parts and parts[0] in ['package',''] or True
    # npm package tarballs may name their top directory after the module.
    rel='/'.join(parts[1:]);assert rel and not Path(rel).is_absolute() and '..' not in Path(rel).parts or m.isdir()
    if m.isdir():continue
    assert rel not in expected
    target=pkg/rel
    if m.isfile():
     b=tar.extractfile(m).read();expected[rel]={'kind':'file','bytes':len(b),'sha256':H(b)}
     if not target.is_file() or target.is_symlink():record['problems'].append({'kind':'MISSING_OR_WRONG_TYPE','path':rel});continue
     actual=target.read_bytes();record['files'].append({'path':rel,'bytes':len(actual),'sha256':H(actual)})
     if actual!=b:record['problems'].append({'kind':'BYTE_MISMATCH','path':rel,'expected':expected[rel],'actual':record['files'][-1]})
    elif m.issym():
     expected[rel]={'kind':'symlink','target':m.linkname}
     if not target.is_symlink() or os.readlink(target)!=m.linkname:record['problems'].append({'kind':'SYMLINK_MISMATCH','path':rel})
    else:record['problems'].append({'kind':'UNSUPPORTED_ARCHIVE_MEMBER','path':rel,'type':str(m.type)})
  for directory,dirs,files in os.walk(pkg,followlinks=False):
   dirs[:]=[d for d in dirs if d!='node_modules']
   for f in files:
    p=Path(directory)/f;rel=str(p.relative_to(pkg))
    if rel not in expected:
     record['extraFiles'].append({'path':rel,'bytes':p.stat().st_size,'sha256':H(p.read_bytes())} if not p.is_symlink() else {'path':rel,'symlink':os.readlink(p)})
  results.append(record)
summary={'schema':'tpnil-npm-installed-byte-audit@1','source':'664e8539031109174e7233390262d76ca6c81240','mode':'READ_ONLY_EXISTING_CACHE_NO_NETWORK_NO_INSTALL','packages':len(results),'tarballVerifiedPackages':sum('tarballSha256'in r for r in results),'matchedFiles':sum(len(r['files']) for r in results),'problemPackages':[{'dependency':r['dependency'],'package':r['package'],'problems':r['problems']} for r in results if r['problems']],'extraFiles':[{'dependency':r['dependency'],'package':r['package'],'files':r['extraFiles']}for r in results if r['extraFiles']],'results':results}
out=home/'package-byte-audit.json';assert not out.exists();out.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2))
