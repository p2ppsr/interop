from pathlib import Path
import json,hashlib,base64,tarfile,os
root=Path.cwd();b=root/'out/native-review-43268040660/review';prepPath=root/'out/messaging-native-verifier/verifier-preparation.json';prep=json.loads(prepPath.read_text());H=lambda b:hashlib.sha256(b).hexdigest();lock=json.loads((root/'components/messaging/sources.lock.json').read_text());component=next(x for x in lock['components'] if x['id']=='typescript-messagebox');assert component['commit']==prep['component']['commit'];assert component['archiveSha256']==prep['archive']['sha256']
archive=Path(prep['archive']['path']);assert H(archive.read_bytes())==component['archiveSha256'];pkg=Path(prep['package']['path']);prefix=f"ts-stack-{component['commit']}/{component['path']}/"
with tarfile.open(archive)as tar:
 for f,key in [('package.json','jsonSha256'),('package-lock.json','lockSha256')]:
  x=tar.extractfile(prefix+f).read();assert x==(pkg/f).read_bytes() and H(x)==prep['package'][key]
npmLock=json.loads((pkg/'package-lock.json').read_text());entry=npmLock['packages']['node_modules/@bsv/sdk'];sdk=pkg/'node_modules/@bsv/sdk';meta=json.loads((sdk/'package.json').read_text());assert meta['version']==entry['version']==prep['sdk']['version']=='4.0.1';assert not any(meta.get(x) for x in ['dependencies','optionalDependencies','peerDependencies'])
algorithm,encoded=entry['integrity'].split('-',1);digest=base64.b64decode(encoded).hex();cached=Path.home()/'.npm/_cacache/content-v2'/algorithm/digest[:2]/digest[2:4]/digest[4:];raw=cached.read_bytes();assert hashlib.new(algorithm,raw).hexdigest()==digest
files=[]
with tarfile.open(cached)as tar:
 for m in tar.getmembers():
  if m.isdir():continue
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  rel='/'.join(Path(m.name).parts[1:]);x=tar.extractfile(m).read();assert(sdk/rel).is_file()and not(sdk/rel).is_symlink()and(sdk/rel).read_bytes()==x;files.append({'path':rel,'bytes':len(x),'sha256':H(x)})
assert len({f['path']for f in files})==len(files)
actual={str(p.relative_to(sdk))for p in sdk.rglob('*')if p.is_file()};assert actual=={f['path']for f in files}
result={'schema':'tpnil-native-messaging-sdk-byte-closure@1','source':'664e8539031109174e7233390262d76ca6c81240','root':str(sdk),'preparedReceiptSha256':H(prepPath.read_bytes()),'upstreamArchiveSha256':component['archiveSha256'],'upstreamPackageLockSha256':prep['package']['lockSha256'],'version':'4.0.1','integrity':entry['integrity'],'cachedTarballSha256':H(raw),'files':files,'fileCount':len(files),'bytes':sum(f['bytes']for f in files),'nonBuiltinExternalDependencies':0,'result':'PASS','claim':'ADDITIONAL_EFFECTIVE_MESSAGING_VERIFIER_DEPENDENCY_BYTES_ONLY_NO_REPLAY'}
out=b/'messaging-sdk-byte-closure.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':'PASS','files':len(files),'bytes':result['bytes'],'sha256':H(out.read_bytes())}))
