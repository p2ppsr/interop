import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
const root=fs.realpathSync(process.cwd()),home=fs.realpathSync(import.meta.dirname)
const sha=b=>createHash('sha256').update(b).digest('hex')
const read=name=>JSON.parse(fs.readFileSync(path.join(home,name)))
const audit=read('package-byte-audit.json'),closure=read('dependency-byte-closure-v2.json'),tests=read('dependency-guard-tests-v2.json'),sdk=read('messaging-sdk-byte-closure.json')
const profile=path.join(home,'replay-dependency-guard-v2.sb')
assert.equal(process.versions.node,'24.22.1')
assert.equal(process.env.NODE_OPTIONS,undefined,'Unexpected ambient Node code injection')
assert.equal(process.env.NODE_PATH,undefined,'Unexpected ambient Node module path')
assert.equal(tests.result,'PASS');assert.equal(tests.tests,15)
assert.equal(sha(fs.readFileSync(profile)),closure.guard.sha256)
assert.equal(sha(fs.readFileSync(path.join(home,'package-byte-audit.json'))),closure.auditSha256)
assert.equal(sha(fs.readFileSync('/usr/bin/sandbox-exec')),tests.sandboxExecSha256)
assert.equal(sha(fs.readFileSync(process.execPath)),tests.nodeSha256)
function walk(directory,base=directory){
 const files=[]
 for(const item of fs.readdirSync(directory,{withFileTypes:true})){
  if(item.name==='node_modules'&&item.isDirectory())continue
  const f=path.join(directory,item.name)
  assert.ok(!item.isSymbolicLink(),`Unexpected package symlink ${f}`)
  if(item.isDirectory())files.push(...walk(f,base));else{assert.ok(item.isFile());files.push(path.relative(base,f))}
 }
 return files.sort()
}
function packageRoots(modules,prefix='node_modules'){
 const found=[]
 for(const item of fs.readdirSync(modules,{withFileTypes:true})){
  if(item.name==='.bin'||item.name==='.package-lock.json')continue
  if(closure.excludedGeneratedCacheDirectories.includes(path.join(modules,item.name))){assert.ok(item.isDirectory()&&!item.isSymbolicLink());continue}
  assert.ok(item.isDirectory()&&!item.isSymbolicLink(),`Unexpected node_modules entry ${item.name}`)
  if(item.name.startsWith('@'))for(const sub of fs.readdirSync(path.join(modules,item.name),{withFileTypes:true})){
   assert.ok(sub.isDirectory()&&!sub.isSymbolicLink());found.push(`${prefix}/${item.name}/${sub.name}`)
  }else found.push(`${prefix}/${item.name}`)
 }
 return found
}
function verifyBytes(){
 let files=0,bytes=0
 for(const dependency of ['synthesis','integrations/services','components/transport']){
  const pkgs=audit.results.filter(p=>p.dependency===dependency),known=pkgs.map(p=>p.package).sort(),actual=packageRoots(path.join(root,dependency,'node_modules'))
  for(const p of pkgs){const nested=path.join(root,dependency,p.package,'node_modules');if(fs.existsSync(nested))actual.push(...packageRoots(nested,`${p.package}/node_modules`))}
  assert.deepEqual(actual.sort(),known,`Installed package inventory differs ${dependency}`)
 }
 for(const pkg of audit.results){
  assert.equal(pkg.problems.length,0)
  const directory=path.join(root,pkg.dependency,pkg.package);assert.ok(fs.lstatSync(directory).isDirectory()&&!fs.lstatSync(directory).isSymbolicLink());const expected=new Map(pkg.files.map(f=>[f.path,f]))
  for(const f of pkg.extraFiles){assert.ok(f.sha256&&!f.symlink);assert.ok(path.join(directory,f.path)===closure.addon.path||closure.excludedGeneratedBuildMetadata.includes(path.join(directory,f.path)));expected.set(f.path,f)}
  assert.deepEqual(walk(directory),[...expected.keys()].sort())
  for(const [name,f]of expected){const b=fs.readFileSync(path.join(directory,name));assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256)}
  for(const f of new Map(pkg.files.map(f=>[f.path,f])).values()){files++;bytes+=f.bytes}
 }
 assert.equal(files,19350);assert.equal(bytes,321859027)
 assert.equal(sha(fs.readFileSync(closure.addon.path)),closure.addon.sha256)
 assert.equal(sdk.result,'PASS');assert.equal(sdk.fileCount,1951);assert.equal(sdk.nonBuiltinExternalDependencies,0)
 assert.deepEqual(walk(sdk.root),sdk.files.map(f=>f.path).sort())
 for(const f of sdk.files){const b=fs.readFileSync(path.join(sdk.root,f.path));assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256)}
 return {packages:526,files:files+sdk.fileCount,bytes:bytes+sdk.bytes,additionalVerifiedNativeAddonBytes:closure.addon.bytes,excludedMetadataFiles:10,excludedGeneratedCaches:1}
}
const verified=verifyBytes()
if(process.argv[2]==='--verify-dependencies-only'){
 console.log(JSON.stringify({verified:true,...verified,semanticReplayExecuted:false}));process.exit(0)
}
const original=fs.realpathSync(process.argv[2]);assert.ok(original.startsWith(path.join(root,'out')+path.sep))
const args=['-f',profile,process.execPath,path.join(home,'replay-when-authorized.mjs'),original,'43268040660']
const startedAt=new Date().toISOString()
const r=spawnSync('/usr/bin/sandbox-exec',args,{cwd:root,env:{...process.env,TPNIL_DEPENDENCY_BYTE_GUARD:'mandatory-sandbox-v1'},encoding:'utf8',timeout:4500000,maxBuffer:64*1024*1024})
for(const[name,b]of[['guarded-replay.stdout.log',r.stdout??''],['guarded-replay.stderr.log',r.stderr??'']])fs.writeFileSync(path.join(home,name),b,{flag:'wx'})
assert.deepEqual(verifyBytes(),verified);assert.equal(sha(fs.readFileSync(profile)),closure.guard.sha256)
const receipt={schema:'tpnil-native-byte-closed-replay-execution@1',source:'664e8539031109174e7233390262d76ca6c81240',run:43268040660,command:['/usr/bin/sandbox-exec',...args],startedAt,completedAt:new Date().toISOString(),exitCode:r.status,signal:r.signal,error:r.error?.message,verifiedDependencies:verified,packageBytesAndInventoryUnchanged:true,guardRequired:true,guardSha256:closure.guard.sha256,byteClosureSha256:sha(fs.readFileSync(path.join(home,'dependency-byte-closure-v2.json'))),messagingSdkClosureSha256:sha(fs.readFileSync(path.join(home,'messaging-sdk-byte-closure.json'))),replayReceipt:fs.existsSync(path.join(home,'replay.json'))?sha(fs.readFileSync(path.join(home,'replay.json'))):null}
fs.writeFileSync(path.join(home,'guarded-replay.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));if(r.status!==0)process.exitCode=1
