#!/usr/bin/env python3
"""Read-only review of preparation receipts; does not execute replay or rehash packages."""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[3]
P=ROOT/'out/native-review-43268040660/review'
OUT=pathlib.Path(__file__).resolve().parent
SOURCE='664e8539031109174e7233390262d76ca6c81240'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(n):return json.loads((P/n).read_bytes())
def desc(n):
 b=(P/n).read_bytes();return {'path':n,'bytes':len(b),'sha256':sha(b)}
preflight=read('byte-closure-preflight.json');index=read('preflight-files.json')
assert desc('byte-closure-preflight.json')['sha256']=='82b173ac6db8c5859d03e67c56bb55da6dc8d45f608790376d11825f11e1eeb6'
assert desc('preflight-files.json')['sha256']=='cb1d3715b6a14109b77eee720f1bb82929219c18e8a844fe3c975d4dcbbb66da'
assert index['source']==preflight['source']==SOURCE
assert index['predecessorPreflightSha256']==desc('byte-closure-preflight.json')['sha256']
assert index['semanticReplayExecuted'] is False and preflight['semanticReplayExecuted'] is False
assert len(index['files'])==80 and len({x['path'] for x in index['files']})==80
for collection in [index['files'],preflight['files']]:
 for row in collection:
  assert '/' not in row['path'] and row['path'] not in ['.','..']
  assert not (P/row['path']).is_symlink()
  assert desc(row['path'])==row,(row,desc(row['path']))
indexed={r['path'] for r in index['files']}
assert {'dependencies.json','verify-dependencies.mjs','guarded-replay.mjs','replay-when-authorized.mjs','test-dependency-inventory.mjs'}<=indexed
closure=read('dependency-byte-closure-v3.json');sandbox=read('dependency-guard-tests-v3.json');inventory=read('dependency-inventory-tests.json');cache=read('cache-isolation-tests.json')
assert sandbox['result']=='PASS' and sandbox['tests']==len(sandbox['controls'])==16
assert sandbox['guardSha256']==closure['guard']['sha256']==desc('replay-dependency-guard-v3.sb')['sha256']
assert sandbox['closureSha256']==desc('dependency-byte-closure-v3.json')['sha256']
for c in sandbox['controls']:
 assert c['exitCode']==(0 if c['id'] in ['allowed-verified-package','same-file-readable-without-guard'] else 1)
assert inventory['result']=='PASS' and inventory['tests']==len(inventory['records'])==11
assert all(r['result']=='PASS' for r in inventory['records'])
guard=(P/'guarded-replay.mjs').read_text()
# The later Rust helper was inserted between the tested functions and verifyBytes.
# Compare only the unchanged exact functions actually exercised by the 11 controls.
functions=guard[guard.index('function walk('):guard.index('function verifyRustBytes()')]
assert sha(functions.encode())==inventory['exactInventoryFunctionSha256']
assert cache['result']=='PASS' and len(cache['records'])==2
assert cache['guardSha256']==desc('replay-dependency-guard-v3.sb')['sha256']
assert cache['cacheIsolationSha256']==desc('cache-isolation.json')['sha256']
for c in cache['records']:
 assert c['exitCode']==0 and c['tempFiles']==0 and c['stdout']['value']==c['value']
 assert c['stdout']['tsx']=='1' and c['stdout']['node']=='1' and c['stdout']['disabled'] is True and c['stdout']['cache'] is None
actual=read('full-dependency-preflight-5.stdout.log')
assert actual==preflight['preflight']
assert (P/'full-dependency-preflight-5.stderr.log').stat().st_size==0
assert actual['packages']==526 and actual['files']==21301 and actual['bytes']==346367681
assert actual['rust']=={'lockedPackages':23,'materializedPackages':22,'verifiedInventoryEntries':1745,'verifiedSourceBytes':17687793,'unmaterializedSandboxDeniedPackages':1}
review={
 'schema':'tpnil-native9-byte-closure-independent-review@1','verified':True,'result':'NO_ACTIONABLE_FINDING_IN_REVIEWED_PREPARATION',
 'source':SOURCE,'nativeRun':43268040660,'semanticReplayExecuted':False,'nativeQualification':False,
 'reviewScope':'Independent source read-through and retained-index/control binding, without repeating installed package scans, controls, Rust compilation or native semantic replay.',
 'preflight':desc('byte-closure-preflight.json'),'supplement':desc('preflight-files.json'),
 'checkedIndexFiles':len(index['files']),'checkedIndexBytes':sum(r['bytes'] for r in index['files']),
 'retainedControls':{'sandbox':16,'inventory':11,'tsxCache':2,'total':29,'rerunByReviewer':False},
 'currentInventoryFunctionSha256':sha(functions.encode()),
 'reviewedMechanisms':[
  'Frozen and installed lock joins; complete package and regular-file inventories with canonical roots and declared .bin symlink targets.',
  'npm installed files matched to locked integrity-verified tarballs; source-locked messaging SDK included separately; native addon bound to official retained release metadata/cache.',
  'All materialized locked Rust dependency entries bind tarballs or exact Git source; the absent wasi dependency remains sandbox denied.',
  'Unqualified generated build metadata and .vite cache are denied to replay descendants; installed dependency writes are denied.',
  'Fresh owned Rust target and temporary directory, disabled TSX/Node caches, recorded compiler/tool bytes and guarded actual replay with post-execution byte checks.',
  'Replay requires original qualification, records, shutdown and both Rust results, uses canonical frozen source and nonempty child receipts, and preserves incomplete attempts.'
 ],
 'resolvedIndexGap':'The additive 80-file index includes dependencies.json and verify-dependencies.mjs without rewriting original 82b preflight.',
 'limits':[
  'This verifies preparation evidence and implementation design, not a completed semantic or native replay.',
  'The 29 controls are author-executed retained receipts checked here, not new independent executions.',
  'The 346367681 npm and 17687793 Rust dependency-byte scans were not repeated by this reviewer; their exact source-bound receipts and code were reviewed.',
  'Host toolchain binaries are recorded; the operating system and compiler runtime are not claimed as reproducible from-source builds.',
  'Actual replay must remain under the guard, satisfy fresh cache conditions and pass all frozen parent/child checks before any native admission claim.'
 ],
 'reviewedFiles':[desc(n) for n in ['guarded-replay.mjs','replay-when-authorized.mjs','verify-package-bytes.py','verify-messaging-sdk-bytes.py','verify-rust-dependency-bytes.py','dependencies.json','verify-dependencies.mjs','replay-dependency-guard-v3.sb','test-dependency-inventory.mjs','test-cache-isolation.mjs','test-dependency-guard-v3.py']],
 'reviewerScript':{'path':'verify-review.py','sha256':sha(pathlib.Path(__file__).read_bytes())}
}
path=OUT/'review.json';path.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'verified':True,'review':str(path.relative_to(ROOT)),'sha256':sha(path.read_bytes()),'indexFiles':80,'controls':29,'semanticReplayExecuted':False}))
