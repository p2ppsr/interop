from pathlib import Path,PurePosixPath
import subprocess,hashlib,json,shlex
root=Path.cwd();out=root/'out/native-review-43268040660/image-export-assessment';commit='664e8539031109174e7233390262d76ca6c81240';H=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a]);tree={}
for row in git('ls-tree','-rz','--full-tree',commit).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob';tree[name.decode()]={'mode':mode,'oid':oid}
counts={};docker={}
for name in ['yours-go','integrated','conformance']:
 p=f'infra/native/{name}/Dockerfile';b=git('show',f'{commit}:{p}');assert(root/p).read_bytes()==b;s=b.decode();docker[name]=s;lines=[l for l in s.splitlines()if l.startswith(('COPY ','RUN '))];counts[name]={'COPY':sum(l.startswith('COPY ')for l in lines),'RUN':sum(l.startswith('RUN ')for l in lines),'filesystemInstructions':len(lines),'sha256':H(b)}
files={};overwrites=[];generated=[];copyRows=[]
for number,line in enumerate(docker['conformance'].splitlines(),1):
 if not line.startswith('COPY '):continue
 parts=shlex.split(line)[1:];srcs,dest=parts[:-1],parts[-1];assert not any(x.startswith('--')for x in srcs);assert dest.startswith('/');assert dest.startswith(('/work/','/opt/tpnil/'))
 for src in srcs:
  if src.startswith('out/${TPNIL_STORAGE_BINARY}'):
   generated.append({'source':src,'destination':dest+'itcve-go-storage-caller-known-inputs'+('.json'if src.endswith('.json')else''),'bytes':'DYNAMIC_LINUX_BINARY_OR_MANIFEST_FROM_SAME_BUILD_REQUIRED'});continue
  matches=[src]if src in tree else [n for n in tree if n.startswith(src+'/')];assert matches,src
  for name in matches:
   if src in tree:target=dest+PurePosixPath(src).name if dest.endswith('/')else dest
   else:target=dest.rstrip('/')+'/'+name[len(src)+1:]
   data=git('cat-file','blob',tree[name]['oid']);record={'source':name,'destination':target,'bytes':len(data),'sha256':H(data),'gitMode':tree[name]['mode'],'copyOwner':'0:0','instruction':number}
   assert record['gitMode']in['100644','100755']
   if target in files:
    assert {k:v for k,v in files[target].items()if k not in['instruction']}=={k:v for k,v in record.items()if k not in['instruction']};overwrites.append({'destination':target,'priorInstruction':files[target]['instruction'],'instruction':number})
   files[target]=record
 copyRows.append({'line':number,'instruction':line})
assert not(root/'.dockerignore').exists();assert not(root/'infra/native/conformance/Dockerfile.dockerignore').exists()
# This proposal is not built or written to a tracked path. Exact COPY order is retained in an isolated overlay stage.
proposal='ARG TPNIL_INTEGRATED_BASE\nFROM scratch AS conformance-files\nARG TPNIL_STORAGE_BINARY=itcve-go-storage-portability\n'+ '\n'.join(r['instruction']for r in copyRows)+'\nFROM ${TPNIL_INTEGRATED_BASE}\nUSER root\nCOPY --from=conformance-files /work/ /work/\nCOPY --from=conformance-files /opt/tpnil/ /opt/tpnil/\nENV TPNIL_NATIVE_CONFORMANCE=1 TPNIL_NATIVE_IDENTITY_TRUST=1\nUSER pwuser\n'
(out/'PROPOSAL-NOT-BUILT.Dockerfile').write_text(proposal)
receipt={'schema':'tpnil-native-image-export-source-assessment@1','source':commit,'mode':'READ_ONLY_SOURCE_ANALYSIS_NO_BUILD_OR_RUNTIME_CHANGE','counts':counts,'currentAddedFilesystemInstructions':sum(v['filesystemInstructions']for v in counts.values()),'conformanceCopyInstructions':len(copyRows),'conformanceStaticFinalFiles':len(files),'staticFinalBytes':sum(f['bytes']for f in files.values()),'exactDuplicateOverwrites':overwrites,'generatedInputs':generated,'staticSourceFileMap':sorted(files.values(),key=lambda f:f['destination']),'proposal':{'path':'PROPOSAL-NOT-BUILT.Dockerfile','sha256':H(proposal.encode()),'finalConformanceFilesystemLayers':2,'reduction':len(copyRows)-2,'sameFinalBase':'TPNIL_INTEGRATED_BASE','finalUser':'pwuser','workdir':'inherits /work','command':'inherits unchanged native base CMD','environmentAdditions':{'TPNIL_NATIVE_CONFORMANCE':'1','TPNIL_NATIVE_IDENTITY_TRUST':'1'},'copiedFileModePreservation':True,'uidGid':'0:0 as current COPY default','unrelatedInheritedFiles':'directory contents merge; not replaced or omitted','actualLinuxFilesystemAndConfigEqualityVerified':False},'limitations':['No Docker build, image extraction or Linux execution was performed.','All static copied-file bytes and Git modes are enumerated, beyond394 pins; actual Linux generated binary/manifest and all directory metadata still need exact comparison.','Source overlay destinations must be verified not to traverse inherited symlinks, and inherited ownership/modes must match after directory merge.','Fewer final-image filesystem layers is a supported structural consequence; export speed, resource use and shutdown cause remain unproved.','Both prior failure and any future passing sample must remain distinct.'],'primaryDocumentation':'https://docs.docker.com/reference/dockerfile/#copy','priorMeasurementsProvidedByRoot':{'native6FinalImageLayers':93,'native6BaseExportSeconds':8.7,'native6IntegratedExportSeconds':16.3,'native6FinalExportSeconds':124.4,'native6FinalContextMB':148.89,'native8FinalContextMB':155.83,'currentExpectedImageLayers':104}}
(out/'review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k not in['staticSourceFileMap','limitations']}))
