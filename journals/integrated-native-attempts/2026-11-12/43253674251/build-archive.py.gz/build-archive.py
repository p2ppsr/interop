from pathlib import Path
import gzip,hashlib,json,shutil
b=Path(__file__).resolve().parent;repo=b.parents[1];d=repo/'journals/integrated-native-attempts/2026-11-12/43253674251';assert not d.exists();d.mkdir(parents=True);sha=lambda v:hashlib.sha256(v).hexdigest();rows=[]
keep=[b/'acquisition.json',b/'build-archive.py',b/'verify-archive-template.py']+[p for sub in ['initial-terminal','source-and-dispatch']for p in sorted((b/sub).rglob('*'))if p.is_file()]
for f in keep:
 rel=f.relative_to(b).as_posix();raw=f.read_bytes();encoding='identity'if f.suffix=='.zip'else'gzip';stored=raw if encoding=='identity'else gzip.compress(raw,mtime=0);name=rel+(''if encoding=='identity'else'.gz');p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(stored);rows.append({'path':name,'originalPath':rel,'encoding':encoding,'originalBytes':len(raw),'originalSha256':sha(raw),'storedBytes':len(stored),'storedSha256':sha(stored)})
enc=d/'encoding.json';enc.write_text(json.dumps({'schema':'tpnil-retained-byte-encoding@1','files':rows},indent=2)+'\n');(d/'verify.py').write_text((b/'verify-archive-template.py').read_text().replace('__ENCODING__',sha(enc.read_bytes())))
(d/'README.md').write_text('''# Native attempt 7: selector startup failure

Run43253674251 executed source69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7 with the coverage3 selector. It failed before any artifact preparation, builds or wallet execution: the committed-selector check threw `spawnSync git ENOBUFS`. The later generic legacy-selector explanation is not evidence that an obsolete selector was requested; the raw environment contains the correct coverage3 selector.

The artifact upload step also failed because out/native-go-wallet did not exist. GitHub's terminal artifact API reports zero artifacts. The complete original workflow/job logs and raw API receipts are retained; no nonexistent native ZIP, repetition, predicate vector, shutdown or Rust receipt is invented. Zero of the planned698 predicates were observed, and no native qualification is claimed.

The executed job ran15:59:10–15:59:32UTC,22seconds. The alternative job was skipped; its inconsistent API timestamps are retained without treating them as an executed negative duration. Together with successful prerequisite CI1826seconds, this order consumed1848seconds and the completed cohort totals26968seconds. Monetary charges, storage/egress, allocated capacity and operator/agent effort remain unknown. Unused reservation is not actual cost or authorization for a retry.

This failed sample is immutable. A prospective selector correction and separately recorded recovery cannot convert it into a passing native result. Run python3 verify.py for byte inventory, terminalAPI, zero-artifact, stage and cost validation. No native or semantic execution occurs in this verifier.
''')
m={'schema':'tpnil-integration-attempt@1','source':'69386efcea077e4bbe5b6e07f71fc6fe3b1f87f7','workflowRun':43253674251,'artifactId':None,'claim':'OBSERVER_STARTUP_ERROR','failureClassification':'COMMITTED_SELECTOR_GIT_BUFFER_ENOBUFS','walletExecuted':False,'newNativeSessions':0,'workflowConclusion':'failure','nativeQualification':False,'completeBRC100Conformance':False,'candidateOnly':True,'officialRelease':False,'files':[{'name':p.relative_to(d).as_posix(),'size':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(d.rglob('*'))if p.is_file()]};p=d/'attempt.json';p.write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'archive':str(d),'attemptSha256':sha(p.read_bytes()),'files':len(m['files']),'bytes':sum(e['size']for e in m['files'])}))
