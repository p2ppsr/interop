from pathlib import Path
import json,subprocess,datetime,hashlib
B=Path(__file__).resolve().parent;now=datetime.datetime.now(datetime.timezone.utc);D=B/'monitoring'/now.strftime('%Y%m%dT%H%M%S%fZ');D.mkdir(parents=True);SOURCE='664e8539031109174e7233390262d76ca6c81240';RUN=43262928941
sha=lambda b:hashlib.sha256(b).hexdigest()
def api(endpoint,name):
 p=subprocess.run(['gh','api',endpoint],capture_output=True,timeout=45);(D/(name+'.json')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode();return json.loads(p.stdout)
runs=api('repos/p2ppsr/interop/actions/runs?head_sha='+SOURCE+'&per_page=100','runs');run=api(f'repos/p2ppsr/interop/actions/runs/{RUN}','run');jobs=api(f'repos/p2ppsr/interop/actions/runs/{RUN}/jobs?per_page=100','jobs')
s={'capturedAt':now.isoformat(),'source':SOURCE,'run':RUN,'status':run['status'],'conclusion':run['conclusion'],'createdAt':run['created_at'],'completedNativeJobSeconds':0,'activeNativeJobSeconds':0,'cohortBeforeNative':28378,'monetaryCostUSD':None,'globalDeadline':'2026-11-12T18:57:49.493531+00:00','nativeMaximumJobSeconds':4200,'alerts':[],'warnings':[],'jobs':[]}
assert run['head_sha']==SOURCE and run['event']=='workflow_dispatch'and run['run_attempt']==1
if runs['total_count']!=2 or {r['id']for r in runs['workflow_runs']}!={RUN,43260409136}:s['alerts'].append('Unexpected source workflow inventory')
assert jobs['total_count']==len(jobs['jobs'])
for j in jobs['jobs']:
 r={k:j[k]for k in['id','name','status','conclusion','started_at','completed_at']};r['activeSteps']=[x['name']for x in j['steps']if x['status']=='in_progress'];r['failedSteps']=[x['name']for x in j['steps']if x['conclusion']=='failure']
 if j['conclusion']=='skipped':r['chargedJobSeconds']=0;r['basis']='Skipped job; raw timestamps retained and not treated as execution'
 elif j['started_at']:
  start=datetime.datetime.fromisoformat(j['started_at'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(j['completed_at'].replace('Z','+00:00'))if j['completed_at']else now;secs=(end-start).total_seconds();assert secs>=0
  if j['completed_at']:r['chargedJobSeconds']=secs;s['completedNativeJobSeconds']+=secs
  else:r['elapsedSeconds']=secs;s['activeNativeJobSeconds']+=secs
  r['jobDeadline']=(start+datetime.timedelta(seconds=4200)).isoformat()
  nativeStep=next((x for x in j['steps']if x['name']=='Execute and independently verify the integrated native wallet graph'),None)
  nativeStarted=nativeStep and nativeStep.get('started_at')
  phaseEnd=datetime.datetime.fromisoformat(nativeStarted.replace('Z','+00:00'))if nativeStarted else end
  setupSeconds=(phaseEnd-start).total_seconds();r['nativeStageStartedAt']=nativeStarted;r['setupSeconds']=setupSeconds;r['nonRepetitionTotalBudgetSeconds']=1080;r['nonRepetitionBudgetAfterSetupSeconds']=1080-setupSeconds;r['twoFullRepetitionsWithGraceSeconds']=3120
  if setupSeconds>1080:s['alerts'].append('Setup consumed more than1080s total non-repetition envelope')
  elif not nativeStarted and setupSeconds>=900:s['warnings'].append('Setup reached900s;180s or less remains for additional setup/verification/upload if both full repetition bounds are consumed')
  if secs>4200:s['alerts'].append('Native job4200s bound exceeded')
 if j['name']not in['all-go-native','yours-wallet']:s['alerts'].append('Unexpected job '+j['name'])
 if j['conclusion']in['failure','timed_out','cancelled']:s['alerts'].append('Terminal '+j['conclusion']+' job '+str(j['id']))
 s['jobs'].append(r)
if now>datetime.datetime.fromisoformat(s['globalDeadline']):s['alerts'].append('Absolute order deadline exceeded')
if s['completedNativeJobSeconds']+s['activeNativeJobSeconds']>4200:s['alerts'].append('Aggregate native4200s bound exceeded')
s['knownCohortIncludingCompletedNative']=28378+s['completedNativeJobSeconds'];s['files']=[{'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(D.iterdir())if p.is_file()];(D/'summary.json').write_text(json.dumps(s,indent=2)+'\n');(B/'latest.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
