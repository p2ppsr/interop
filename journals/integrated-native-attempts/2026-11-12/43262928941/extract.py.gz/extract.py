from pathlib import Path
import json,zipfile,hashlib,datetime
B=Path(__file__).resolve().parent;A=B/'acquisition';r=json.loads((A/'acquisition.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();assert r['result']=='ORIGINAL_BYTES_VERIFIED'and r['runId']==43262928941
if r['artifact']is None:
 print(json.dumps({'originalArtifactAbsent':True,'run':43262928941,'noExecutionVerdictInferred':True}));raise SystemExit(0)
row=next(x for x in r['zipIntegrity']if x['artifactId']==r['artifact']['id']);p=A/row['path'];assert r['artifact']['githubDigest']=='sha256:'+sha(p.read_bytes());ts=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H-%M-%SZ');attempt=B/('attempt-'+ts);D=attempt/'original';D.mkdir(parents=True)
with zipfile.ZipFile(p)as z:
 for m in row['members']:
  q=Path(m['path']);assert not q.is_absolute()and'..'not in q.parts;raw=z.read(m['path']);assert sha(raw)==m['sha256']and len(raw)==m['bytes'];f=D/q;f.parent.mkdir(parents=True,exist_ok=True);assert not f.exists();f.write_bytes(raw)
assert {f.relative_to(D).as_posix()for f in D.rglob('*')if f.is_file()}=={m['path']for m in row['members']}
out={'schema':'tpnil-native-original-extraction@1','run':r['runId'],'source':r['source'],'archiveSha256':sha(p.read_bytes()),'acquisitionSha256':sha((A/'acquisition.json').read_bytes()),'originalDirectory':str(D),'members':row['members'],'observedCount':len(row['members']),'qualificationClaim':False};f=attempt/'extraction.json';f.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'originalDirectory':str(D),'members':len(row['members']),'receipt':str(f),'receiptSha256':sha(f.read_bytes())}))
