#!/usr/bin/env python3
"""Reproduce the retained pre-runtime interruption boundary without network or replay."""
from pathlib import Path
from datetime import datetime
import json,hashlib,re,sys
base=Path(__file__).resolve().parent; acquired=base.parent/'acquisition'; H=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((acquired/'run.json').read_text());jobs=json.loads((acquired/'jobs.json').read_text())['jobs'];artifacts=json.loads((acquired/'artifacts.json').read_text());check=json.loads((base/'check-run.json').read_text());suite=json.loads((base/'check-suite.json').read_text());annotations=json.loads((base/'annotations.json').read_text())
source='664e8539031109174e7233390262d76ca6c81240'
assert run['id']==43262928941 and run['head_sha']==source and run['conclusion']=='failure' and run['status']=='completed' and run['run_attempt']==1
assert check['head_sha']==suite['head_sha']==source and check['conclusion']==suite['conclusion']=='failure'
assert check['output']['annotations_count']==len(annotations)==2
assert [x['message'] for x in annotations if x['annotation_level']=='failure']==['Process completed with exit code 143.']
job=next(x for x in jobs if x['name']=='all-go-native');assert job['id']==131338748697 and job['conclusion']=='failure'
assert [x['conclusion'] for x in jobs if x['name']=='yours-wallet']==['skipped']
steps={x['name']:x for x in job['steps']}
for name in ['Check committed native selector before builds','Prepare and verify immutable artifacts and Go host','Build the frozen native browser closure','Install the pinned integrated service closure']:assert steps[name]['conclusion']=='success'
assert steps['Build the prospective conformance image']['conclusion']=='failure'
for name in ['Execute two clean isolated native repetitions and verify results','Execute and independently verify the integrated native wallet graph','Retain every attempt and qualification receipt']:assert steps[name]['conclusion']=='skipped'
assert artifacts['total_count']==0 and artifacts['artifacts']==[]
log=(acquired/'job-131338748697.log').read_text(encoding='utf-8-sig');lines=log.splitlines();plain=[re.sub(r'^\S+Z ','',x) for x in lines]
assert [x for x in plain if '##[error]' in x]==['##[error]Process completed with exit code 143.','##[error]The runner has received a shutdown signal. This can happen when the runner service is stopped, or a manually started runner is canceled.']
assert not re.search(r'no space left|disk full|out of memory|OOMKilled',log,re.I)
final=max(i for i,l in enumerate(plain) if re.search(r'#\d+ \[64/64\] COPY ',l));assert re.search(r'#\d+ DONE 0\.0s',plain[final+1])
assert any('#69 exporting layers' in x for x in plain[final+1:])
assert not any('#69 DONE' in x or '#69 writing image' in x for x in plain[final+1:])
manifest=None;manifest_line=None
for i,line in enumerate(plain):
 if line=='{':
  try:
   obj,_=json.JSONDecoder().raw_decode('\n'.join(plain[i:]))
   if obj.get('schema')=='tpnil-storage-caller-known-inputs-go-build@1.0.0':
    assert manifest is None;manifest=obj;manifest_line=i+1
  except json.JSONDecodeError:pass
assert manifest and manifest['toolchain']=='go1.27.3' and manifest['binarySha256']=='e85716ded21ac7d58fc21eeded238ced12f8f956742f567fe0abc21f6c04468b'
seconds=int((datetime.fromisoformat(job['completed_at'].replace('Z','+00:00'))-datetime.fromisoformat(job['started_at'].replace('Z','+00:00'))).total_seconds());assert seconds==1052
files=[]
for parent,names in [(acquired,['acquisition.json','run.json','jobs.json','artifacts.json','job-131338748697.log','all-job-logs.zip']),(base,['check-run.json','check-suite.json','annotations.json'])]:
 for name in names:
  p=parent/name;b=p.read_bytes();files.append({'path':str(p.relative_to(base.parent)),'bytes':len(b),'sha256':H(b)})
receipt={'schema':'tpnil-native-pre-runtime-interruption-review@1','verified':True,'source':source,'run':run['id'],'job':job['id'],'jobSeconds':seconds,'result':'IMAGE_EXPORT_INTERRUPTED_BY_RUNNER_SHUTDOWN','nativeSessions':0,'nativeObservations':0,'artifactCount':0,'qualification':False,'failure':{'exitCode':143,'logLines':[1712,1713],'stage':'final Docker image export','shutdownOrigin':'UNKNOWN','humanCancellationEvidence':None,'capacityFailureEvidence':None,'workflowConclusion':'failure'},'source2Selector':'PASS','finalDockerInstructions':{'completed':64,'finalInstructionLogLine':final+1,'exportCompleted':False},'reportedGoBuild':{'schema':manifest['schema'],'logLine':manifest_line,'binarySha256':manifest['binarySha256'],'toolchain':manifest['toolchain'],'generatedHostFiles':len(manifest['generatedHost']),'note':'Complete build manifest emitted in original log; binary itself not retained because runner shutdown skipped artifact upload.'},'limitations':['A shutdown notification and exit143 establish interruption, not its initiating cause.','No disk/OOM diagnostic or identified cancellation actor appears in the acquired log/check annotations; absence does not prove the underlying cause.','Completed Docker COPYs and emitted Go manifest are not native runtime or final-image qualification.','No full native parent replay is possible: no original qualification/session artifacts exist.'],'files':files}
out=base/'review.json'
if '--write' in sys.argv:
 assert not out.exists();out.write_text(json.dumps(receipt,indent=2)+'\n')
else:assert json.loads(out.read_text())==receipt
print(json.dumps({'verified':True,'reviewSha256':H(out.read_bytes()),'nativeSessions':0,'jobSeconds':seconds,'shutdownOrigin':'UNKNOWN'}))
