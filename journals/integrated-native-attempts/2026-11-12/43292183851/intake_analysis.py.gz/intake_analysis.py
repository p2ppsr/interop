"""Passive original-ZIP intake. No extraction, runtime, RPC, Rust or semantic replay."""
from pathlib import Path,PurePosixPath
import argparse,collections,datetime,hashlib,json,stat,zipfile
HERE=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
OUTCOMES=['PASS','FAIL','BLOCKED','INCONCLUSIVE','NOT_OBSERVED']
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def counts(rows,key='outcome'):return {x:sum(r.get(key)==x for r in rows)for x in OUTCOMES}
def index_record(r):
 assert isinstance(r,dict)and isinstance(r.get('vectors'),list),'Missing vector array'
 assert [v['id']for v in r['vectors']]==[f'ISI-4-V00{i}'for i in range(1,9)],'Wrong ordered vector inventory'
 ix={}
 for v in r['vectors']:
  assert isinstance(v['assertions'],list)
  for a in v['assertions']:
   assert isinstance(a.get('id'),str)and a['id'];assert a.get('outcome')in OUTCOMES[:-1]
   k=v['id']+'/'+a['id'];assert k not in ix,'Duplicate assertion '+k
   ix[k]={'key':k,'vector':v['id'],'id':a['id'],'outcome':a['outcome'],'detail':str(a.get('detail',''))[:8000]}
 return ix
def safe_members(z):
 infos=z.infolist();assert len(infos)<=20000;assert sum(i.file_size for i in infos)<=8*1024**3
 names=set();rows=[]
 for i in infos:
  n=i.filename;p=PurePosixPath(n);assert n and not n.startswith('/')and '\\'not in n and '\0'not in n and all(x not in ['', '.', '..']for x in n.rstrip('/').split('/'))
  assert n not in names;names.add(n);assert not stat.S_ISLNK(i.external_attr>>16);assert not(i.flag_bits&1);assert i.file_size<=384*1024**2
  if i.is_dir():continue
  h=hashlib.sha256();size=0
  with z.open(i)as f:
   for b in iter(lambda:f.read(1024*1024),b''):size+=len(b);h.update(b)
  assert size==i.file_size;rows.append({'path':n,'bytes':size,'sha256':h.hexdigest()})
 return rows
def inspect(original,config,legacy=False):
 with zipfile.ZipFile(original)as z:
  members=safe_members(z);names={r['path']for r in members};errors=[]
  def read(n):return json.loads(z.read(n))if n in names else None
  def capture(n):
   if n not in names:return {'path':n,'status':'MISSING'}
   try:
    v=read(n);return {'path':n,'status':'PRESENT_UNVERIFIED','schema':v.get('schema')if isinstance(v,dict)else None,'value':v}
   except Exception as e:return {'path':n,'status':'MALFORMED','error':str(e)}
  lock=read('run-lock.json');expectedSource=config['source'];source=lock.get('source')if isinstance(lock,dict)else None
  if source!=expectedSource:errors.append('Run-lock source mismatch')
  if not legacy and lock is not None:
   if lock.get('planSha256')!=config['planSha256']:errors.append('Run-lock plan digest mismatch')
   if lock.get('executionVariant')!=config['executionVariant']:errors.append('Run-lock execution variant mismatch')
  report={'schema':'tpnil-native-passive-intake-review@1','claim':'ORIGINAL_BYTES_AND_RAW_OBSERVATIONS_ONLY','sourceExpected':expectedSource,'sourceObserved':source,'originalZip':{'path':str(Path(original).resolve()),'sha256':digest(original),'bytes':Path(original).stat().st_size},'members':members,'semanticReplayExecuted':False,'nativeQualification':False,'qualifiedEnvironment':False,'fullParentAdmission':'NOT_INDEPENDENTLY_REPLAYED','completeBRC100Conformance':False,'errors':errors,'repetitions':[],'rawAdmissions':{},'legacyControl':legacy}
  for name in ['qualification.json','integrated-qualification.json']:
   c=capture(name);v=c.pop('value',None)
   if isinstance(v,dict):c.update({'source':v.get('source'),'profile':v.get('profile',v.get('itcve')),'qualifiedEnvironmentClaim':v.get('qualifiedEnvironment'),'repetitionMatchClaim':v.get('repetitionMatch'),'assertionCount':sum(len(x.get('assertions',[]))for x in v.get('vectors',[])),'claim':v.get('claim')})
   report['rawAdmissions'][name]=c
  expected={r['key']for r in(config['legacyNative6']if legacy else config['expectedAssertions'])};indexes=[]
  for i in [1,2]:
   prefix=f'repetition-{i}/';evidence=prefix+'evidence/';rec=read(prefix+'record.json');recName=prefix+'record.json'
   if rec is None:recName=evidence+'conformance/result.json';rec=read(recName)
   row={'index':i,'recordPath':recName if rec is not None else None,'recordStatus':'MISSING','original99':[],'modules':{},'diagnostics':{}}
   ix={}
   if rec is not None:
    try:
     ix=index_record(rec);row.update({'recordStatus':'RAW_RECORD_INDEXED','recordProfile':rec.get('itcve'),'rawCounts':counts(list(ix.values())),'rawAssertions':len(ix),'missingExpectedIds':sorted(expected-set(ix)),'unexpectedIds':sorted(set(ix)-expected),'nonPass':[a for a in ix.values()if a['outcome']!='PASS']})
     if not legacy and rec.get('itcve')!=config['profile']:row.setdefault('bindingErrors',[]).append('Unexpected profile')
     if not legacy and rec.get('walletCandidate')!=config['walletCandidate']:row.setdefault('bindingErrors',[]).append('Unexpected candidate tuple')
    except Exception as e:row['recordStatus']='MALFORMED';row['recordError']=str(e)
   indexes.append(ix)
   for old in config['original99']:
    now=ix.get(old['key']);row['original99'].append({**old,'before':old['outcome'],'outcome':now['outcome']if now else'NOT_OBSERVED','detail':now.get('detail')if now else None,'attribution':'PROSPECTIVE_NAMESPACE_ORACLE_CORRECTION'if old['id']in ['namespace.protocol.reserved','namespace.basket.reserved']else'ARTIFACT_COMPONENT_AND_FIXTURE_OBSERVATION_NO_SINGLE_CAUSE_INFERENCE'})
   row['original99Counts']=counts(row['original99']);row['original99NonPass']=[x for x in row['original99']if x['outcome']!='PASS']
   for family,modules in [('coverage',config['coverageModules']),('completion',config['completionModules'])]:
    for name,m in modules.items():
     vector=m.get('vector','ISI-4-V005'if name=='permissions'else'ISI-4-V008');ids=m['assertionIds'];xs=[ix.get(vector+'/'+id,{'key':vector+'/'+id,'id':id,'outcome':'NOT_OBSERVED'})for id in ids]
     row['modules'][family+'.'+name]={'expectedAssertions':len(ids),'counts':counts(xs),'nonPass':[x for x in xs if x['outcome']!='PASS']}
   # Retain diagnostic metadata, never reinterpret envelope exceptional values as valid JS results.
   for n in ['conformance/coverage-suite.json','conformance/completion-suite.json','conformance/permission-prelude-completion.json','conformance/permission-extension.json','conformance/coverage-extension.json','conformance/coverage-certificates.json']+[m['report']for m in config['completionModules'].values()]:
    c=capture(evidence+n);v=c.pop('value',None)
    if isinstance(v,dict):
     envelope=v.get('schema')=='tpnil-coverage-observation@1.0.0';c['encodedObservation']=envelope
     if envelope:c['exceptionalValueCount']=len(v.get('exceptionalValues',[]));v=v.get('value')
     if isinstance(v,dict):
      for k in ['schema','oracle','policySha256','errors','modules','fixtureBlockers','cleanup','counts']:
       if k in v:c[k]=v[k]
      if isinstance(v.get('trace'),list):c['traceCalls']=len(v['trace'])
    row['diagnostics'][n]=c
   for n in ['shutdown-submissions.json','mongo-cleanup.json','completion-inventory-closure.json','action-observer-closure.json']:
    c=capture(prefix+n);v=c.pop('value',None)
    if isinstance(v,dict):
     for k in ['schema','profile','policy','errors','failureCategories','cleanup','initialCount','clean','forced','code','signal']:
      if k in v:c[k]=v[k]
     if isinstance(v.get('submissions'),list):c['submissionCount']=len(v['submissions'])
    row['diagnostics'][n]=c
   for n in [f'host-repetition-{i}-cleanup.json',evidence+'native-browser-contexts.json']:
    c=capture(n);v=c.pop('value',None)
    if isinstance(v,dict):
     if 'contexts'in v:c['contexts']=v['contexts']
     else:c['raw']=v
    row['diagnostics'][n]=c
   rust=capture(f'rust-repetition-{i}/result.json');v=rust.pop('value',None)
   if isinstance(v,dict):rust.update({'rawCounts':counts(v.get('assertions',[]),'result'),'assertionCount':len(v.get('assertions',[])),'schema':v.get('schema')})
   else:rust['execution']='NOT_OBSERVED'
   row['rust']=rust;report['repetitions'].append(row)
  report['repetitionDifferences']=[{'key':k,'first':indexes[0].get(k,{}).get('outcome','NOT_OBSERVED'),'second':indexes[1].get(k,{}).get('outcome','NOT_OBSERVED')}for k in sorted(set(indexes[0])|set(indexes[1]))if indexes[0].get(k,{}).get('outcome')!=indexes[1].get(k,{}).get('outcome')]
  report['failureFiles']=[r for r in members if any(x in r['path'].lower()for x in ['attempt-failure','failure-tree','worker.stderr','container.log'])]
  report['artifactIntegrity']='ALL_MEMBER_BYTES_READ_AND_CRC_SHA256_CHECKED'
  return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--zip',required=True);p.add_argument('--output',required=True);p.add_argument('--run-api');p.add_argument('--artifact-api');p.add_argument('--run-id',type=int);p.add_argument('--legacy-native6-control',action='store_true');a=p.parse_args()
 config=json.loads((HERE/'config.json').read_bytes());prep=json.loads((HERE/'preparation.json').read_bytes());assert H((HERE/'config.json').read_bytes())==prep['configSha256']
 result=inspect(a.zip,config,a.legacy_native6_control);result['createdAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['configSha256']=prep['configSha256'];result['checkerSha256']=digest(__file__)
 if a.run_api:
  api=json.loads(Path(a.run_api).read_bytes());assert api['id']==a.run_id and api['head_sha']==config['source'];assert api['status']=='completed'and api['event']=='workflow_dispatch';result['runApi']={'id':api['id'],'conclusion':api['conclusion'],'source':api['head_sha'],'sha256':digest(a.run_api),'runAttempt':api['run_attempt']}
 if a.artifact_api:
  api=json.loads(Path(a.artifact_api).read_bytes());assert api['total_count']==len(api['artifacts']);rows=[x for x in api['artifacts']if x['name']==config['artifactName']];assert len(rows)==1;v=rows[0];assert not v['expired'];assert v['digest']=='sha256:'+result['originalZip']['sha256']and v['size_in_bytes']==result['originalZip']['bytes'];result['githubArtifact']={'id':v['id'],'name':v['name'],'apiSha256':digest(a.artifact_api),'digestVerified':True}
 with Path(a.output).open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'written':a.output,'sha256':digest(a.output),'claim':result['claim'],'members':len(result['members']),'errors':result['errors'],'repetitions':[{'index':r['index'],'rawCounts':r.get('rawCounts'),'original99Counts':r['original99Counts'],'recordStatus':r['recordStatus'],'rust':r['rust']['status']}for r in result['repetitions']],'qualifiedEnvironment':False}))
